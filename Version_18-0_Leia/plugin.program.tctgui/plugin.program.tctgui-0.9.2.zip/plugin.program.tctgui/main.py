"""
    Plugin: Texture Cache Tool - GUI Version
    See https://github.com/Project-Kodi/Project-Kodi.github.io
    
"""

# Imports
import subprocess
import os
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
import urllib3
import json
import time
import re
from pathlib import Path
from functools import partial
from datetime import datetime

# Import Lunatixz - CPU Benchmark | for a update, read: plugin.program.tctgui\resources\lib\pystone\README
from resources.lib.pystone import cpubenchmark

# Addon Infos
self = xbmcaddon.Addon()
__name__ = self.getAddonInfo('name')
__id__ = self.getAddonInfo('id')
__summary__ = self.getAddonInfo('summary')
__description__ = self.getAddonInfo('description')
__author__ = self.getAddonInfo('author')
__version__ = self.getAddonInfo('version')
__changelog__ = self.getAddonInfo('changelog')
__type__ = self.getAddonInfo('type')
__disclaimer__ = self.getAddonInfo('disclaimer')
__path__ = self.getAddonInfo('path')
__fanart__ = self.getAddonInfo('fanart')	
__icon__ = self.getAddonInfo('icon')
__profile__ = self.getAddonInfo('profile')	
__stars__ = self.getAddonInfo('stars')

# Fixed values/configs
time2000 = 2000
time4000 = 4000

# Function: Info Log
def log_info(log_entry):
    if self.getSettingBool('utility_logging01'):
        xbmc.log( 'plugin.program.tctgui: Info: %s' % log_entry, xbmc.LOGINFO)

# Function: Debug Log
def log_debug(log_entry):
    if self.getSettingBool('utility_logging02'):
        xbmc.log( 'plugin.program.tctgui: DEBUG: %s' % log_entry)

# Function: datetime
def show_datetime():
    clean_show_datetime = str(datetime.now())
    return clean_show_datetime

# Function: Remove all control characters
def control_characters(dirty_str):
    clean_str = re.sub(r'[\x00-\x1f]', '', str(dirty_str))
    return clean_str

# Dev Check: arguments/parameters/addon - Part 1
if len(sys.argv) == 3:
    #print ('sys.argv = 3')
    log_debug('Dev Check - count arguments/parameters: ' + str(len(sys.argv)))
    log_debug('Dev Check - arguments/parameters are: ' + str(sys.argv))
    log_debug('Dev Check - Sysargv[0] is: ' + str(sys.argv[0]) + ' | Sysargv[1] is: ' + str(sys.argv[1]) + ' | Sysargv[2] is: ' + str(sys.argv[2]))
else:
    #print ('sys.argv != 3')
    log_debug('Dev Check - count arguments/parameters: ' + str(len(sys.argv)))

 # Dev Check: arguments/parameters/addon - Part 2 
log_debug('Dev Check - addon: ' + str(self))
log_debug('Dev Check - addonname: ' + __name__) 
log_debug('Dev Check - addonpath: ' + __path__)
log_debug('Dev Check - xbmcgui.getCurrentWindowId: ' + str(xbmcgui.getCurrentWindowId()))
log_debug('Dev Check - xbmcgui.getCurrentWindowDialogId: ' + str(xbmcgui.getCurrentWindowDialogId()))

# Function: Write texturecache.cfg file and fill it with content
def write_texturecache_cfg(filecontent):
    filepathfull = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'lib', 'texturecachetool', 'texturecache.cfg')
    log_debug('Write texturecache Config Data to: ' + filepathfull)
    with xbmcvfs.File(filepathfull, 'w') as f:
        result = f.write(filecontent)
        if result:
            log_info('write_texturecache_cfg: OK')
        else:    
            log_info('write_texturecache_cfg: ERROR')
    log_debug('Write texturecache.cfg Content: ' + filecontent)   

# Write 
def write_texturecache_default_cfg():
    cfgfilecontent = '## ' + self.getLocalizedString(30845) + ' - ' + show_datetime() + '\nxbmc.host = ' + self.getSettingString('xbmc.host') + '\nwebserver.port = ' + str(self.getSettingInt('webserver.port')) + '\nwebserver.username = ' + self.getSettingString('webserver.username') + '\nwebserver.password = ' + self.getSettingString('webserver.password') + '\nrpc.port = ' + str(self.getSettingInt('rpc.port')) + '\nrpc.retry = ' + str(self.getSettingInt('rpc.retry')) + '\ndbfile = ' + self.getSettingString('dbfile') + '\nthumbnails = ' + self.getSettingString('thumbnails') + '\nuserdata = ' + self.getSettingString('userdata') + '\ndownload.threads = ' + str(self.getSettingInt('download.threads')) + '\ndownload.retry = ' + str(self.getSettingInt('download.retry')) + '\ndownload.prime = ' + self.getSettingString('download.prime') + '\nallow.recacheall = ' + self.getSettingString('allow.recacheall') + '\ncache.castthumb = ' + self.getSettingString('cache.castthumb') + '\ncache.extra = ' + self.getSettingString('cache.extra') + '\nimdb.threads = ' + str(self.getSettingInt('imdb.threads')) + '\norphan.limit.check = ' + self.getSettingString('orphan.limit.check') + '\nlastrunfile = ' + self.getSettingString('lastrunfile') + '\nlogfile.unique = ' + self.getSettingString('logfile.unique') + '\nlogfile = ' + self.getSettingString('logfile') + '\nlogfile.verbose = ' + self.getSettingString('logfile.verbose') + '\n'     
    write_texturecache_cfg(cfgfilecontent)

# Addon - Main Menu - Auswahl Steuerung
def select(heading, options, default=lambda: start_main_menu):
    labels = [option['label'] for option in options]
    result = xbmcgui.Dialog().select(heading, labels)
    selected = options[result]
    log_debug('Auswahl:  label=' + selected['label'] + ' | func=' + control_characters(selected['func']) + ' | complete=' + control_characters(selected['complete']) + ' | cmd=' + selected['cmd'] + ' | cmd2=' + selected['cmd2'] + '')
    print([selected]) 
    if result == -1:
        log_debug("Addon - Main Menu - Auswahl Steuerung: Default")
        default()
        return
    selected['func'](selected)
    selected['complete']()

# Helper => First Windows from Menu [0]
def cmd_busy(command):
    log_debug('Start the function: cmd_busy, argument:' + str(command))
    #print(command)
# Sub-Helper => Fifth   
    def busy_command(option):
        log_debug('Start the function: busy_command, argument:' + str(option))

        option_label = option["label"]
        log_debug(option_label) 
        option_func = option["func"]
        log_debug(option_func)
        option_complete = option["complete"]
        log_debug(option_complete) 
        option_cmd = option["cmd"]
        log_debug(option_cmd) 
        option_cmd2 = option["cmd2"]
        log_debug(option_cmd2)         
    
        #xbmc.executebuiltin( "ActivateWindow(busydialog)" )
        retVal = command(option)
        #xbmc.executebuiltin( "Dialog.Close(busydialog)" )
        log_debug('In the function: busy_command, argument:' + str(retVal))        
        return retVal
    return busy_command

# Helper => Second
def start_u_opt(*args):
    log_debug('Start the function: start_u_opt, arguments:' + str(*args))

    s_option_label = args[0]["label"]
    log_debug(s_option_label) 
    s_option_func = args[0]["func"]
    log_debug(s_option_func)
    s_option_complete = args[0]["complete"]
    log_debug(s_option_complete)
    s_option_cmd = args[0]["cmd"]
    log_debug(s_option_cmd)
    s_option_cmd2 = args[0]["cmd2"]
    log_debug(s_option_cmd2)

    # Notification
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('' + self.getLocalizedString(30846) + '', 'texturecache.py ' + s_option_cmd + '' + s_option_cmd2 + '', time2000, __icon__))        
    log_debug('RUNNING | texturecache.py ' + s_option_cmd + '' + s_option_cmd2 + '')
            
    #OS: den Pfad unabhängig von OS korrekt anpassen, pathlib
    file_to_run = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'lib', 'texturecachetool', 'texturecache.py')        
    #file_to_run = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'lib', 'texturecachetool', s_option_cmd)
    log_debug('Dev Check - Run python file Aufruf without args: ' + file_to_run)
    log_info('Run python file with args: ' + file_to_run + ' ' + s_option_cmd + ' ' + s_option_cmd2)

    #Run Script CMD with one or two Options, empty options make a \n error | Python, File, Arg1, Arg2, Arg3,.. stdout=PIPE
    if s_option_cmd2 == "":
        result = subprocess.run(['python', file_to_run, s_option_cmd], shell=True, capture_output=True, text=True)
    else:
        result = subprocess.run(['python', file_to_run, s_option_cmd, s_option_cmd2], shell=True, capture_output=True, text=True)
    print(result)
    log_debug('Run python file Standardfehlerausgabe (stderr): ' + control_characters(result.stderr))
    log_debug('Run python file Standardausgabe (stdout): ' + control_characters(result.stdout))
    log_debug('Run python file Return Code (returncode): ' + control_characters(result.returncode))
    log_debug('Run python file Output (args): ' + control_characters(result.args))

    # Daten aufbereiten und Antworten hinzufügen
    args = list(args)
    args[0]["output"]  = control_characters(result.stderr).strip()
    args[0]["output2"]  = control_characters(result.stdout).strip()
    print (*args)
 
    # Übergabe an die Funktion: start_u_opt_one
    start_u_opt_one(*args)

# Helper => Thirds
def start_u_opt_one(option):
    log_debug('Start the function: start_u_opt_one: Menu Eintrag anzeigen 1 / Ausgabe der einzelnen Options: LABEL | FUNC | COMPLETE | CMD')
    #print(option)

    option_label = option["label"]
    log_debug(option_label) 
    option_func = option["func"]
    log_debug(option_func)
    option_complete = option["complete"]
    log_debug(option_complete) 
    option_cmd = option["cmd"]
    log_debug(option_cmd)
    option_cmd2 = option["cmd2"]
    log_debug(option_cmd2)
    option_output = option["output"]
    log_debug(option_output)
    option_output2 = option["output2"]
    log_debug(option_output2)  

    # Hier ein eigenes Fenster mit der gesamten Meldung:
    dialog = xbmcgui.Dialog()
    dialog.textviewer('' + self.getLocalizedString(30847) + ': texturecache.py ' + option_cmd + ' ' + option_cmd2 + '', 'Result 01:\n' + option_output + '\n\nResult 02:\n' + option_output2 + '')

    # Hier die Meldung weiter geben an das Untermenü // gespeicherten Log Path anzeigen oder andere Dinge. // Danach weiter in das Hauptmenü
    runfilescmd = []
    runfilescmd.append({'label': '' + self.getLocalizedString(30841) + ': ' + self.getLocalizedString(30840) + '', 'func': dummy, 'complete': select_noop, 'cmd': option_cmd, 'cmd2': option_cmd2, 'output': option_output, 'output2': option_output2})
    log_debug('Start the function: start_u_opt_one: Menu Eintrag anzeigen 2')
    #select('AUSGABE 01',runfilescmd)
    select('' + self.getLocalizedString(30847) + ': texturecache.py ' + option_cmd + ' ' + option_cmd2 + '',runfilescmd)

# ODER
    # Direkt in das Hauptmenü retour
    #start_main_menu()

# Helper  => Fourth
def dummy(*args):
    log_debug('Start the function: dummy, arguments:' + str(*args))

    d_option_label = args[0]["label"]
    log_debug(d_option_label) 
    d_option_func = args[0]["func"]
    log_debug(d_option_func)
    d_option_complete = args[0]["complete"]
    log_debug(d_option_complete)
    d_option_cmd = args[0]["cmd"]
    log_debug(d_option_cmd)
    d_option_cmd2 = args[0]["cmd2"]
    log_debug(d_option_cmd2)
    d_option_output = args[0]["output"]
    log_debug(d_option_output)
    d_option_output2 = args[0]["output2"]
    log_debug(d_option_output2)   

# Helper => Keine Auswahl, Standard im Menü
def select_noop(*args):
    log_debug('Start the function: select_noop, Ende Meldung, keine Auswahl, Standard im Menü')
    pass

# Addon - Main Menu V. 1.0.1
def start_main_menu():
    log_debug('Start the Main Menu')
    menu = [  
            {'label': '' + self.getLocalizedString(30800) + '', 'func': cmd_busy(start_u_opt), 'complete': start_main_menu, 'cmd': 'r', 'cmd2': ''},
            {'label': '' + self.getLocalizedString(30801) + '', 'func': cmd_busy(start_u_opt), 'complete': start_main_menu, 'cmd': 'R', 'cmd2': ''},
            {'label': '' + self.getLocalizedString(30802) + '', 'func': cmd_busy(start_u_opt), 'complete': start_main_menu, 'cmd': 'Xd', 'cmd2': ''},
            {'label': '' + self.getLocalizedString(30803) + '', 'func': cmd_busy(start_u_opt), 'complete': start_main_menu, 'cmd': 'p', 'cmd2': ''},
            {'label': '' + self.getLocalizedString(30804) + '', 'func': cmd_busy(start_u_opt), 'complete': start_main_menu, 'cmd': 'P', 'cmd2': ''},
            {'label': '' + self.getLocalizedString(30805) + '', 'func': cmd_busy(start_u_opt), 'complete': start_main_menu, 'cmd': 'lc', 'cmd2': ''},
            {'label': '' + self.getLocalizedString(30806) + '', 'func': cmd_busy(start_u_opt), 'complete': start_main_menu, 'cmd': 'c', 'cmd2': ''},
            {'label': '' + self.getLocalizedString(30807) + '', 'func': cmd_busy(start_u_opt), 'complete': start_main_menu, 'cmd': 'C', 'cmd2': ''},
            {'label': '' + self.getLocalizedString(30808) + '', 'func': cmd_busy(start_u_opt), 'complete': start_main_menu, 'cmd': 'lc', 'cmd2': 'movies'},
            {'label': '' + self.getLocalizedString(30809) + '', 'func': cmd_busy(start_u_opt), 'complete': start_main_menu, 'cmd': 'c ', 'cmd2': 'movies'},
            {'label': '' + self.getLocalizedString(30810) + '', 'func': cmd_busy(start_u_opt), 'complete': start_main_menu, 'cmd': 'C ', 'cmd2': 'movies'},
            {'label': '' + self.getLocalizedString(30811) + '', 'func': cmd_busy(start_u_opt), 'complete': start_main_menu, 'cmd': 'lc ', 'cmd2': 'tvshows'},
            {'label': '' + self.getLocalizedString(30812) + '', 'func': cmd_busy(start_u_opt), 'complete': start_main_menu, 'cmd': 'c', 'cmd2': 'tvshows'},
            {'label': '' + self.getLocalizedString(30813) + '', 'func': cmd_busy(start_u_opt), 'complete': start_main_menu, 'cmd': 'C', 'cmd2': 'tvshows'},
            {'label': '' + self.getLocalizedString(30814) + '', 'func': cmd_busy(start_u_opt), 'complete': start_main_menu, 'cmd': 'lc', 'cmd2': 'artists'},
            {'label': '' + self.getLocalizedString(30815) + '', 'func': cmd_busy(start_u_opt), 'complete': start_main_menu, 'cmd': 'c', 'cmd2': 'artists'},
            {'label': '' + self.getLocalizedString(30816) + '', 'func': cmd_busy(start_u_opt), 'complete': start_main_menu, 'cmd': 'C', 'cmd2': 'artists'},
            {'label': '' + self.getLocalizedString(30817) + '', 'func': cmd_busy(start_u_opt), 'complete': start_main_menu, 'cmd': 'lc', 'cmd2': 'albums'},
            {'label': '' + self.getLocalizedString(30818) + '', 'func': cmd_busy(start_u_opt), 'complete': start_main_menu, 'cmd': 'c', 'cmd2': 'albums'},
            {'label': '' + self.getLocalizedString(30819) + '', 'func': cmd_busy(start_u_opt), 'complete': start_main_menu, 'cmd': 'C', 'cmd2': 'albums'},
            {'label': '' + self.getLocalizedString(30820) + '', 'func': cmd_busy(start_u_opt), 'complete': start_main_menu, 'cmd': 'lc', 'cmd2': 'sets'},
            {'label': '' + self.getLocalizedString(30821) + '', 'func': cmd_busy(start_u_opt), 'complete': start_main_menu, 'cmd': 'c', 'cmd2': 'sets'},
            {'label': '' + self.getLocalizedString(30822) + '', 'func': cmd_busy(start_u_opt), 'complete': start_main_menu, 'cmd': 'C', 'cmd2': 'sets'}
    ]
    select('' + self.getLocalizedString(30842) + '', menu, default=select_noop)

# Control - Addon - Press Start - Show Main Menu
if xbmcgui.getCurrentWindowDialogId() == 9999:
    log_debug('Addon Program Start')
    # Davor noch aus den Addon Settings in texturecache.cfg speichern
    write_texturecache_default_cfg()
    # Menü Funktion starten
    start_main_menu()

# Control - Addon Settings - Actions V.0.0.3
if len(sys.argv) > 1:
    log_debug('ON: Control - Addon Settings - Actions')
    # Run CPU/Python Benchmark    
    if (sys.argv[1] == 'mode=cpu-python-benchmark'):
        if (sys.argv[2] == 'action=run_now'):
            xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('' + self.getLocalizedString(30843) + '', '' + self.getLocalizedString(30844) + '!', time2000, __icon__)) 
            cpubenchmark.CPU().run()
            log_debug('RUNNING | mode=cpu-python-benchmark')
            log_info('Run CPU Benchmark')
        else: 
            log_debug('WRONG COMMAND/ERROR | mode=cpu-python-benchmark')        
    # Update von texturecache.py
    if (sys.argv[1] == 'mode=texturecachetoolupdate'):
        if (sys.argv[2] == 'action=run_now'):
            xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('' + self.getLocalizedString(30848) + '', '' + self.getLocalizedString(30844) + '!', time2000, __icon__))        
            log_debug('RUNNING | mode=texturecachetoolupdate')
            log_info('Run Update from texturecache.py')           
            #OS: den Pfad unabhängig von OS korrekt anpassen, pathlib    
            file_to_run = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'lib', 'texturecachetool', 'texturecache.py')
            log_debug('Run python file Aufruf: ' + file_to_run)
            
            # Source: https://docs.python.org/3/library/subprocess.html
            #subprocess.run(args, *, stdin=None, input=None, stdout=None, stderr=None, capture_output=False, shell=False, cwd=None, timeout=None, check=False, encoding=None, errors=None, text=None, env=None, universal_newlines=None, **other_popen_kwargs)

            #Running Update from texturecache.py | Python, File, Arg1, Arg2, Arg3,.. stdout=PIPE
            result = subprocess.run(['python', file_to_run, 'update', ''], shell=True, capture_output=True, text=True)
            log_debug('Run python file Standardfehlerausgabe (stderr): ' + control_characters(result.stderr))
            log_debug('Run python file Standardausgabe (stdout): ' + control_characters(result.stdout))
            log_debug('Run python file Return Code (returncode): ' + control_characters(result.returncode))
            log_debug('Run python file Output (args): ' + control_characters(result.args))
            xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__name__,control_characters(result.stderr), time4000, __icon__))            
        else:            
             log_debug('WRONG COMMAND/ERROR | mode=texturecachetoolupdate')      
    # Update von texturecache.cfg             
    if (sys.argv[1] == 'mode=texturecachecfgupdate'):
        if (sys.argv[2] == 'action=run_now'):
            xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('' + self.getLocalizedString(30849) + '', '' + self.getLocalizedString(30850) + '!', time2000, __icon__))
            # Addon Settings in texturecache.cfg speichern
            write_texturecache_default_cfg()
            log_debug('RUNNING | mode=texturecachecfgupdate')
            log_info('Run Update from texturecache.cfg')
        else:            
            log_debug('WRONG COMMAND/ERROR | mode=texturecachecfgupdate')  
                      
    # dev01
    if (sys.argv[1] == 'mode=dev01'):
        if (sys.argv[2] == 'action=run_now'):
            log_debug('RUNNING | mode=dev01')
            log_info('Run DEV01')
            xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('mode=dev01', 'action=run_now', time2000, __icon__))            

####===>> DEV ZONE 01
 
        else:            
             log_debug('WRONG COMMAND/ERROR | mode=dev01')               
             
    # dev02
    if (sys.argv[1] == 'mode=dev02'):
        if (sys.argv[2] == 'action=run_now'):
            log_debug('RUNNING | mode=mode=dev02')
            log_info('Run DEV02')
            xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('mode=dev02', 'action=run_now', time2000, __icon__))            

####===>> DEV ZONE 02
            
        else:            
             log_debug('WRONG COMMAND/ERROR | mode=mode=dev02') 
             
# Reserve
    # dev03
 #   if (sys.argv[1] == 'mode=dev03'):
 #       if (sys.argv[2] == 'action=run_now'):
 #           log_debug('RUNNING | mode=mode=dev03')
 #            log_info('Run DEV03')
 #           xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('mode=dev03', 'action=run_now', time2000, __icon__)) 
 #       else:            
 #            log_debug('WRONG COMMAND/ERROR | mode=mode=dev03')              
                               
else:
    log_debug('OFF: Control - Addon Settings - Actions')