# -*- coding: UTF-8 -*-
#
# Copyright (C) 2024, Project Kodi
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# Code attribution:
# core based on metadata.tvshows.thesportsdb.python by pkscout
# and metadata.tvmaze scrapper by Roman Miroshnychenko aka Roman V.M.
# and the metadata.tvshows.themoviedb.org.python scraper by Team Kodi
# all created by improvements to metadata.thesportsdb.com 2015 from Project Kodi (peter0123)
#
# Addon: The Sports Database Python - metadata.thesportsdb.python
# See https://github.com/Project-Kodi/Project-Kodi.github.io/
# pylint: disable=missing-docstring


"""Misc utils"""

from __future__ import absolute_import, unicode_literals

import os
import re
import xbmc
from xbmcaddon import Addon
import xbmcvfs
import json
from datetime import datetime
from . import settings
try:
    from typing import Text, Optional, Any, Dict  # pylint: disable=unused-import
except ImportError:
    pass

# Addon Settings - Verbose logging extreme
verboselog_adv = settings.VERBOSELOGADV
overwrite_nfo = settings.OVERWRITENFO

# Addon Data ?
ADDON_ID = "metadata.tvshows.thesportsdb.python"
ADDON = Addon()

# Addon Infos
self_addon_name = ADDON.getAddonInfo('name')
self_addon_id = ADDON.getAddonInfo('id')
self_addon_version = ADDON.getAddonInfo('version')
self_addon_providername = ADDON.getAddonInfo('author')

TimeStamp = datetime.now().strftime('%d-%m-%Y %H:%M:%S')
RepositoryInfo = 'https://Project-Kodi.github.io/'



class logger:
    log_message_prefix = "[{} ({})]: ".format(ADDON_ID, ADDON.getAddonInfo("version"))

    @staticmethod
    def log(message, level=xbmc.LOGDEBUG):
        # type: (Text, int) -> None
        if isinstance(message, bytes):
            message = message.decode("utf-8")
        message = logger.log_message_prefix + message
        xbmc.log(message, level)

    @staticmethod
    def info(message):
        # type: (Text) -> None
        logger.log(message, xbmc.LOGINFO)

    @staticmethod
    def error(message):
        # type: (Text) -> None
        logger.log(message, xbmc.LOGERROR)

    @staticmethod
    def debug(message):
        # type: (Text) -> None
        logger.log(message, xbmc.LOGDEBUG)


def url_fix(url):
    # type: (Text) -> Text
    """
    fixes the URL from the API results to remove escaping slashes
    """
    if url:
        return url.replace("\/", "/")
    else:
        return ""

# Function: Remove all control characters
def control_characters(dirty_str):
    clean_str = re.sub(r'[\x00-\x1f]', '', str(dirty_str))
    return clean_str

#Get correct TVShow
def nfo_correct_tvshow(nfo_str_League, spdb_vdb_id):
    logger.debug('Start function: nfo_correct_tvshow')
    logger.debug('nfo_str_League parm:  "{}"'.format(nfo_str_League))
    logger.debug('spdb_vdb_id parm:  "{}"'.format(spdb_vdb_id))
    nfo_kodi_vdb_id = ''
    payload = {"jsonrpc": "2.0", "method": "VideoLibrary.GetTVShows", "params": { "properties": ["art", "genre", "plot", "title", "originaltitle", "year", "rating", "thumbnail", "playcount", "file", "fanart"], "sort": { "order": "ascending", "method": "label" } }, "id": "libTvShows"}
    #payload = {"jsonrpc": "2.0", "method": "VideoLibrary.GetTVShows", "params": { "filter": {"field": "playcount", "operator": "is", "value": "0"}, "limits": { "start" : 0, "end": 75 }, "properties": ["art", "genre", "plot", "title", "originaltitle", "year", "rating", "thumbnail", "playcount", "file", "fanart"], "sort": { "order": "ascending", "method": "label" } }, "id": "libTvShows"}

    info = json.loads(xbmc.executeJSONRPC(json.dumps(payload)))
    result = info["result"]
    nfo_full_result = info["result"]['tvshows']
    if verboselog_adv:
        logger.debug('nfo_correct_tvshow - Result:  "{}"'.format(result))
        logger.debug('nfo_correct_tvshow - Result:  "{}"'.format(nfo_full_result))
    #Loop TVShow for correct one
    for x in nfo_full_result:
        #correct one found
        if verboselog_adv:
            logger.debug('nfo_correct_tvshow - correct one ..  "{}"'.format(x)) 
        if nfo_str_League in x['title']:
            nfo_path = x['file']
            nfo_kodi_vdb_id = x['tvshowid']
            nfo_title = x['title']
            if verboselog_adv:
                logger.debug("nfo_path: %s " % nfo_path)
                logger.debug("nfo_kodi_vdb_id: %s " % nfo_kodi_vdb_id)
                logger.debug("nfo_title: %s " % nfo_title)
    #Wenn nicht gefunden, durch Loop da nur 1 Ergebnis.
    if not nfo_kodi_vdb_id:
        nfo_path = nfo_full_result[0]['file']
        nfo_kodi_vdb_id = nfo_full_result[0]['tvshowid']
        nfo_title = nfo_full_result[0]['title']
    if verboselog_adv:    
        logger.debug('Correct Kodi VideoDatabase TVShow ID:  "{}"'.format(spdb_vdb_id))
        logger.debug('Correct Kodi VideoDatabase nfo_path:  "{}"'.format(nfo_path))
        logger.debug('Correct Kodi VideoDatabase nfo_kodi_vdb_id:  "{}"'.format(nfo_kodi_vdb_id))
        logger.debug('Correct Kodi VideoDatabase nfo_title:  "{}"'.format(nfo_title))
    #Call function for NFO
    write_nfo_get_filepath_content('tvshow', nfo_path, nfo_title, nfo_kodi_vdb_id, nfo_full_result, spdb_vdb_id)


# Function: Write *.nfo file and fill it with content
def write_nfo_file_msg(filepathfull, filecontent):
    logger.debug('Start function: write_nfo_file_msg')
    logger.debug('Write *.nfo Data to:  "{}"'.format(filepathfull))
    index = 0

    # NFO - IF File exist and overwrite is off
    logger.debug('overwrite_nfo (Addon Setting):  "{}"'.format(overwrite_nfo))
    logger.debug('xbmcvfs.exists:  "{}"'.format(xbmcvfs.exists(filepathfull,)))    

    if xbmcvfs.exists(filepathfull) and not overwrite_nfo:
        logger.debug('NFO File exist and overwrite is off - Addon Setting')
    else:
        logger.debug('NFO File write is ok - Addon Setting')       
        with xbmcvfs.File(filepathfull, 'w') as f:
            result = f.write('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n')
            f.write('<!-- Created by ' + self_addon_name + ' Version ' + self_addon_version + ' | Provider: ' + self_addon_providername + ' | Addon: ' + self_addon_id + ' | Repository: ' + RepositoryInfo + ' | Created on ' + TimeStamp + ' -->\n')
            while index < len(filecontent):           
                f.write(str(filecontent[index]) + '')
                index += 1
            f.close()
            if result:
                logger.debug('write_nfo_file: OK')
            else:
                logger.debug('write_nfo_file: ERROR')    
                if filepathfull.find("/") > 0:
                    logger.debug('write_nfo_file: Slash or Backslah: / ')
                    searchlist = filepathfull.rsplit('/', 1)
                if filepathfull.find("\\") > 0:
                    logger.debug('write_nfo_file: Slash or Backslah: \ ')
                    searchlist = filepathfull.rsplit('\\', 1)
                filepathfull_help = searchlist[0]
                #Existiert der Pfad nicht?
                if xbmcvfs.exists(filepathfull):
                    logger.debug('write_nfo_file: Pfad existiert')                
                else:
                    xbmcvfs.mkdirs(filepathfull_help) 
                    logger.debug('write_nfo_file: MKDIRS:  "{}"'.format(filepathfull_help))                                        
                    with xbmcvfs.File(filepathfull, 'w') as f:
                        result = f.write(filecontent)
                    if result:
                        logger.debug('Again.. write_nfo_file: OK')                
                    else:
                        logger.debug('Again.. write_nfo_file: ERROR')              
        logger.debug('Write *.nfo Content: "{}"'.format(filecontent))


def write_nfo_get_filepath_content(media_type, media_path, media_name, kodi_vdb_id, media_result, spdb_vdb_id):
    logger.debug('Start function: write_nfo_get_filepath_content')
    if verboselog_adv:
        logger.debug('media_type: "{}"'.format(media_type))
        logger.debug('media_path: "{}"'.format(media_path))
        logger.debug('media_name: "{}"'.format(media_name))
        logger.debug('kodi_vdb_id: "{}"'.format(kodi_vdb_id))    
        logger.debug('media_result: "{}"'.format( media_result)) 
    # Mediatype => tvshow
    if media_type=="tvshow":
        logger.debug('function: write_nfo_get_filepath_content => Auswahl TVSHOW')
        
        #Ausgabe im Serien Ordner
        # Wenn Ausgabe im Serien Ordner oder eigener Pfad, write_nfo_default = true
        if settings.WRITENFODEFAULT:
            logger.debug('Auswahl: NFO im Serien Ordner speichern')
            #Dateiname = write_nfo_tvshow_filename // (tvshowtitle).nfo // tvshow.nfo default 2
            if settings.WRITENFOTVSHOWFILENAME  == '1':         
                logger.debug('Auswahl NFO im Serien Ordner + : (tvshowtitle).nfo')
                # Dateiname und  Pfad ändern für NFO [(tvshowtitle).nfo]
                #filepathtvshow = sys.listitem.getVideoInfoTag().getPath()
                filepathtvshow = media_path


                filepathtvshow = os.path.join(filepathtvshow)
                logger.debug('filepathtvshow: "{}"'.format(filepathtvshow))
                #filepathtvshowwext = sys.listitem.getVideoInfoTag()

                nfofilenametvshow = media_name 
                logger.debug('title: "{}"'.format(nfofilenametvshow))
                nfofilenametvshow = nfofilenametvshow + '.nfo'
                logger.debug('nfofilenametvshow: "{}"'.format(nfofilenametvshow))
                nfofilenametvshow = filepathtvshow + nfofilenametvshow
                logger.debug('nfofilenametvshow: "{}"'.format(nfofilenametvshow))

                # NFO SCHREIBEN
                #nfofilenametvshow_content = 'das ist ein Test\n'
                #write_nfo_file_msg(nfofilenametvshow, nfofilenametvshow_content)     
                write_nfo_file_msg(nfofilenametvshow, create_nfo_content_tvshow(kodi_vdb_id, spdb_vdb_id))

            #Dateiname = write_nfo_tvshow_filename // (tvshowtitle).nfo // tvshow.nfo default 2
            
            elif settings.WRITENFOTVSHOWFILENAME == '2':
                logger.debug('Auswahl NFO im Serien Ordner +: tvshow.nfo')
                # Dateiname und  Pfad ändern für NFO [tvshow.nfo]
                #filepathtvshow = sys.listitem.getVideoInfoTag().getPath()
                filepathtvshow = media_path

                filepathtvshow = os.path.join(filepathtvshow)
                logger.debug('filepathtvshow: "{}"'.format(filepathtvshow))
                nfofilenametvshow = 'tvshow.nfo'
                logger.debug('nfofilenametvshow: "{}"'.format(nfofilenametvshow))
                nfofilenametvshow = filepathtvshow + nfofilenametvshow
                logger.debug('nfofilenametvshow: "{}"'.format(nfofilenametvshow))

                # NFO SCHREIBEN
                #nfofilenametvshow_content = 'das ist ein Test\n'
                #write_nfo_file_msg(nfofilenametvshow, nfofilenametvshow_content)     
                write_nfo_file_msg(nfofilenametvshow, create_nfo_content_tvshow(kodi_vdb_id, spdb_vdb_id))

        # Wenn Ausgabe im Serien Ordner oder eigener Pfad, write_nfo_default = false                   
        else:
            logger.debug('Auswahl: NFO in eigenen Ordner speichern')   

            #Dateiname = write_nfo_tvshow_filename // (tvshowtitle).nfo // tvshow.nfo default 2
            if settings.WRITENFOTVSHOWFILENAME == '1':
                logger.debug('Auswahl eigener Pfad + : (tvshowtitle).nfo')
                ##Eingegebener Pfad
                nfofilenametvshowp = settings.WRITENFOWNTVSHOWPATH 
                logger.debug('Auswahl eigener Pfad: "{}"'.format(nfofilenametvshowp))
                ##Eingegebener Pfad + Dateiname
                #filepathtvshowwext = sys.listitem.getVideoInfoTag()

                nfofilenametvshow = media_name  
                logger.debug('title: "{}"'.format(nfofilenametvshow))
                nfofilenametvshow = nfofilenametvshow + '.nfo'     
                nfofilenametvshow = nfofilenametvshowp + nfofilenametvshow
                logger.debug('nfofilenametvshow: "{}"'.format(nfofilenametvshow))

                # NFO SCHREIBEN
                #nfofilenametvshow_content = 'das ist ein Test\n'
                #write_nfo_file_msg(nfofilenametvshow, nfofilenametvshow_content)     
                write_nfo_file_msg(nfofilenametvshow, create_nfo_content_tvshow(kodi_vdb_id, spdb_vdb_id))

            #Dateiname = write_nfo_tvshow_filename // (tvshowtitle).nfo // tvshow.nfo default 2
            elif settings.WRITENFOTVSHOWFILENAME == '2':
                logger.debug('Auswahl eigener Pfad +: tvshow.nfo')
                ##Eingegebener Pfad
                nfofilenametvshow = settings.WRITENFOWNTVSHOWPATH 
                logger.debug('Auswahl eigener Pfad: "{}"'.format(nfofilenametvshow))
                ##Eingegebener Pfad + Dateiname
                nfofilenametvshow = nfofilenametvshow + 'tvshow.nfo'     

                # NFO SCHREIBEN
                #nfofilenametvshow_content = 'das ist ein Test\n'
                #write_nfo_file_msg(nfofilenametvshow, nfofilenametvshow_content)     
                write_nfo_file_msg(nfofilenametvshow, create_nfo_content_tvshow(kodi_vdb_id, spdb_vdb_id))                       


    # Auswahl SEASON
    elif media_type=="season":
        logger.debug('function: write_nfo_get_filepath_content => Auswahl SEASON')

    # Auswahl EPISODE
    elif media_type=="episode":
        logger.debug('function: write_nfo_get_filepath_content => Auswahl EPISODE')



# Function: NFO Content TVSHOW => https://kodi.wiki/view/NFO_files/Templates
def create_nfo_content_tvshow(kodi_vdb_id, spdb_vdb_id):
    logger.debug('Start function: create_nfo_content_tvshow')
    if verboselog_adv:
        logger.debug('kodi_vdb_id: "{}"'.format(kodi_vdb_id))

    payload = {"jsonrpc": "2.0", "method": "VideoLibrary.GetTVShowDetails", "params": {"properties": ["title", "genre", "year", "rating", "plot", "studio", "mpaa", "cast", "playcount", "episode", "imdbnumber", "premiered", "votes", "lastplayed", "fanart", "thumbnail", "file", "originaltitle", "sorttitle", "episodeguide", "season", "watchedepisodes", "dateadded", "tag", "art", "userrating", "ratings", "runtime", "uniqueid"], "tvshowid": kodi_vdb_id}, "id": 1}
    info = json.loads(xbmc.executeJSONRPC(json.dumps(payload)))
    result = info["result"]
    full_result = info["result"]['tvshowdetails']
    if verboselog_adv:
        logger.debug('RPC CALL Result: "{}"'.format(result))
    #Anfang TVSHOW
    nfo_content_tvshow = ['<tvshow>\n']
    nfo_content_tvshow.append('\t<dateadded>' + full_result['dateadded'] + '</dateadded>\n')   
    #Titel
    if full_result['title']:
        nfo_content_tvshow.append('\t<title>' + full_result['title'] + '</title>\n')
    if full_result['label']:
        nfo_content_tvshow.append('\t<showtitle>' + full_result['label'] + '</showtitle>\n')
    if full_result['originaltitle']:    
        nfo_content_tvshow.append('\t<originaltitle>' + full_result['originaltitle'] + '</originaltitle>\n') 
    if full_result['sorttitle']:
        nfo_content_tvshow.append('\t<sorttitle>' + full_result['sorttitle'] + '</sorttitle>\n')
    #Season
    if full_result['season']:
        nfo_content_tvshow.append('\t<season>' + str(full_result['season']) + '</season>\n')
    #Episoden Anzahl! - Achtung, Anzahl an gespeicherten Kodi Episoden und nicht von Scraper! = zeigt eventuell weniger als es zur Gänze gibt
    if full_result['episode']:
        nfo_content_tvshow.append('\t<episode>' + full_result['episode'] + '</episode>\n')
    #Votes - TSDB
    if full_result['votes']:
        nfo_content_tvshow.append('\t<votes>' + full_result['votes'] + '</votes>\n')
    #User Ratings
    if full_result['userrating']:
        nfo_content_tvshow.append('\t<userrating>' + str(full_result['userrating']) + '</userrating>\n')
    nfo_content_tvshow.append('\t<top250></top250>\n')
    #Plot and Tags
    if full_result['plot']:
        nfo_content_tvshow.append('\t<outline>' + control_characters(full_result['plot']) + '</outline>\n')
    if full_result['plot']:
        nfo_content_tvshow.append('\t<plot>' + control_characters(full_result['plot']) + '</plot>\n')
    if full_result['runtime']:    
        nfo_content_tvshow.append('\t<runtime>' + str(full_result['runtime']) + '</runtime>\n')    
    #Pictures
    full_result_art = full_result['art']
    #if full_result['art']['banner']:
    if full_result_art['banner']:        
        nfo_content_tvshow.append('\t<thumb aspect="banner">' + full_result['art']['banner'] + '</thumb>\n')
   # if full_result['art']['fanart']:
    if full_result_art['fanart']:       
        nfo_content_tvshow.append('\t<thumb aspect="landscape">' + full_result['art']['fanart'] + '</thumb>\n')
    #if full_result['art']['poster']:
    if full_result_art['poster']:       
        nfo_content_tvshow.append('\t<thumb aspect="poster">' + full_result['art']['poster'] + '</thumb>\n')
    #Fanart
    if full_result['fanart']:
        nfo_content_tvshow.append('\t<fanart><thumb colors="" preview="">' + full_result['fanart'] + '</thumb></fanart>\n') 

    #Season Poster
    #<thumb aspect="poster" season="0" type="season">https://image.tmdb.org/t/p/original/65fnzCKkyx8xZPvmIf7PhhyXZI9.jpg</thumb>
    #<thumb aspect="poster" season="1" type="season">https://image.tmdb.org/t/p/original/tGII1c84fhml9jYclHJiB3Yy4Vc.jpg</thumb>

    #Other Artwork
    #<thumb aspect="clearart">http://assets.fanart.tv/fanart/tv/72173/hdclearart/arrested-development-51581b135e99e.png</thumb>
    #<thumb aspect="clearlogo">https://image.tmdb.org/t/p/original/ddWlOQ7kojFlp0cchDZZUNAQhMp.png</thumb>
    #<thumb aspect="characterart">http://assets.fanart.tv/fanart/tv/72173/characterart/arrested-development-51581b4ccdf4d.png</thumb>
    #nfo_content_tvshow.append('\t<thumb spoof="" cache="" aspect="discart" preview="">https://assets.fanart.tv/fanart/movies/476669/moviedisc/the-kings-man-617786bba9b7f.png</thumb>\n')
    #nfo_content_tvshow.append('\t<thumb spoof="" cache="" aspect="keyart" preview="">https://assets.fanart.tv/fanart/movies/476669/movieposter/the-kings-man-5f468bd247c3b.jpg</thumb>\n')

    #Set Artwork
    #nfo_content_tvshow.append('\t<thumb spoof="" cache="" aspect="set.clearlogo" preview="">https://assets.fanart.tv/fanart/movies/391860/hdmovielogo/kingsman-collection-5a69d2e6eaa21.png</thumb>\n')
    #nfo_content_tvshow.append('\t<thumb spoof="" cache="" aspect="set.keyart" preview="">https://assets.fanart.tv/fanart/movies/391860/movieposter/kingsman-collection-5add0aa47e577.jpg</thumb>\n')
    #nfo_content_tvshow.append('\t<thumb spoof="" cache="" aspect="set.banner" preview="">https://assets.fanart.tv/fanart/movies/391860/moviebanner/kingsman-collection-5a691aee3c1e1.jpg</thumb>\n')
    #nfo_content_tvshow.append('\t<thumb spoof="" cache="" aspect="set.poster" preview="">https://image.tmdb.org/t/p/original/xMsRZIkUGUuHsNHCQBDyZH7l53M.jpg</thumb>\n')
    #nfo_content_tvshow.append('\t<thumb spoof="" cache="" aspect="set.landscape" preview="">https://image.tmdb.org/t/p/original/mkusMBRJyXJCcJ5RKlrKK2SC0Qv.jpg</thumb>\n')
    #nfo_content_tvshow.append('\t<thumb spoof="" cache="" aspect="set.fanart" preview="">https://image.tmdb.org/t/p/original/3Odw3MJymLLbFuOnmQjmvndKhOr.jpg</thumb>\n')

    #Abspieldaten
    if full_result['playcount']:
        nfo_content_tvshow.append('\t<playcount>' + str(full_result['playcount']) + '</playcount>\n')
    if full_result['lastplayed']:    
        nfo_content_tvshow.append('\t<lastplayed>' + full_result['lastplayed'] + '</lastplayed>\n')
    #Databse Kodi ID from Movie    
    if full_result['tvshowid']:
        nfo_content_tvshow.append('\t<id>' + str(full_result['tvshowid']) + '</id>\n')
    #Database IMDBNumber => Wrong, Scraper saves spdb in imdb
    if full_result['imdbnumber']:
        nfo_content_tvshow.append('\t<imdb></imdb> <!-- https://www.imdb.com/ -->\n')
        nfo_content_tvshow.append('\t<uniqueid default="false" type="imdb"></uniqueid> <!-- https://www.imdb.com/ -->\n')
    else:    
        nfo_content_tvshow.append('\t<uniqueid default="false" type="imdb"></uniqueid> <!-- https://www.imdb.com/ -->\n')
    #Database Number Sportsdb
    nfo_content_tvshow.append('\t<uniqueid default="true" type="tsdb">' + spdb_vdb_id + '</uniqueid> <!-- https://www.thesportsdb.com/ --> \n')  
    nfo_content_tvshow.append('\t<uniqueid default="false" type="thesportsdb">' + spdb_vdb_id + '</uniqueid> <!-- https://www.thesportsdb.com/ --> \n') 
    nfo_content_tvshow.append('\t<tsdb>' + spdb_vdb_id + '</tsdb> <!-- https://www.thesportsdb.com/ --> \n')
    #Databse ID's IMDB, TMDB, TVDB, ANIDB + WIKIDATA, FACEBOOK, INSTAGRAM & X    
    nfo_content_tvshow.append('\t<uniqueid default="false" type="tmdb"></uniqueid> <!-- https://www.themoviedb.com/ -->\n')
    nfo_content_tvshow.append('\t<uniqueid default="false" type="tvdb"></uniqueid> <!-- https://www.thetvdb.com/ -->\n')
    nfo_content_tvshow.append('\t<uniqueid default="false" type="anidb"></uniqueid> <!-- https://anidb.net/ -->\n')
    nfo_content_tvshow.append('\t<uniqueid default="false" type="tvrage"></uniqueid> <!-- https://www.tvrage.com/ -->\n')
    nfo_content_tvshow.append('\t<uniqueid default="false" type="tvmaze"></uniqueid> <!-- https://www.tvmaze.com/ -->\n')
    nfo_content_tvshow.append('\t<uniqueid default="false" type="zap2it"></uniqueid> <!-- https://tvschedule.zap2it.com/ -->\n')                
    nfo_content_tvshow.append('\t<uniqueid default="false" type="wikidata"></uniqueid> <!-- https://www.wikidata.org/ -->\n')
    nfo_content_tvshow.append('\t<uniqueid default="false" type="facebook"></uniqueid> <!-- https://www.facebook.com/ -->\n')
    nfo_content_tvshow.append('\t<uniqueid default="false" type="instagram"></uniqueid> <!-- https://www.instagram.com/ -->\n')
    nfo_content_tvshow.append('\t<uniqueid default="false" type="x"></uniqueid> <!-- https://x.com/ -->\n')
    #Episodeguide New
    nfo_content_tvshow.append('\t' + full_result['episodeguide'].replace(" ", "") + '\n')
    #Genres
    if full_result['genre']: 
        for x_genre in full_result['genre']:
            nfo_content_tvshow.append('\t<genre>' + x_genre + '</genre>\n')
    #Premiered,Year
    if full_result['premiered']:
        nfo_content_tvshow.append('\t<premiered>' + full_result['premiered'] + '</premiered>\n')
    if full_result['year']:
        nfo_content_tvshow.append('\t<year>' + str(full_result['year']) + '</year>\n')
    #Status, Code, Studio,Country, - unbenutzt    
    nfo_content_tvshow.append('\t<status></status>\n')
    nfo_content_tvshow.append('\t<code></code>\n')
    nfo_content_tvshow.append('\t<studio>' + str(full_result['studio']) + '</studio>\n')
    nfo_content_tvshow.append('\t<country></country>\n')
    nfo_content_tvshow.append('\t<mpaa>' + full_result['mpaa'] + '</mpaa>\n')
    nfo_content_tvshow.append('\t<tag>' + str(full_result['tag']) + '</tag>\n')    
    #Cast/Actors
    if full_result['cast']:
        for casts in full_result['cast']:
            nfo_content_tvshow.append('\t<actor>\n')
            if casts['name']:
                nfo_content_tvshow.append('\t\t<name>' + str(casts['name']) + '</name>\n')
            if casts['role']:
             nfo_content_tvshow.append('\t\t<role>' + str(casts['role']) + '</role>\n')
            if casts['order']:
             nfo_content_tvshow.append('\t\t<order>' + str(casts['order']) + '</order>\n')
            #if casts['thumbnail']:
            #    nfo_content_tvshow.append('\t\t<thumb>' + str(casts['thumbnail']) + '</thumb>\n')
            nfo_content_tvshow.append('\t</actor>\n')
    #Extra01 - TVShow Pfad
    if full_result['file']:        
        nfo_content_tvshow.append('\t<tvshowpath>' + full_result['file'] + '</tvshowpath>\n')
    #Extra02 - Scraper Helper
    nfo_content_tvshow.append('\t<tvshowsource>https://www.thesportsdb.com/league/' + spdb_vdb_id + '</tvshowsource>\n')
    #Ende TVSHOW
    nfo_content_tvshow.append('</tvshow>\n')
    return nfo_content_tvshow
