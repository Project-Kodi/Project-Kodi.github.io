# -*- coding: UTF-8 -*-
#
# Copyright (C) 2024, Project Kodi => Peter Streimelweger
#
# Addon: The Sports Database Python - metadata.thesportsdb.python
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# Code attribution:
# core based on metadata.tvshows.thesportsdb.python by pkscout
# and metadata.tvmaze scrapper by Roman Miroshnychenko aka Roman V.M.
# and the metadata.tvshows.themoviedb.org.python scraper by Team Kodi
# all created by improvements to metadata.thesportsdb.com 2015 from Project Kodi (peter0123)
# The owner "ZAG" of TheSportsdb.com!! He supported all of the people mentioned!
# Big praise, it's been 10 years, we'll soon have sports series integrated into Kodi!
#
# Kodi Forum: https://forum.kodi.tv/showthread.php?tid=256198
# Support - Join us at Discord: TheDataDB => https://discord.com/channels/481047912286257152/481047912286257155
# Source and Information, see  https://project-kodi.github.io/ or https://github.com/Project-Kodi/Project-Kodi.github.io/
# Emergency contact to continue the scraper: kodi-support@streimelweger.eu
# pylint: disable=missing-docstring

"""
Provides a context manager that writes extended debugging info
in the Kodi log on unhandled exceptions
"""
from __future__ import absolute_import, unicode_literals

import inspect
from contextlib import contextmanager
from platform import uname
from pprint import pformat

import xbmc

from .utils import logger

try:
    from typing import (
        Text,
        Generator,
        Callable,
        Dict,
        Any,
    )  # pylint: disable=unused-import
except ImportError:
    pass


def _format_vars(variables):
    # type: (Dict[Text, Any]) -> Text
    """
    Format variables dictionary

    :param variables: variables dict
    :type variables: dict
    :return: formatted string with sorted ``var = val`` pairs
    :rtype: str
    """
    var_list = [
        (var, val)
        for var, val in variables.items()
        if not (var.startswith("__") or var.endswith("__"))
    ]
    var_list.sort(key=lambda i: i[0])
    lines = []
    for var, val in var_list:
        lines.append("{0} = {1}".format(var, pformat(val)))
    return "\n".join(lines)


@contextmanager
def debug_exception(logger_func=logger.error):
    # type: (Callable[[Text], None]) -> Generator[None]
    """
    Diagnostic helper context manager

    It controls execution within its context and writes extended
    diagnostic info to the Kodi log if an unhandled exception
    happens within the context. The info includes the following items:

    - System info
    - Kodi version
    - Module path.
    - Code fragment where the exception has happened.
    - Global variables.
    - Local variables.

    After logging the diagnostic info the exception is re-raised.

    Example::

        with debug_exception():
            # Some risky code
            raise RuntimeError('Fatal error!')

    :param logger_func: logger function which must accept a single argument
        which is a log message.
    """
    try:
        yield
    except Exception as exc:
        frame_info = inspect.trace(5)[-1]
        logger_func(
            "*** Unhandled exception detected: {} {} ***".format(
                type(exc), exc)
        )
        logger_func("*** Start diagnostic info ***")
        logger_func("System info: {0}".format(uname()))
        logger_func("OS info: {0}".format(
            xbmc.getInfoLabel("System.OSVersionInfo")))
        logger_func(
            "Kodi version: {0}".format(
                xbmc.getInfoLabel("System.BuildVersion"))
        )
        logger_func("File: {0}".format(frame_info[1]))
        context = ""
        if frame_info[4] is not None:
            for i, line in enumerate(frame_info[4], frame_info[2] - frame_info[5]):
                if i == frame_info[2]:
                    context += "{0}:>{1}".format(str(i).rjust(5), line)
                else:
                    context += "{0}: {1}".format(str(i).rjust(5), line)
        logger_func("Code context:\n" + context)
        logger_func("Global variables:\n" +
                    _format_vars(frame_info[0].f_globals))
        logger_func("Local variables:\n" +
                    _format_vars(frame_info[0].f_locals))
        logger_func("**** End diagnostic info ****")
        raise exc
