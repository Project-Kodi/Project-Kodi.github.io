# -*- coding: UTF-8 -*-
#
# Copyright (C) 2024, Project Kodi
#
# Addon: The Sports Database Python - metadata.thesportsdb.python
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# Code attribution:
# core based on metadata.tvshows.thesportsdb.python by pkscout
# and metadata.tvmaze scrapper by Roman Miroshnychenko aka Roman V.M.
# and the metadata.tvshows.themoviedb.org.python scraper by Team Kodi
# all created by improvements to metadata.thesportsdb.com 2015 from Project Kodi (peter0123)
# The owner "ZAG" of TheSportsdb.com!! He supported all of the people mentioned!
# Big praise, it's been 10 years, we'll soon have sports series integrated into Kodi!
#
# Support only here: https://tsdb.club/Thread-Support-The-Sports-Database-Python-for-Kodi-from-author
# Use our NFO Generator: https://tsdb.club/nfogenerator.php
# Kodi Forum: https://forum.kodi.tv/showthread.php?tid=256198
# Support - Join us at Discord: TheDataDB => https://discord.com/channels/481047912286257152/481047912286257155
# Source and Information, see  https://project-kodi.github.io/ or https://github.com/Project-Kodi/Project-Kodi.github.io/
# Emergency contact to continue the scraper: kodi-support@streimelweger.eu
# pylint: disable=missing-docstring


"""Misc utils"""

from __future__ import absolute_import, unicode_literals

# import os
# import re
import xbmc
from xbmcaddon import Addon
# import urllib.parse
# import xbmcvfs
# import json
from datetime import datetime
from . import settings
# from .tsdb import get_nfo_tvshow_cast, get_nfo_episode_cast, get_nfo_episode_cast2
try:
    from typing import Text, Optional, Any, Dict  # pylint: disable=unused-import
except ImportError:
    pass

# Addon Settings - Verbose logging extreme
verboselog_adv = settings.VERBOSELOGADV
overwrite_nfo = settings.OVERWRITENFO

# Addon Data ?
ADDON_ID = "metadata.tvshows.thesportsdb.python"
ADDON = Addon()

# Addon Infos
# self_addon_name = ADDON.getAddonInfo("name")
# self_addon_id = ADDON.getAddonInfo("id")
# self_addon_version = ADDON.getAddonInfo("version")
# self_addon_providername = ADDON.getAddonInfo("author")

TimeStamp = datetime.now().strftime("%d-%m-%Y %H:%M:%S")
RepositoryInfo = "https://Project-Kodi.github.io/"


class logger:
    log_message_prefix = "[{} ({})]: ".format(
        ADDON_ID, ADDON.getAddonInfo("version"))

    @staticmethod
    def log(message, level=xbmc.LOGDEBUG):
        # type: (Text, int) -> None
        if isinstance(message, bytes):
            message = message.decode("utf-8")
        message = logger.log_message_prefix + message
        xbmc.log(message, level)

    @staticmethod
    def info(message):
        # type: (Text) -> None
        logger.log(message, xbmc.LOGINFO)

    @staticmethod
    def error(message):
        # type: (Text) -> None
        logger.log(message, xbmc.LOGERROR)

    @staticmethod
    def debug(message):
        # type: (Text) -> None
        logger.log(message, xbmc.LOGDEBUG)


def url_fix(url):
    # type: (Text) -> Text
    """
    fixes the URL from the API results to remove escaping slashes
    """
    if url:
        return url.replace("\/", "/")
    else:
        return ""
