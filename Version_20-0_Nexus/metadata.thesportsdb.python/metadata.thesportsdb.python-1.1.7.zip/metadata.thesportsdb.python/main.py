# -*- coding: UTF-8 -*-
#
# Copyright (C) 2024, Project Kodi
#
# Addon: The Sports Database Python - metadata.thesportsdb.python
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# Code attribution:
# core based on metadata.tvshows.thesportsdb.python by pkscout
# and metadata.tvmaze scrapper by Roman Miroshnychenko aka Roman V.M.
# and the metadata.tvshows.themoviedb.org.python scraper by Team Kodi
# all created by improvements to metadata.thesportsdb.com 2015 from Project Kodi (peter0123)
# The owner "ZAG" of TheSportsdb.com!! He supported all of the people mentioned!
# Big praise, it's been 10 years, we'll soon have sports series integrated into Kodi!
#
# Support only here: https://tsdb.club/Thread-Support-The-Sports-Database-Python-for-Kodi-from-author
# Use our NFO Generator: https://tsdb.club/nfogenerator.php
# Kodi Forum: https://forum.kodi.tv/showthread.php?tid=256198
# Support - Join us at Discord: TheDataDB => https://discord.com/channels/481047912286257152/481047912286257155
# Source and Information, see  https://project-kodi.github.io/ or https://github.com/Project-Kodi/Project-Kodi.github.io/
# Emergency contact to continue the scraper: kodi-support@streimelweger.eu
# pylint: disable=missing-docstring


from __future__ import absolute_import

import sys

from libs.actions import router
from libs.debugger import debug_exception

if __name__ == "__main__":
    with debug_exception():
        router(sys.argv[2][1:])
