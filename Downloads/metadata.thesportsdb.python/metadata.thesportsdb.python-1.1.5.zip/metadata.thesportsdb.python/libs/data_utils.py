# -*- coding: UTF-8 -*-
#
# Copyright (C) 2024, Project Kodi => Peter Streimelweger
#
# Addon: The Sports Database Python - metadata.thesportsdb.python
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# Code attribution:
# core based on metadata.tvshows.thesportsdb.python by pkscout
# and metadata.tvmaze scrapper by Roman Miroshnychenko aka Roman V.M.
# and the metadata.tvshows.themoviedb.org.python scraper by Team Kodi
# all created by improvements to metadata.thesportsdb.com 2015 from Project Kodi (peter0123)
# The owner "ZAG" of TheSportsdb.com!! He supported all of the people mentioned!
# Big praise, it's been 10 years, we'll soon have sports series integrated into Kodi!
#
# Kodi Forum: https://forum.kodi.tv/showthread.php?tid=256198
# Support - Join us at Discord: TheDataDB => https://discord.com/channels/481047912286257152/481047912286257155
# Source and Information, see  https://project-kodi.github.io/ or https://github.com/Project-Kodi/Project-Kodi.github.io/
# Emergency contact to continue the scraper: kodi-support@streimelweger.eu
# pylint: disable=missing-docstring


"""Functions to process data"""

from __future__ import absolute_import, unicode_literals

import os
import re
import json
import xbmc
import xbmcvfs
from xbmc import Actor
from xbmcaddon import Addon
from collections import namedtuple
from .utils import url_fix, logger
from . import cache, tsdb, settings, api_utils
from urllib.request import urlretrieve
from urllib.request import urlopen
import urllib.error
import urllib.parse
import datetime
from datetime import datetime
import time


try:
    from typing import Optional, Text, Dict, List, Any  # pylint: disable=unused-import
    from xbmcgui import ListItem  # pylint: disable=unused-import

    InfoType = Dict[Text, Any]  # pylint: disable=invalid-name
except ImportError:
    pass

# Addon Settings - API Version/Add Date to Episode Title/Exclude League/Verbose logging extreme
api_version = settings.APIVERSION
change_ep_title = settings.CHANGEEPTITLE
change_ep_title_excl = settings.CHANGEEPTITLEEXCL
verboselog_adv = settings.VERBOSELOGADV
enab_season_poster_overw = settings.ENABSEASONPOSTEROVERW
enab_character_art = settings.ENABCHARACTERART
enab_character_art_version = settings.ENABCHARACTERARTVERSION
character_art_switch_name = settings.CHARACTERARTSWITCHNAME
write_character_art_path = settings.WRITECHRACTERARTPATH
write_character_art_own_path = settings.WRITECHRACTERARTOWNPATH
overwrite_nfo = settings.OVERWRITENFO

# Addon Infos
ADDON_ID = "metadata.tvshows.thesportsdb.python"
ADDON = Addon()
self_addon_name = ADDON.getAddonInfo("name")
self_addon_id = ADDON.getAddonInfo("id")
self_addon_version = ADDON.getAddonInfo("version")
self_addon_providername = ADDON.getAddonInfo("author")

TimeStamp = datetime.now().strftime("%d-%m-%Y %H:%M:%S")
RepositoryInfo = "https://Project-Kodi.github.io/"


# Regular expressions for various parsing
SHOW_ID_REGEXPS = [r"(thesportsdb)\.com/league/(\d+)"]
YOUTUBE_REGEXP = r"v=(.*)"

TAG_RE = re.compile(r"<[^>]+>")
CLEAN_PLOT_REPLACEMENTS = (
    ("<b>", "[B]"),
    ("</b>", "[/B]"),
    ("<i>", "[I]"),
    ("</i>", "[/I]"),
    ("</p><p>", "[CR]"),
)

UrlParseResult = namedtuple("UrlParseResult", ["provider", "show_id"])


# Function: Remove all control characters
def control_characters(dirty_str):
    clean_str = re.sub(r"[\x00-\x1f]", "", str(dirty_str))
    return clean_str


# Get correct TVShow
def nfo_correct_tvshow(nfo_str_League, spdb_vdb_id, typnfo, season_list):
    if verboselog_adv:
        logger.debug("Start function: nfo_correct_tvshow")
        logger.debug('nfo_str_League parm:  "{}"'.format(nfo_str_League))
        logger.debug('spdb_vdb_id parm:  "{}"'.format(spdb_vdb_id))
        logger.debug('season_list parm:  "{}"'.format(season_list))
    nfo_kodi_vdb_id = ""

    payload = {
        "jsonrpc": "2.0",
        "method": "VideoLibrary.GetTVShows",
        "params": {
            "filter": {"field": "title", "operator": "is", "value": nfo_str_League},
            "limits": {"start": 0, "end": 1},
            "properties": ["title", "file"],
        },
        "id": "libTvShows",
    }

    try:
        info = json.loads(xbmc.executeJSONRPC(json.dumps(payload)))
        result = info["result"]
        nfo_full_result = info["result"]["tvshows"]
        nfo_path = nfo_full_result[0]["file"]
        nfo_kodi_vdb_id = nfo_full_result[0]["tvshowid"]
        nfo_title = nfo_full_result[0]["title"]

        if verboselog_adv:
            logger.debug(
                'function: nfo_full_result - RPC - TRY - Info:  "{}"'.format(
                    nfo_full_result
                )
            )
            logger.debug(
                "function: nfo_full_result - RPC => nfo_path: %s " % nfo_path)
            logger.debug(
                "function: nfo_full_result - RPC => nfo_kodi_vdb_id: %s " % nfo_kodi_vdb_id)
            logger.debug(
                "function: nfo_full_result - RPC => nfo_title: %s " % nfo_title)

    except:
        if verboselog_adv:
            logger.debug("function: nfo_correct_tvshow - RPC - except:")

    if verboselog_adv:
        logger.debug(
            'Correct Kodi VideoDatabase TVShow ID:  "{}"'.format(spdb_vdb_id))
        logger.debug(
            'Correct Kodi VideoDatabase nfo_path:  "{}"'.format(nfo_path))
        logger.debug(
            'Correct Kodi VideoDatabase nfo_kodi_vdb_id:  "{}"'.format(
                nfo_kodi_vdb_id)
        )
        logger.debug(
            'Correct Kodi VideoDatabase nfo_title:  "{}"'.format(nfo_title))

    if typnfo == 'tvshow':
        # typnfo gegen string bei fuc aufruf austauschen!
        # Call function for NFO => tvshow //
        if verboselog_adv:
            logger.debug('CALL NFO => TVSHOW')
        write_nfo_get_filepath_content(
            "tvshow", nfo_path, nfo_title, nfo_kodi_vdb_id, nfo_full_result, spdb_vdb_id, season_list)
    elif typnfo == 'season':
        # Call function for NFO => season
        if verboselog_adv:
            logger.debug('CALL NFO => SEASON')
        write_nfo_get_filepath_content(
            "season", nfo_path, nfo_title, nfo_kodi_vdb_id, nfo_full_result, spdb_vdb_id, season_list)
    elif typnfo == 'episode':
        # Call function for NFO => episode
        if verboselog_adv:
            logger.debug('CALL NFO => EPISODE')
        write_nfo_get_filepath_content(
            "episode", nfo_path, nfo_title, nfo_kodi_vdb_id, nfo_full_result, spdb_vdb_id, season_list)


# Function: Write *.nfo file and fill it with content
def write_nfo_file_msg(filepathfull, filecontent):
    if verboselog_adv:
        logger.debug("Start function: write_nfo_file_msg")
        logger.debug('Write *.nfo Data to:  "{}"'.format(filepathfull))
        logger.debug('Write *.nfo Data content:  "{}"'.format(filecontent))
    index = 0
    # NFO - IF File exist and overwrite is off
    if verboselog_adv:
        logger.debug(
            'overwrite_nfo (Addon Setting):  "{}"'.format(overwrite_nfo))
        logger.debug('xbmcvfs.exists:  "{}"'.format(
            xbmcvfs.exists(filepathfull)))

    if xbmcvfs.exists(filepathfull) and not overwrite_nfo:
        logger.debug("NFO File exist and overwrite is off - Addon Setting")
    else:
        # GIbt es den Pfad, sonst vorher anlegen
        if filepathfull.find("/") > 0:
            logger.debug("write_nfo_file: Slash or Backslah: / ")
            searchlist = filepathfull.rsplit("/", 1)
        elif filepathfull.find("\\") > 0:
            logger.debug("write_nfo_file: Slash or Backslah: \\ ")
            searchlist = filepathfull.rsplit("\\", 1)
 # Add here with one \
        filepathfull_help = searchlist[0]
        # Existiert der Pfad nicht?
        if xbmcvfs.exists(filepathfull):
            logger.debug("write_nfo_file: Pfad existiert")
        else:
            xbmcvfs.mkdirs(filepathfull_help)
            logger.debug(
                'write_nfo_file: MKDIRS:  "{}"'.format(filepathfull_help))
        # Write NFO
        logger.debug("NFO File write is ok - Addon Setting")
        with xbmcvfs.File(filepathfull, "w") as f:
            result = f.write(
                '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
            )
            f.write("<!-- Created by " + self_addon_name + " Version " + self_addon_version + " | Provider: " + self_addon_providername +
                    " | Addon: " + self_addon_id + " | Repository: " + RepositoryInfo + " | Created on " + TimeStamp + " -->\n")
            while index < len(filecontent):
                f.write(str(filecontent[index]) + "")
                index += 1
            f.close()
            if result:
                logger.debug("write_nfo_file: OK")
            else:
                logger.debug("write_nfo_file: ERROR")
        logger.debug('Write *.nfo Content: "{}"'.format(filecontent))


def write_nfo_get_filepath_content(media_type, media_path, media_name, kodi_vdb_id, media_result, spdb_vdb_id, season_list):
    logger.debug("Start function: write_nfo_get_filepath_content")
    if verboselog_adv:
        logger.debug('media_type: "{}"'.format(media_type))
        logger.debug('media_path: "{}"'.format(media_path))
        logger.debug('media_name: "{}"'.format(media_name))
        logger.debug('kodi_vdb_id: "{}"'.format(kodi_vdb_id))
        logger.debug('League ID => spdb_vdb_id: "{}"'.format(spdb_vdb_id))
        logger.debug('media_result: "{}"'.format(media_result))
    # Mediatype => tvshow
    if media_type == "tvshow":
        logger.debug(
            "function: write_nfo_get_filepath_content => Auswahl TVSHOW")

        # Ausgabe im Serien Ordner
        # Wenn Ausgabe im Serien Ordner oder eigener Pfad, write_nfo_default = true
        if settings.WRITENFODEFAULT:
            logger.debug("Auswahl: NFO im Serien Ordner speichern")
            # Dateiname = write_nfo_tvshow_filename // (tvshowtitle).nfo // tvshow.nfo default 2
            if settings.WRITENFOTVSHOWFILENAME == "1":
                logger.debug(
                    "Auswahl NFO im Serien Ordner + : (tvshowtitle).nfo")
                # Dateiname und  Pfad ändern für NFO [(tvshowtitle).nfo]
                filepathtvshow = media_path
                filepathtvshow = os.path.join(filepathtvshow)
                logger.debug('filepathtvshow: "{}"'.format(filepathtvshow))
                nfofilenametvshow = media_name
                logger.debug('title: "{}"'.format(nfofilenametvshow))
                nfofilenametvshow = nfofilenametvshow + ".nfo"
                logger.debug(
                    'nfofilenametvshow: "{}"'.format(nfofilenametvshow))
                nfofilenametvshow = filepathtvshow + nfofilenametvshow
                logger.debug(
                    'nfofilenametvshow: "{}"'.format(nfofilenametvshow))
                # NFO SCHREIBEN
                write_nfo_file_msg(
                    nfofilenametvshow,
                    create_nfo_content_tvshow(kodi_vdb_id, spdb_vdb_id),
                )

            # Dateiname = write_nfo_tvshow_filename // (tvshowtitle).nfo // tvshow.nfo default 2
            elif settings.WRITENFOTVSHOWFILENAME == "2":
                logger.debug("Auswahl NFO im Serien Ordner +: tvshow.nfo")
                filepathtvshow = media_path
                filepathtvshow = os.path.join(filepathtvshow)
                logger.debug('filepathtvshow: "{}"'.format(filepathtvshow))
                nfofilenametvshow = "tvshow.nfo"
                logger.debug(
                    'nfofilenametvshow: "{}"'.format(nfofilenametvshow))
                nfofilenametvshow = filepathtvshow + nfofilenametvshow
                logger.debug(
                    'nfofilenametvshow: "{}"'.format(nfofilenametvshow))
                # NFO SCHREIBEN
                write_nfo_file_msg(
                    nfofilenametvshow,
                    create_nfo_content_tvshow(kodi_vdb_id, spdb_vdb_id),
                )

        # Wenn Ausgabe im Serien Ordner oder eigener Pfad, write_nfo_default = false
        else:
            logger.debug("Auswahl: NFO in eigenen Ordner speichern")

            # Dateiname = write_nfo_tvshow_filename // (tvshowtitle).nfo // tvshow.nfo default 2
            if settings.WRITENFOTVSHOWFILENAME == "1":
                logger.debug("Auswahl eigener Pfad + : (tvshowtitle).nfo")
                # Eingegebener Pfad
                nfofilenametvshowp = settings.WRITENFOWNTVSHOWPATH
                logger.debug('Auswahl eigener Pfad: "{}"'.format(
                    nfofilenametvshowp))
                nfofilenametvshown = media_name
                logger.debug('title: "{}"'.format(nfofilenametvshown))
                testy = str(media_name)
                nfofilenametvshowf = testy + ".nfo"
                nfofilenametvshowp = xbmcvfs.translatePath(nfofilenametvshowp)
                nfofilenametvshow = os.path.join(
                    nfofilenametvshowp, testy, nfofilenametvshowf)
                logger.debug(
                    'Auswahl eigener Pfad TEST X: "{}"'.format(nfofilenametvshow))
                # NFO SCHREIBEN
                write_nfo_file_msg(
                    nfofilenametvshow,
                    create_nfo_content_tvshow(kodi_vdb_id, spdb_vdb_id),
                )

            # Dateiname = write_nfo_tvshow_filename // (tvshowtitle).nfo // tvshow.nfo default 2
            elif settings.WRITENFOTVSHOWFILENAME == "2":
                logger.debug("Auswahl eigener Pfad +: tvshow.nfo")
                # Eingegebener Pfad
                nfofilenametvshowp = settings.WRITENFOWNTVSHOWPATH
                logger.debug('Auswahl eigener Pfad: "{}"'.format(
                    nfofilenametvshowp))
                # Eingegebener Pfad + Dateiname
                testx = str(media_name)
                nfofilenametvshowp = xbmcvfs.translatePath(nfofilenametvshowp)
                nfofilenametvshow = os.path.join(
                    nfofilenametvshowp, testx, 'tvshow.nfo')
                logger.debug(
                    'Auswahl eigener Pfad TEST X: "{}"'.format(nfofilenametvshow))
                # NFO SCHREIBEN
                write_nfo_file_msg(
                    nfofilenametvshow,
                    create_nfo_content_tvshow(kodi_vdb_id, spdb_vdb_id),
                )

    # Auswahl SEASON => Hier zu beachten, es gibt mehrere season pro tvshow
    # WRITENFOSEASONFILENAME = source_settings.get(    "write_nfo_season_filename", ADDON.getSettingString("write_nfo_season_filename"))
    elif media_type == "season":
        logger.debug(
            "function: write_nfo_get_filepath_content => Auswahl SEASON")

        # Get all seasons directorys
        payload = {
            "jsonrpc": "2.0",
            "method": "Files.GetDirectory",
            "params": {
                "properties": ["showtitle", "title", "season", "episode", "file"],
                "directory": media_path,
                "media": "video",
            },
            "id": 1,
        }
        info = json.loads(xbmc.executeJSONRPC(json.dumps(payload)))
        try:
            info_files = info["result"]["files"]
            if verboselog_adv:
                logger.debug("NEW PATH TEST result:  %s " % info)
            ret = []
            for r in info_files:
                ret.append(r)
        except:
            logger.debug("Files.GetDirectory - Result: NOTHING EXCEPT res")

        # Season Loop from Get all seasons directorys
        # db_path_entry - Result loop: db_path_entry: "{'file': 'smb://192.168.1.120/Sport-Videos/Serien-tsdb/MotoGP/Season 2010/', 'filetype': 'directory', 'label': 'Season 2010', 'title': '', 'type': 'unknown'}"
        for db_path_entry in ret:
            logger.debug(
                'Files.GetDirectory - db_path_entry - Result loop: db_path_entry: "{}"'.format(
                    db_path_entry
                )
            )
            dp_path_entry_label = db_path_entry["label"]
            # Alle Zeichen bis auf 0-9 und - erhalten
            dp_path_entry_label_s = re.sub(
                "[^0-9-]", "", db_path_entry["label"])
            dp_path_tvshow_season = db_path_entry["file"]
            seasonid_db = []
            # Get Season ID
            payload3 = {"jsonrpc": "2.0", "method": "VideoLibrary.GetSeasons", "params": {
                "tvshowid": kodi_vdb_id, "limits": {"end": 120, "start": 0}}, "id": 1}
            info3 = json.loads(xbmc.executeJSONRPC(json.dumps(payload3)))
            try:
                info_files3 = info3["result"]["seasons"]
                logger.debug('Get Season ID info_files3: "{}"'.format(info_files3))
                ###WARNUNG WENN SEASON NICHT ERKANNT WIRD!
                #Check if anything found!
                if not info_files3:
                    # Default: [{'label': '2021-2022', 'seasonid': 31}, {'label': '2022-2023', 'seasonid': 32}, {'label': '2024-2025', 'seasonid': 34}]"
                    # If no Season detect: []
                    #Was genau ist der Grund, genauer schreiben, wirklich season name??
                    info_str = 'Label: ' + db_path_entry["label"] + ' | Path: ' + db_path_entry["file"] + ''                
                    logger.debug('Loop in Tv show - seasons - each season => fail, Season only in kodi db, but scraper fails to know the Season..wrong foldernaming, wrong episodename or check if : Change Episode Title => Exclude List "{}"'.format(info_str))
                    logger.info('NFO Export for Season: Kodi saved the season, but did not recognize any information about it, if you use the addon setting "Change Episode Title" add the League to the Exclude List, if not  please try a different folder name or check the episodes in it => information about: season | Path => "{}"'.format(info_str))
## CHECK HERE: sprint er zum nächsten Loop?                     
                    continue

                # Data found, normal Loop:
                else:
                    # Label suchen
                    for r in info_files3:
                        if verboselog_adv:
                            logger.debug('Label search => r-label: "{}"'.format(r["label"]))
                            logger.debug('Label search => db_path_entry-label_s: "{}"'.format(dp_path_entry_label_s))
                        if r["label"] == dp_path_entry_label_s:
                            seasonid_db = r["seasonid"]
                            logger.debug('Found correct seasonid_db: "{}"'.format(seasonid_db))

            except Exception as error:
                logger.debug(
                    'write_nfo_get_filepath_content =>  info_files3 => except: "{}"'.format(error))
                logger.debug(
                    'write_nfo_get_filepath_content =>  info_files3 => except: "{}"'.format(type(error)))
                logger.debug(
                    'write_nfo_get_filepath_content =>  info_files3 => except: "{}"'.format(error.args))
                #Change to next Loop Round                
                continue



            # remove all other chars
            dp_path_entry_label_clean = re.sub(
                "[^0-9]", "", dp_path_entry_label)
            #  cut [4}] &  make int
            try:
                season_nr_short = int(dp_path_entry_label_clean[:4])
                season_nr = int(dp_path_entry_label_clean)

                # Wenn Ausgabe im Serien Ordner (oder eigener Pfad), write_nfo_default = true
                if settings.WRITENFODEFAULT:
                    logger.debug("Auswahl: NFO im Serien Ordner speichern")
                    # Dateiname = write_nfo_season_filename // seasonXX.nfo // season.nfo default 2

                    if settings.WRITENFOSEASONFILENAME == "1":
                        logger.debug(
                            "Auswahl NFO im Serien Ordner + /seasonxx/ + : seasonXX.nfo")
                        # NFO SCHREIBEN
                        dp_path_help = 'season' + str(season_nr_short) + '.nfo'
                        dp_path_tvshow_season = os.path.join(
                            media_path, dp_path_help)
                        # dp_path_tvshow_season = xbmcvfs.translatePath(media_path + "season" + season_nr + ".nfo")
                        logger.debug('WRITE PATH FOR SEASON NFO: "{}"'.format(
                            dp_path_tvshow_season))
                        write_nfo_file_msg(dp_path_tvshow_season, create_nfo_content_season(
                            kodi_vdb_id, spdb_vdb_id, seasonid_db, dp_path_tvshow_season),)

                    # Dateiname = write_nfo_season_filename // seasonXX.nfo // season.nfo default 2
                    elif settings.WRITENFOSEASONFILENAME == "2":
                        logger.debug(
                            "Auswahl NFO im Serien Ordner +: season.nfo")
                        # NFO SCHREIBEN
                        dp_path_tvshow_season = os.path.join(
                            dp_path_tvshow_season, 'season.nfo')
                        # dp_path_tvshow_season = xbmcvfs.translatePath(dp_path_tvshow_season + "season.nfo")
                        logger.debug('WRITE PATH FOR SEASON NFO: "{}"'.format(
                            dp_path_tvshow_season))
                        write_nfo_file_msg(dp_path_tvshow_season, create_nfo_content_season(
                            kodi_vdb_id, spdb_vdb_id, seasonid_db, dp_path_tvshow_season),)

                # Wenn eigener Pfad (oder Ausgabe im Serien Ordner), write_nfo_default = false
                # WRITENFOWNSEASONPATH = source_settings.get(    "write_nfo_own_season_path", ADDON.getSettingString("write_nfo_own_season_path"))
                else:
                    logger.debug("Auswahl: NFO in eigenen Ordner speichern")

                    # Dateiname = write_nfo_season_filename // seasonXX.nfo // season.nfo default 2
                    if settings.WRITENFOSEASONFILENAME == "1":
                        logger.debug(
                            "Auswahl eigener Pfad + /tvshwow/ + : seasonXX.nfo")
                        # Eingegebener Pfad
                        nfofilenameseasonp = settings.WRITENFOWNSEASONPATH
                        logger.debug('Auswahl eigener Pfad: "{}"'.format(
                            nfofilenameseasonp))
                        # => TV SHow Folder in Path.. eigener pfad/tvshow/seasonxx.nfo
                        nfofilenameseasonp = xbmcvfs.translatePath(
                            nfofilenameseasonp)
                        dp_path_help = 'season' + str(season_nr_short) + '.nfo'
                        # dp_path_tvshow_season = nfofilenameseasonp + media_name + "/" + season_nr + ".nfo"
                        dp_path_tvshow_season = os.path.join(
                            nfofilenameseasonp, media_name, dp_path_help)

                        logger.debug('WRITE PATH FOR SEASON NFO: "{}"'.format(
                            dp_path_tvshow_season))
                        # NFO SCHREIBEN
                        write_nfo_file_msg(dp_path_tvshow_season, create_nfo_content_season(
                            kodi_vdb_id, spdb_vdb_id, seasonid_db, dp_path_tvshow_season),)

                    # Dateiname = write_nfo_season_filename // seasonXX.nfo // season.nfo default 2
                    elif settings.WRITENFOSEASONFILENAME == "2":
                        logger.debug(
                            "Auswahl eigener Pfad + /tvshwow/seasonXX/ + : season.nfo")
                        # Eingegebener Pfad
                        nfofilenameseasonp = settings.WRITENFOWNSEASONPATH
                        logger.debug('Auswahl eigener Pfad: "{}"'.format(
                            nfofilenameseasonp))
                        # => TV SHow Folder in Path.. eigener pfad/tvshow/seasonxx/season.nfo
                        nfofilenameseasonp = xbmcvfs.translatePath(
                            nfofilenameseasonp)
                        # dp_path_tvshow_season = nfofilenameseasonp + media_name + '/' + dp_path_entry_label + '/' + "season.nfo"
                        dp_path_tvshow_season = os.path.join(
                            nfofilenameseasonp, media_name, dp_path_entry_label, 'season.nfo')
                        logger.debug('WRITE PATH FOR SEASON NFO: "{}"'.format(
                            dp_path_tvshow_season))
                        # NFO SCHREIBEN
                        write_nfo_file_msg(dp_path_tvshow_season, create_nfo_content_season(
                            kodi_vdb_id, spdb_vdb_id, seasonid_db, dp_path_tvshow_season),)

            except Exception as error:
                logger.debug(
                    'Season Loop from Get all seasons directorys => except: "{}"'.format(error))
                logger.debug(
                    'Season Loop from Get all seasons directorys => except: "{}"'.format(type(error)))
                logger.debug(
                    'Season Loop from Get all seasons directorys => except: "{}"'.format(error.args))
                continue

    # Auswahl EPISODE  => Hier zu beachten, es gibt mehrere episoden je season und tvshow
    # WRITENFOEPISODEFILENAME = source_settings.get(    "write_nfo_episode_filename", ADDON.getSettingString("write_nfo_episode_filename"))
    elif media_type == "episode":
        logger.debug(
            "function: write_nfo_get_filepath_content => Auswahl EPISODE")

        # Get all seasons directorys from kodi db/os
        payload = {
            "jsonrpc": "2.0",
            "method": "Files.GetDirectory",
            "params": {
                "properties": ["showtitle", "title", "season", "episode", "file"],
                "directory": media_path,
                "media": "video",
            },
            "id": 1,
        }
        info = json.loads(xbmc.executeJSONRPC(json.dumps(payload)))
        try:
            info_files = info["result"]["files"]
            if verboselog_adv:
                logger.debug("NEW PATH TEST result episode:  %s " % info)
            ret = []
            for r in info_files:
                ret.append(r)
        except:
            logger.debug(
                "Files.GetDirectory - Result: NOTHING EXCEPT episode res")
        # paths from seasons
        for db_path_entry in ret:
            logger.debug(
                'Files.GetDirectory - db_path_entry - episode - Result loop: db_path_entry: "{}"'.format(db_path_entry))
            logger.debug(
                'Files.GetDirectory - db_path_entry - episode - Result loop: db_path_entry file: "{}"'.format(db_path_entry['file']))
            dp_path_entry_label = db_path_entry["label"]

            # Für jeden Tvshow Seasons Ordner, RPC Call, welche Episoden liegen darin
            payload2 = {
                "jsonrpc": "2.0",
                "method": "Files.GetDirectory",
                "params": {
                    "properties": ["showtitle", "title", "season", "episode", "file"],
                    "directory": db_path_entry['file'],
                    "media": "video"
                },
                "type": "episode",
                "id": 1
            }
            info2 = json.loads(xbmc.executeJSONRPC(json.dumps(payload2)))
            info_files2 = info2["result"]["files"]

            for r2 in info_files2:
                logger.debug(
                    'Loop in Tv show - season - each episode: "{}"'.format(r2))
                try:
                    # If Kodi do not known infos about the episode, but save this in his database => type': 'unknown' + episode and season = -1 / or not exists.
                    # Then = no episode, id or season here!
                    if r2["type"] == 'unknown':
                        logger.debug(
                            'Loop in Tv show - season - each episode => fail, Episode only in kodi db, but scraper fails to know the episode..wrong filenaming,.. "{}"'.format(r2))
                        logger.info(
                            'NFO Export for Episode: Kodi saved the episode, but did not recognize any information about it! If you use the addon setting "Change Episode Title" add the League to the Exclude List, if no season or episode of this league correct scrapt. Only one episode is not recognized? Please try a different file name => Video file: "{}"'.format(r2["file"]))

                    # Episode is known from kodi!
                    else:
                        logger.debug(
                            'Loop in Tv show - season - each episode => episode_nr: "{}"'.format(r2["episode"]))
                        episode_nr = r2["episode"]
                        episode_id = r2["id"]

                        # Wenn Ausgabe im Serien Ordner (oder eigener Pfad), write_nfo_default = true
                        if settings.WRITENFODEFAULT:
                            logger.debug(
                                "Auswahl: NFO im Serien Ordner speichern")

                            # Dateiname = write_nfo_episode_filename // (episodefilename).nfo default 1
                            if settings.WRITENFOEPISODEFILENAME == "1":
                                logger.debug(
                                    "Auswahl NFO im Serien Ordner  tvshow/seasonxx/(episodefilename).nfo")
                                dp_path_r2_file = r2["file"]
                                logger.debug(
                                    'Loop in Tv show - season - each episode: Problem r2file "{}"'.format(dp_path_r2_file))
                                # Get Filename
                                if dp_path_r2_file.find("/") > 0:
                                    logger.debug(
                                        "write_nfo_file dp_path_r2_file: Slash or Backslah: / ")
                                    dp_path_tvshow_episodef = dp_path_r2_file.rsplit(
                                        "/")[-1]
                                elif dp_path_r2_file.find("\\") > 0:
                                    logger.debug(
                                        "write_nfo_file dp_path_r2_file: Slash or Backslah: \\ ")
                                    dp_path_tvshow_episodef = dp_path_r2_file.rsplit(
                                        "\\")[-1]
                                logger.debug(
                                    'Loop in Tv show - season - each episode: dp_path_tvshow_episodef "{}"'.format(dp_path_tvshow_episodef))
                                # Create NFO Filename
                                res = dp_path_tvshow_episodef.rsplit('.', 1)
                                logger.debug(
                                    'Loop in Tv show - season - each episode: res "{}"'.format(res))
                                dp_path_tvshow_episodef = str(res[0]) + '.nfo'
                                logger.debug(
                                    'Loop in Tv show - season - each episode: dp_path_tvshow_episodef end "{}"'.format(dp_path_tvshow_episodef))
                                dp_path_tvshow_episode = os.path.join(
                                    db_path_entry['file'], dp_path_tvshow_episodef)
                                logger.debug('WRITE PATH FOR EPISODE NFO: "{}"'.format(
                                    dp_path_tvshow_episode))
                                write_nfo_file_msg(dp_path_tvshow_episode, create_nfo_content_episode(
                                    kodi_vdb_id, spdb_vdb_id, episode_nr, episode_id, dp_path_entry_label),)

                        # WRITENFOWNEPISODEPATH = source_settings.get("write_nfo_own_episode_path", ADDON.getSettingString("write_nfo_own_episode_path"))
                        else:
                            logger.debug(
                                "Auswahl: NFO in eigenen Ordner speichern")

                            # Dateiname = write_nfo_episode_filename // (episodefilename).nfo default 1
                            if settings.WRITENFOEPISODEFILENAME == "1":
                                logger.debug(
                                    "Auswahl: NFO in eigenen Ordner speichern + /tvshow/seasonxx/(episodefilename).nfo")

                                # Eingegebener Pfad
                                nfofilenameepisodep = settings.WRITENFOWNEPISODEPATH
                                logger.debug('Auswahl eigener Pfad: "{}"'.format(
                                    nfofilenameepisodep))
                                # Eingegebener Pfad +TVShow Folder/+ Season/ + Dateiname
                                nfofilenameseasonp = xbmcvfs.translatePath(
                                    nfofilenameepisodep)
                                dp_path_r2_file = r2["file"]
                                logger.debug(
                                    'Loop in Tv show - season - each episode: Problem r2file "{}"'.format(dp_path_r2_file))
                                # Create Filename
                                # Get Filename
                                if dp_path_r2_file.find("/") > 0:
                                    logger.debug(
                                        "write_nfo_file dp_path_r2_file: Slash or Backslah: / ")
                                    dp_path_tvshow_episodef = dp_path_r2_file.rsplit(
                                        "/")[-1]
                                elif dp_path_r2_file.find("\\") > 0:
                                    logger.debug(
                                        "write_nfo_file dp_path_r2_file: Slash or Backslah: \\ ")
                                    dp_path_tvshow_episodef = dp_path_r2_file.rsplit(
                                        "\\")[-1]
                                logger.debug(
                                    'Loop in Tv show - season - each episode: dp_path_tvshow_episodef "{}"'.format(dp_path_tvshow_episodef))
                                # Create NFO Filename
                                res = dp_path_tvshow_episodef.rsplit('.', 1)
                                logger.debug(
                                    'Loop in Tv show - season - each episode: res "{}"'.format(res))
                                dp_path_tvshow_episodef = str(res[0]) + '.nfo'
                                logger.debug(
                                    'Loop in Tv show - season - each episode: dp_path_tvshow_episodef end "{}"'.format(dp_path_tvshow_episodef))
                                # Build Path
                                dp_path_tvshow_episode = os.path.join(
                                    nfofilenameseasonp, media_name, dp_path_entry_label, dp_path_tvshow_episodef)
                                logger.debug('WRITE PATH FOR EPISODE NFO: "{}"'.format(
                                    dp_path_tvshow_episode))
                                # Send to writer..
                                logger.debug('WRITE PATH FOR EPISODE NFO: "{}"'.format(
                                    dp_path_tvshow_episode))
                                write_nfo_file_msg(dp_path_tvshow_episode, create_nfo_content_episode(
                                    kodi_vdb_id, spdb_vdb_id, episode_nr, episode_id, dp_path_entry_label),)

                except Exception as error:
                    logger.debug(
                        'Episode Season Loop from Get all seasons episodes directorys => except: "{}"'.format(error))
                    logger.debug(
                        'Episode Season Loop from Get all seasons episodes directorys => except: "{}"'.format(type(error)))
                    logger.debug(
                        'Episode Season Loop from Get all seasons episodes directorys => except: "{}"'.format(error.args))
                    continue






# HERE HERE => Season_id empty??? kommt von oben // Get Season ID info_files3: "[]"





# Function: NFO Content SEASON => https://kodi.wiki/view/NFO_files/Templates
def create_nfo_content_season(kodi_vdb_id, spdb_vdb_id, season_id, season_path):
    logger.debug("Start function: create_nfo_content_season")

    logger.debug(
        'Start function: create_nfo_content_season = season_id: "{}"'.format(season_id))

    # Get Season Infos
    payload = {
        "jsonrpc": "2.0",
        "method": "VideoLibrary.GetSeasonDetails",
        "params": {
            "properties": [
                "season",
                "showtitle",
                "playcount",
                "episode",
                "fanart",
                "thumbnail",
                "tvshowid",
                "watchedepisodes",
                "art",
                "userrating",
                "title",
            ],
            "seasonid": season_id,
        },
        "id": 1,
    }

    info = json.loads(xbmc.executeJSONRPC(json.dumps(payload)))
    full_result = info["result"]["seasondetails"]
    full_result_art = full_result["art"]
    if verboselog_adv:
        logger.debug(
            'NEW TEST full_result full_result "{}"'.format(full_result))
        logger.debug(
            'create_nfo_content_season // create_nfo_content_season full_result_art: "{}"'.format(full_result_art))

    # Get Infos from Cache about TV show if exists
    # Cache Infos:
    tvshow_info_cache = cache.load_show_info_from_cache(spdb_vdb_id)
    if tvshow_info_cache is None:
        logger.debug(
            "create_nfo_content_season => TV show info => no cache file found!")
    else:
        cache_use = 1
        strWebsite = tvshow_info_cache["strWebsite"]
        strFacebook = tvshow_info_cache["strFacebook"]
        strInstagram = tvshow_info_cache["strInstagram"]
        strTwitter = tvshow_info_cache["strTwitter"]
        strYoutube = tvshow_info_cache["strYoutube"]
        strRSS = tvshow_info_cache["strRSS"]
        strCountry = tvshow_info_cache["strCountry"]
        strFanart1 = tvshow_info_cache["strFanart1"]
        strFanart2 = tvshow_info_cache["strFanart2"]
        strFanart3 = tvshow_info_cache["strFanart3"]
        strFanart4 = tvshow_info_cache["strFanart4"]
        if verboselog_adv:
            logger.debug('create_nfo_content_season => TV show info => CACHE TVSHOW: "{}"'.format(
                tvshow_info_cache))

        # Get TV show Description
        season_plot = tvshow_info_cache["strDescription" + settings.LANGUAGE]
        logger.debug("Check if strDescription in Language: " +
                     settings.LANGUAGE + "")
        if not season_plot:
            season_plot = tvshow_info_cache["strDescriptionEN"]
        if season_plot:
            season_plot = _clean_plot(season_plot)
            season_plot = control_characters(season_plot)
            if verboselog_adv:
                logger.debug(
                    'create_nfo_content_season => TV show info => tvshow/season_plot: "{}"'.format(season_plot))

    # In Season, we use TV show Teams => TSDB Teams in League as Actor
    error = 0
    casts_nfo = get_nfo_tvshow_cast_normal(spdb_vdb_id, full_result)
    # TvShow Cast
    if casts_nfo == 'No data found':
        logger.debug('No TV show cast found!"{}"'.format(casts_nfo))
        error = 1

    # Get extra: tmp_strLeague
    nfo_season_casts = tsdb.get_nfo_tvshow_cast(spdb_vdb_id)
    # No data found
    if nfo_season_casts == 'No data found':
        logger.debug('nfo_season_casts => tmp_strLeague: No data found => "{}"'.format(
            nfo_season_casts))
        tmp_strLeague = 'No data found'
    # When we found data
    else:
        logger.debug('nfo_season_casts => tmp_strLeague: data found => "{}"'.format(
            nfo_season_casts))
        tmp_strLeague = nfo_season_casts[0]["strLeague"]
        tmp_strLeague.replace(" ", "_")

     # Anfang SEASON
    nfo_content_season = ["<season>\n"]
    # Titel
    if "title" in full_result:
        nfo_content_season.append(
            "\t<title>" + full_result["title"] + "</title>\n")
    if "showtitle" in full_result:
        nfo_content_season.append(
            "\t<showtitle>" + full_result["showtitle"] + "</showtitle>\n"
        )
    if "showtitle" in full_result:
        nfo_content_season.append(
            "\t<originaltitle>" +
            full_result["showtitle"] + "</originaltitle>\n"
        )
    if "sorttitle" in full_result:
        nfo_content_season.append(
            "\t<sorttitle>" + full_result["sorttitle"] + "</sorttitle>\n"
        )

    # Plot/Outline from Cache TV show.
    if season_plot:
        nfo_content_season.append(
            "\t<outline>" + season_plot + "</outline>\n"
        )
        nfo_content_season.append(
            "\t<plot>" + season_plot + "</plot>\n"
        )

    # Season
    if "season" in full_result:
        nfo_content_season.append(
            "\t<seasonnumber>" +
            str(full_result["season"]) + "</seasonnumber>\n"
        )

    if strCountry:
        nfo_content_season.append("\t<country>" + strCountry + "</country>\n")

    # Databse Kodi ID from Tv Show
    nfo_content_season.append("\t<id>" + str(kodi_vdb_id) + "</id>\n")
    # Database Number Sportsdb
    nfo_content_season.append(
        '\t<uniqueid default="true" type="tsdb"></uniqueid> <!--  no unique relay ID for season available at https://www.thesportsdb.com/ --> \n')
    nfo_content_season.append(
        '\t<uniqueid default="false" type="thesportsdb"></uniqueid> <!-- no unique relay ID for season available https://www.thesportsdb.com/ --> \n')
    nfo_content_season.append(
        '\t<tsdb></tsdb> <!--  no unique relay ID for season available https://www.thesportsdb.com/ --> \n')
    # Pictures
    if "tvshow.banner" in full_result_art:
        tmp_full_result_banner = urllib.parse.unquote(
            full_result_art["tvshow.banner"]).replace("image://", "")
        nfo_content_season.append(
            '\t<thumb aspect="banner">'
            + tmp_full_result_banner.replace(".jpg/", ".jpg")
            + '</thumb>\n'
        )
    if "'tvshow.fanart" in full_result_art:
        tmp_full_result_fanartl = urllib.parse.unquote(
            full_result_art["'tvshow.fanart"]).replace("image://", "")
        nfo_content_season.append(
            '\t<thumb aspect="landscape">'
            + tmp_full_result_fanartl.replace(".jpg/", ".jpg")
            + '</thumb>\n'
        )
    if "tvshow.poster" in full_result_art:
        tmp_full_result_poster = urllib.parse.unquote(
            full_result_art["tvshow.poster"]).replace("image://", "")
        nfo_content_season.append(
            '\t<thumb aspect="poster">'
            + tmp_full_result_poster.replace(".jpg/", ".jpg")
            + '</thumb>\n'
        )

    # Season Poster
    # <thumb aspect="poster" season="0" type="season">https://image.tmdb.org/t/p/original/65fnzCKkyx8xZPvmIf7PhhyXZI9.jpg</thumb>
    # <thumb aspect="poster" season="1" type="season">https://image.tmdb.org/t/p/original/tGII1c84fhml9jYclHJiB3Yy4Vc.jpg</thumb>

    # More Fanart!!
    fanart_links = ''
    if strFanart1:
        fanart_links = fanart_links + '<thumb colors="" preview=""> ' + strFanart1 + '</thumb>'
    if strFanart2:
        fanart_links = fanart_links + '<thumb colors="" preview=""> ' + strFanart2 + '</thumb>'
    if strFanart3:
        fanart_links = fanart_links + '<thumb colors="" preview=""> ' + strFanart3 + '</thumb>'
    if strFanart4:
        fanart_links = fanart_links + '<thumb colors="" preview=""> ' + strFanart4 + '</thumb>'
    # Fanart
    if fanart_links:
        nfo_content_season.append('\t<fanart>' + fanart_links + '</fanart>\n')
    # Clearlogo
    if "tvshow.clearlogo" in full_result_art:
        tmp_full_result_clearlogo = urllib.parse.unquote(
            full_result_art["tvshow.clearlogo"]).replace("image://", "")
        nfo_content_season.append(
            '\t<thumb aspect="clearlogo">'
            + tmp_full_result_clearlogo.replace(".png/", ".png")
            + '</thumb>\n'
        )
    # Clearart
    if "tvshow.clearart" in full_result_art:
        tmp_full_result_clearlogo = urllib.parse.unquote(
            full_result_art["tvshow.clearart"]).replace("image://", "")
        nfo_content_season.append(
            '\t<thumb aspect="clearart">'
            + tmp_full_result_clearlogo.replace(".png/", ".png")
            + '</clearart>\n'
        )
    # CharacterArt
    if "tvshow.characterart" in full_result_art:
        tmp_full_result_characterart = urllib.parse.unquote(
            full_result_art["tvshow.characterart"]).replace("image://", "")
        nfo_content_season.append(
            '\t<thumb aspect="characterart">'
            + tmp_full_result_characterart.replace(".png/", ".png")
            + '</thumb>\n'
        )
    if "tvshow.characterart1" in full_result_art:
        tmp_full_result_characterart = urllib.parse.unquote(
            full_result_art["tvshow.characterart1"]).replace("image://", "")
        nfo_content_season.append(
            '\t<thumb aspect="characterart">'
            + tmp_full_result_characterart.replace(".png/", ".png")
            + '</thumb>\n'
        )
    if "tvshow.characterart2" in full_result_art:
        tmp_full_result_characterart = urllib.parse.unquote(
            full_result_art["tvshow.characterart2"]).replace("image://", "")
        nfo_content_season.append(
            '\t<thumb aspect="characterart">'
            + tmp_full_result_characterart.replace(".png/", ".png")
            + '</thumb>\n'
        )
    if "tvshow.characterart3" in full_result_art:
        tmp_full_result_characterart = urllib.parse.unquote(
            full_result_art["tvshow.characterart3"]).replace("image://", "")
        nfo_content_season.append(
            '\t<thumb aspect="characterart">'
            + tmp_full_result_characterart.replace(".png/", ".png")
            + '</thumb>\n'
        )
    if "tvshow.characterart4" in full_result_art:
        tmp_full_result_characterart = urllib.parse.unquote(
            full_result_art["tvshow.characterart4"]).replace("image://", "")
        nfo_content_season.append(
            '\t<thumb aspect="characterart">'
            + tmp_full_result_characterart.replace(".png/", ".png")
            + '</thumb>\n'
        )
    if "tvshow.characterart5" in full_result_art:
        tmp_full_result_characterart = urllib.parse.unquote(
            full_result_art["tvshow.characterart5"]).replace("image://", "")
        nfo_content_season.append(
            '\t<thumb aspect="characterart">'
            + tmp_full_result_characterart.replace(".png/", ".png")
            + '</thumb>\n'
        )
    if "tvshow.characterart6" in full_result_art:
        tmp_full_result_characterart = urllib.parse.unquote(
            full_result_art["tvshow.characterart6"]).replace("image://", "")
        nfo_content_season.append(
            '\t<thumb aspect="characterart">'
            + tmp_full_result_characterart.replace(".png/", ".png")
            + '</thumb>\n'
        )
    if "tvshow.characterart7" in full_result_art:
        tmp_full_result_characterart = urllib.parse.unquote(
            full_result_art["tvshow.characterart7"]).replace("image://", "")
        nfo_content_season.append(
            '\t<thumb aspect="characterart">'
            + tmp_full_result_characterart.replace(".png/", ".png")
            + '</thumb>\n'
        )
    if "tvshow.characterart8" in full_result_art:
        tmp_full_result_characterart = urllib.parse.unquote(
            full_result_art["tvshow.characterart8"]).replace("image://", "")
        nfo_content_season.append(
            '\t<thumb aspect="characterart">'
            + tmp_full_result_characterart.replace(".png/", ".png")
            + '</thumb>\n'
        )
    if "tvshow.characterart9" in full_result_art:
        tmp_full_result_characterart = urllib.parse.unquote(
            full_result_art["tvshow.characterart9"]).replace("image://", "")
        nfo_content_season.append(
            '\t<thumb aspect="characterart">'
            + tmp_full_result_characterart.replace(".png/", ".png")
            + '</thumb>\n'
        )
# Part SEASON
# New Part Cast:
    if error == 0:
        if verboselog_adv:
            logger.debug(
                'NFO TV show season new part cast: "{}"'.format(casts_nfo))
        for cast_nfo in casts_nfo:
            try:
                if cast_nfo["thumbnail"] is None:
                    if verboselog_adv:
                        logger.debug('create_nfo_content_season => play thumbnail not here!')
                    cast_nfo_thumb = ''    
                else:
                    if verboselog_adv:
                        logger.debug('create_nfo_content_season => play thumbnail is here!') 
                    cast_nfo_thumb = urllib.parse.unquote(cast_nfo["thumbnail"]).replace("image://", "")      
                    cast_nfo_thumb = cast_nfo_thumb.replace(".jpg/", ".jpg")
                    if verboselog_adv:
                        logger.debug('create_nfo_content_season => for cast_nfo in casts_nfo => cast_nfo_thumb: "{}"'.format(cast_nfo_thumb))
                nfo_content_season.append("\t<actor>\n")
                if "name" in cast_nfo:          
                    nfo_content_season.append("\t\t<name>" + cast_nfo["name"] + "</name>\n")
                if "role" in cast_nfo:
                    nfo_content_season.append("\t\t<role>" + cast_nfo["role"] + "</role>\n")
                if "order" in cast_nfo:                   
                    nfo_content_season.append("\t\t<order>" + str(cast_nfo["order"]) + "</order>\n")
                if cast_nfo_thumb:
                    nfo_content_season.append("\t\t<thumbnail>" + cast_nfo_thumb + "</thumbnail>\n")
                if "teaminfosource" in cast_nfo:
                    nfo_content_season.append("\t\t<teaminfosource>" + cast_nfo["teaminfosource"] + "</teaminfosource>\n")
                if "tsdbteamid" in cast_nfo:
                    nfo_content_season.append("\t\t<tsdbteamid>" + cast_nfo["tsdbteamid"] + "</tsdbteamid>\n")
                nfo_content_season.append("\t</actor>\n")
            except Exception as error:
                logger.debug(
                    'create_nfo_content_season => for cast_nfo in casts_nfo => except: "{}"'.format(error))
                logger.debug(
                    'create_nfo_content_season => for cast_nfo in casts_nfo => except: "{}"'.format(type(error)))
                logger.debug(
                    'create_nfo_content_season => for cast_nfo in casts_nfo => except: "{}"'.format(error.args))
                continue
    # Extra - WebSources:
    if cache_use == 1:
        if strWebsite:
            nfo_content_season.append(
                "\t<website>" + strWebsite + "</website>\n")
        if strFacebook:
            nfo_content_season.append(
                "\t<facebook>" + strFacebook + "</facebook>\n")
        if strInstagram:
            nfo_content_season.append(
                "\t<instagram>" + strInstagram + "</instagram>\n")
        if strTwitter:
            nfo_content_season.append(
                "\t<twitter>" + strTwitter + "</twitter>\n")
        if strYoutube:
            nfo_content_season.append(
                "\t<youtube>" + strYoutube + "</youtube>\n")
        if strRSS:
            nfo_content_season.append("\t<rssfeed>" + strRSS + "</rssfeed>\n")
    # Extra01 - season path
    if season_path:
        nfo_content_season.append(
            "\t<seasonpath>" + season_path + "</seasonpath>\n"
        )
    # Extra02 - Scraper Helper: season info source | #https://www.thesportsdb.com/season/4328-English-Premier-League/2023-2024 | #https://www.thesportsdb.com/season/4445-Boxing/2023
    if tmp_strLeague != 'No data found':
        seasoninfosource = "https://www.thesportsdb.com/season/" + \
            spdb_vdb_id + "-" + tmp_strLeague + \
            "/" + str(full_result["season"])
        nfo_content_season.append(
            "\t<seasoninfosource>" + seasoninfosource + "</seasoninfosource>\n")
    # Ende SEASON
    nfo_content_season.append("</season>\n")
    return nfo_content_season



# Function to create NFO Cast Part for TV Shows
def get_nfo_tvshow_cast_normal(spdb_vdb_id, full_result):
    error = 0
    logger.debug("Start function: get_nfo_tvshow_cast_normal")
    nfo_x_casts = tsdb.get_nfo_tvshow_cast(spdb_vdb_id)
    logger.debug(
        'get_nfo_tvshow_cast_normal => nfo_x_casts:  "{}"'.format(nfo_x_casts))
    # No data found
    if nfo_x_casts == 'No data found':
        logger.debug(
            'create_nfo_content_tvshow => nfo_x_casts: NO DATA!! => "{}"'.format(nfo_x_casts))
        error = 1
    # When we found data
    else:
        tmp_strLeague = nfo_x_casts[0]["strLeague"]
        tmp_strLeague.replace(" ", "_")
        casts_nfo = []
        order = 1
        # Collect all Teams from League for cast
        for nfo_x_cast in nfo_x_casts:
            logger.debug(
                'create_nfo_content_tvshow => nfo_x_cast:  "{}"'.format(nfo_x_cast))
            cast_nfo_name = nfo_x_cast["strTeam"] + \
                " - (" + nfo_x_cast["strLeague"] + ")"
            if "genre" in full_result:
                cast_nfo_role = "Sport: " + \
                    str(full_result["genre"][0]) + " - " + \
                    str(nfo_x_cast["strCountry"]) + ""
            else:

                # Hier mit mehr Daten besseren Sport finden,,,
                cast_nfo_role = "Country: " + \
                    str(nfo_x_cast["strCountry"]) + ""
            casts_nfo.append(
                {
                    "name": cast_nfo_name,
                    "role": cast_nfo_role,
                    "order": order,
                    "thumbnail": nfo_x_cast["strBadge"],
                    "teaminfosource": "https://www.thesportsdb.com/league/" + spdb_vdb_id + "",
                    "tsdbteamid": nfo_x_cast["idTeam"],
                }
            )
            order = order + 1
        if verboselog_adv:
            logger.debug(
                'create_nfo_content_tvshow => Collect all Teams from League for cast ALL:  "{}"'.format(casts_nfo))
    # Wenn ein Fehler, dann no data liefern
    if error == 1:
        return 'No data found'
    else:
        return casts_nfo


# Function: NFO Content EPISODE => https://kodi.wiki/view/NFO_files/Templates
# Shit RPC GetEpisodeDetails is broken.... other way..
def create_nfo_content_episode(kodi_vdb_id, spdb_vdb_id, episode_nr, episode_id, season_nr):
    logger.debug("Start function: create_nfo_content_episode")
    error = 0
    season_label = season_nr
    season_nr = re.sub("[^0-9]", "", season_label)
    season_nr = int(season_nr[:4])
    payload3 = {"params": {"season": season_nr, "tvshowid": kodi_vdb_id, "properties": ["title", "firstaired", "playcount", "runtime", "season", "episode", "showtitle",
                                                                                        "productioncode", "streamdetails", "lastplayed", "file", "tvshowid", "dateadded", "uniqueid", "seasonid"]}, "jsonrpc": "2.0", "method": "VideoLibrary.GetEpisodes", "id": 1}
    info3 = json.loads(xbmc.executeJSONRPC(json.dumps(payload3)))
    full_result3 = info3["result"]["episodes"]
    logger.debug(
        'create_nfo_content_episode => full_result3: "{}"'.format(full_result3))
    episode_tsdb_id = full_result3[0]["uniqueid"]["tsdb"]
    logger.debug('create_nfo_content_episode => EventID from TSDB (episode_tsdb_id): "{}"'.format(
        episode_tsdb_id))
# Achtung episode_id = idEpisode // episode_nr = in tvshow/season/explizit episode // episode_tsdb_id = event id tsdb
    # Get fresh Episode Data from TSDB
    epi_tdsb_use = 0
    nfo_episode_tsdb = tsdb.load_episode_info_short(episode_tsdb_id)
    if nfo_episode_tsdb == 'No data found':
        logger.debug(
            "create_nfo_content_episode => load_episode_info_short => No data found")
    else:
        epi_tdsb_use = 1
        if verboselog_adv:
            logger.debug('create_nfo_content_episode => load_episode_info_short: "{}"'.format(
                nfo_episode_tsdb))

    # Get Episode Cast incl. Fallbacks
    nfo_episode_casts = tsdb.get_nfo_episode_cast(episode_tsdb_id)
    casts_nfo = []
    order = 1
    # Nothing found => Need Fallback 2
    logger.debug('create_nfo_content_episode => nfo_episode_casts: "{}"'.format(
        nfo_episode_casts))
    if nfo_episode_casts == 'No data found':
        logger.debug(
            'create_nfo_content_episode => Need Fallback 2: "{}"'.format(episode_tsdb_id))
        error = 1
        # ERSATZ TV SHOW!
        # Fallback to TV Show Cast
        casts_nfo = get_nfo_tvshow_cast_normal(spdb_vdb_id, full_result3)
        # TvShow Cast
        if casts_nfo != 'No data found':
            logger.debug('create_nfo_content_episode =>Fallback to TV show actors => nfo_episode_casts: "{}"'.format(
                nfo_episode_casts))
            error = 0
    # Normal Episode cast
    else:
        logger.debug('create_nfo_content_episode => Casts ok (normal) => nfo_episode_casts: "{}"'.format(
            nfo_episode_casts))
        # Alle Player ids sammeln..
        casts_idPlayer = []
        for nfo_episode_cast in nfo_episode_casts:
            tmp_idPlayer = nfo_episode_cast["idPlayer"]
            # At this time, only the PlayerID is important, strPlayer and strTeam not allways exists!
            if "strPlayer" in nfo_episode_cast:
                tmp_strPlayer = nfo_episode_cast["strPlayer"]
            else:
                tmp_strPlayer = 'No data found'
            if "strTeam" in nfo_episode_cast:
                tmp_strTeam = nfo_episode_cast["strTeam"]
            else:
                tmp_strTeam = 'No data found'
            casts_idPlayer.append(
                {"idPlayer": tmp_idPlayer, "strPlayer": tmp_strPlayer, "strTeam": tmp_strTeam, })

        # Get Episode Players and form casts
        # = https://www.thesportsdb.com/api/v2/json/3/lookup/player/34145937
        episode_player_infos = tsdb.get_nfo_episode_cast2(casts_idPlayer)
        logger.debug('create_nfo_content_episode => Casts ok (normal) =>  episode_player_infos: "{}"'.format(
            episode_player_infos))

        # Nothing found in get_nfo_episode_cast2
        if episode_player_infos == 'No data found':
            logger.debug('create_nfo_content_episode => episode_player_infos => no data found: "{}"'.format(
                episode_tsdb_id))
            error = 1
        else:
            # Create Actor Set
            for episode_player_info in episode_player_infos:
                results = episode_player_info["players"][0]
                cast_nfo_name = results["strPlayer"] + \
                    " - (" + results["dateBorn"] + ")"
#
# Sprach Variable von Addon Settings setzen!!!! => cast_nfo_role => Wort Sport!
#
                cast_nfo_role = "Sport: " + \
                    results["strSport"] + " - " + \
                    results["strNationality"] + ""
                casts_nfo.append(
                    {
                        "name": cast_nfo_name,
                        "role": cast_nfo_role,
                        "order": order,
                        "thumbnail": results["strThumb"],
                        "playerinfosource": "https://www.thesportsdb.com/player/" + results["idPlayer"] + "",
                        "playerid": results["idPlayer"],
                    }
                )
                order = order + 1
            logger.debug(
                'create_nfo_content_episode => Casts ok (normal) =>  Create Actor Set => casts_nfo: "{}"'.format(casts_nfo))


# Now we have the Event ID, => Search Loop replace! ('uniqueid': {'tsdb': '504985'})
    # Search Episode
    correct_episode_info = []
    for r in full_result3:
        if r["episodeid"] == episode_id:
            correct_episode_info.append(r)
            logger.debug(
                'Found correct Episode ID from Kodi with episodeID: "{}"'.format(r["episodeid"]))
    logger.debug('Found correct Episode ID from Kodi => correct_episode_info: "{}"'.format(
        correct_episode_info))
    search_str = str(correct_episode_info)
    correct_episode_info_stream = correct_episode_info[0]["streamdetails"]
    # logger.debug('Found correct Episode correct_episode_info_stream - all: "{}"'.format(correct_episode_info_stream))
    # Anfang EPISODE
    nfo_content_episode = ["<episodedetails>\n"]
    logger.debug('Found correct Episode correct_episode_info => correct_episode_info-title: "{}"'.format(
        correct_episode_info[0]["title"]))
    # Titel
    if "title" in search_str:
        nfo_content_episode.append(
            "\t<title>" + correct_episode_info[0]["title"] + "</title>\n")

    if "showtitle" in search_str:
        nfo_content_episode.append(
            "\t<showtitle>" +
            correct_episode_info[0]["showtitle"] + "</showtitle>\n"
        )
    # Original Title
    if "title" in search_str:
        nfo_content_episode.append(
            "\t<originaltitle>" +
            correct_episode_info[0]["title"] + "</originaltitle>\n"
        )
    # Sorttitle
    if "label" in search_str:
        nfo_content_episode.append(
            "\t<sorttitle>" +
            correct_episode_info[0]["label"] + "</sorttitle>\n"
        )
    # Season
    if "season" in search_str:
        nfo_content_episode.append(
            "\t<season>" +
            str(correct_episode_info[0]["season"]) + "</season>\n"
        )
    # Episoden Anzahl
    if "episode" in search_str:
        nfo_content_episode.append(
            "\t<episode>" +
            str(correct_episode_info[0]["episode"]) + "</episode>\n"
        )

    # More Information from TSDB Site:
    # https://www.thesportsdb.com/api/v1/json/3/lookupevent.php?id=441613
    if epi_tdsb_use == 1:
        logger.debug('create_nfo_content_episode => load_episode_info_short: "{}"'.format(
            nfo_episode_tsdb))

        # Description Language
        try:
            if verboselog_adv:
                logger.debug("create_nfo_content_episode => load_episode_info_short => check if description in:  {}".format(
                    settings.LANGUAGE))
            lang = "strDescription" + settings.LANGUAGE + ""
            episode_plot = nfo_episode_tsdb[lang]
        except:
            if verboselog_adv:
                logger.debug("create_nfo_content_episode => load_episode_info_short =>  {}".format(
                    settings.LANGUAGE))
            episode_plot = nfo_episode_tsdb["strDescriptionEN"]
            pass
            # continue
        logger.debug(
            'create_nfo_content_episode => load_episode_info_short => check the description, not in tsdb for language: ' + settings.LANGUAGE + ' | "  Fallback Language EN: "{}"'.format(episode_plot))
        if episode_plot:
            episode_plot = _clean_plot(episode_plot)
            episode_plot = control_characters(episode_plot)
            nfo_content_episode.append(
                "\t<outline>" + episode_plot + "</outline>\n")
            nfo_content_episode.append("\t<plot>" + episode_plot + "</plot>\n")
        if nfo_episode_tsdb['strSport']:
            nfo_content_episode.append(
                "\t<genre>" + nfo_episode_tsdb['strSport'] + "</genre>\n")
        if nfo_episode_tsdb['dateEvent']:
            nfo_content_episode.append(
                "\t<premiered>" + nfo_episode_tsdb['dateEvent'] + "</premiered>\n")
        if nfo_episode_tsdb['strVideo']:
            nfo_content_episode.append(
                "\t<trailer>" + nfo_episode_tsdb['strVideo'] + "</trailer>\n")
        if nfo_episode_tsdb['strPoster']:
            nfo_content_episode.append(
                "\t<thumb aspect='poster'>" + str(nfo_episode_tsdb['strPoster']) + "</thumb>\n")
        if nfo_episode_tsdb['strFanart']:
            nfo_content_episode.append(
                "\t<thumb aspect='fanart'>" + str(nfo_episode_tsdb['strFanart']) + "</thumb>\n")
        if nfo_episode_tsdb['strBanner']:
            nfo_content_episode.append(
                "\t<thumb aspect='banner'>" + str(nfo_episode_tsdb['strBanner']) + "</thumb>\n")
        if nfo_episode_tsdb['strFanart']:
            nfo_content_episode.append(
                "\t<thumb aspect='landscape'>" + str(nfo_episode_tsdb['strFanart']) + "</thumb>\n")
        fanart_links = ''
        if nfo_episode_tsdb['strMap']:
            fanart_links = "<thumb preview=''>" + \
                str(nfo_episode_tsdb['strMap']) + "</thumb>"
        if nfo_episode_tsdb['strFanart']:
            fanart_links = "<thumb preview=''>" + \
                str(nfo_episode_tsdb['strFanart']) + "</thumb>"
        if nfo_episode_tsdb['strThumb']:
            fanart_links = "<thumb preview=''>" + \
                str(nfo_episode_tsdb['strThumb']) + "</thumb>"
        if fanart_links:
            nfo_content_episode.append(
                "\t<fanart>" + fanart_links + "</fanart>\n")

    # Database Number Sportsdb
    if "tsdb" in correct_episode_info[0]["uniqueid"]:
        nfo_content_episode.append(
            '\t<uniqueid default="true" type="tsdb">'
            + correct_episode_info[0]["uniqueid"]["tsdb"]
            + '</uniqueid> <!-- https://www.thesportsdb.com/ --> \n'
        )
        nfo_content_episode.append(
            '\t<uniqueid default="false" type="thesportsdb">'
            + correct_episode_info[0]["uniqueid"]["tsdb"]
            + '</uniqueid> <!-- https://www.thesportsdb.com/ --> \n'
        )
        nfo_content_episode.append(
            '\t<tsdb>' + correct_episode_info[0]["uniqueid"]["tsdb"] + '</tsdb> <!-- https://www.thesportsdb.com/ --> \n'
        )

    if "firstaired" in search_str:
        nfo_content_episode.append(
            '\t<firstaired>' + correct_episode_info[0]["firstaired"] + '</firstaired>\n'
        )

    if "playcount" in search_str:
        nfo_content_episode.append(
            '\t<playcount>' + str(correct_episode_info[0]["playcount"]) + '</playcount>\n'
        )

    if "runtime" in search_str:
        nfo_content_episode.append(
            '\t<runtime>' + str(correct_episode_info[0]["runtime"]) + '</runtime>\n'
        )
# Part EPISODE
# New Part Cast:
    if error == 0:
        if verboselog_adv:
            logger.debug(
                'NFO TV show Episode new part cast: "{}"'.format(casts_nfo))
        for cast_nfo in casts_nfo:
            logger.debug('create_nfo_content_episode => ERRROR IN THE  LOOOP ???  "{}"'.format(cast_nfo))
            try:
                if cast_nfo["thumbnail"] is None:
                    if verboselog_adv:
                        logger.debug('create_nfo_content_episode => play thumbnail not here!')
                    cast_nfo_thumb = ''    
                else:
                    if verboselog_adv:
                        logger.debug('create_nfo_content_episode => play thumbnail is here!') 
                    cast_nfo_thumb = urllib.parse.unquote(cast_nfo["thumbnail"]).replace("image://", "")      
                    cast_nfo_thumb = cast_nfo_thumb.replace(".jpg/", ".jpg")
                    if verboselog_adv:
                        logger.debug('create_nfo_content_episode => for cast_nfo in casts_nfo => cast_nfo_thumb: "{}"'.format(cast_nfo_thumb))
                nfo_content_episode.append("\t<actor>\n")
                if "name" in cast_nfo:          
                    nfo_content_episode.append("\t\t<name>" + cast_nfo["name"] + "</name>\n")
                if "role" in cast_nfo:
                    nfo_content_episode.append("\t\t<role>" + cast_nfo["role"] + "</role>\n")
                if "order" in cast_nfo:                   
                    nfo_content_episode.append("\t\t<order>" + str(cast_nfo["order"]) + "</order>\n")
                if cast_nfo_thumb:
                    nfo_content_episode.append("\t\t<thumbnail>" + cast_nfo_thumb + "</thumbnail>\n")
                if "teaminfosource" in cast_nfo:
                    nfo_content_episode.append("\t\t<teaminfosource>" + cast_nfo["teaminfosource"] + "</teaminfosource>\n")
                if "tsdbteamid" in cast_nfo:
                    nfo_content_episode.append("\t\t<tsdbteamid>" + cast_nfo["tsdbteamid"] + "</tsdbteamid>\n")
                nfo_content_episode.append("\t</actor>\n")
            except Exception as error:
                logger.debug(
                    'create_nfo_content_episode => for cast_nfo in casts_nfo => except: "{}"'.format(error))
                logger.debug(
                    'create_nfo_content_episode => for cast_nfo in casts_nfo => except: "{}"'.format(type(error)))
                logger.debug(
                    'create_nfo_content_episode => for cast_nfo in casts_nfo => except: "{}"'.format(error.args))
                continue

    # Extra01 - TVShow Pfad
    if "file" in search_str:
        nfo_content_episode.append(
            "\t<episodepath>" +
            correct_episode_info[0]["file"] + "</episodepath>\n"
        )
    # Extra02 - Scraper Helper
    nfo_content_episode.append(
        "\t<episodeinfosource>https://www.thesportsdb.com/event/"
        + episode_tsdb_id
        + "</episodeinfosource>\n"
    )

    # Ende EPISODE
    nfo_content_episode.append("</episodedetails>\n")
    return nfo_content_episode


# Function: NFO Content TVSHOW => https://kodi.wiki/view/NFO_files/Templates
def create_nfo_content_tvshow(kodi_vdb_id, spdb_vdb_id):
    logger.debug("Start function: create_nfo_content_tvshow")
    if verboselog_adv:
        logger.debug('kodi_vdb_id: "{}"'.format(kodi_vdb_id))

    payload = {
        "jsonrpc": "2.0",
        "method": "VideoLibrary.GetTVShowDetails",
        "params": {
            "properties": [
                "title",
                "genre",
                "year",
                "rating",
                "plot",
                "studio",
                "mpaa",
                "cast",
                "playcount",
                "episode",
                "imdbnumber",
                "premiered",
                "votes",
                "lastplayed",
                "fanart",
                "thumbnail",
                "file",
                "originaltitle",
                "sorttitle",
                "episodeguide",
                "season",
                "watchedepisodes",
                "dateadded",
                "tag",
                "art",
                "userrating",
                "ratings",
                "runtime",
                "uniqueid",
            ],
            "tvshowid": kodi_vdb_id,
        },
        "id": 1,
    }
    info = json.loads(xbmc.executeJSONRPC(json.dumps(payload)))
    result = info["result"]
    full_result = info["result"]["tvshowdetails"]
    if verboselog_adv:
        logger.debug('RPC CALL Result: "{}"'.format(result))

    # Get Infos from Cache about TV show if exists
    # Cache Infos:
    cache_use = 0
    tvshow_info_cache = cache.load_show_info_from_cache(spdb_vdb_id)
    if tvshow_info_cache is None:
        logger.debug(
            "create_nfo_content_season => TV show info => no cache file found!")
    else:
        cache_use = 1
        strWebsite = tvshow_info_cache["strWebsite"]
        strFacebook = tvshow_info_cache["strFacebook"]
        strInstagram = tvshow_info_cache["strInstagram"]
        strTwitter = tvshow_info_cache["strTwitter"]
        strYoutube = tvshow_info_cache["strYoutube"]
        strRSS = tvshow_info_cache["strRSS"]
        strCountry = tvshow_info_cache["strCountry"]
        strFanart1 = tvshow_info_cache["strFanart1"]
        strFanart2 = tvshow_info_cache["strFanart2"]
        strFanart3 = tvshow_info_cache["strFanart3"]
        strFanart4 = tvshow_info_cache["strFanart4"]
        if verboselog_adv:
            logger.debug('create_nfo_content_season => TV show info => CACHE TVSHOW: "{}"'.format(
                tvshow_info_cache))
    # Cast for TV show => TSDB Teams in League as Actor
    error = 0
    casts_nfo = get_nfo_tvshow_cast_normal(spdb_vdb_id, full_result)
    # TvShow Cast
    if casts_nfo == 'No data found':
        error = 1
    # Anfang TVSHOW
    nfo_content_tvshow = ["<tvshow>\n"]
    nfo_content_tvshow.append(
        "\t<dateadded>" + full_result["dateadded"] + "</dateadded>\n"
    )
    # Titel
    # if full_result['title']:
    if "title" in full_result:
        nfo_content_tvshow.append(
            "\t<title>" + full_result["title"] + "</title>\n")
    # if full_result['label']:
    if "label" in full_result:
        nfo_content_tvshow.append(
            "\t<showtitle>" + full_result["label"] + "</showtitle>\n"
        )
    # if full_result['originaltitle']:
    if "originaltitle" in full_result:
        nfo_content_tvshow.append(
            "\t<originaltitle>" +
            full_result["originaltitle"] + "</originaltitle>\n"
        )
    # if full_result['sorttitle']:
    if "sorttitle" in full_result:
        nfo_content_tvshow.append(
            "\t<sorttitle>" + full_result["sorttitle"] + "</sorttitle>\n"
        )
    # Season Anzahl! - Achtung, Anzahl an gespeicherten Kodi Staffeln und nicht von Scraper!
    if "season" in full_result:
        nfo_content_tvshow.append(
            "\t<season>" + str(full_result["season"]) + "</season>\n"
        )
    # Episoden Anzahl! - Achtung, Anzahl an gespeicherten Kodi Episoden und nicht von Scraper!
    if "episode" in full_result:
        nfo_content_tvshow.append(
            "\t<episode>" + str(full_result["episode"]) + "</episode>\n"
        )
    # Votes - TSDB
    # if full_result['votes']:
    if "votes" in full_result:
        nfo_content_tvshow.append(
            "\t<votes>" + full_result["votes"] + "</votes>\n")
    # User Ratings
    # if full_result['userrating']:
    if "userrating" in full_result:
        nfo_content_tvshow.append(
            "\t<userrating>" +
            str(full_result["userrating"]) + "</userrating>\n"
        )
    nfo_content_tvshow.append("\t<top250></top250>\n")
    # Plot and Tags
    # if full_result['plot']:
    if "plot" in full_result:
        nfo_content_tvshow.append(
            "\t<outline>" +
            control_characters(full_result["plot"]) + "</outline>\n"
        )
    # if full_result['plot']:
    if "plot" in full_result:
        nfo_content_tvshow.append(
            "\t<plot>" + control_characters(full_result["plot"]) + "</plot>\n"
        )
    # if full_result['runtime']:
    if "runtime" in full_result:
        nfo_content_tvshow.append(
            "\t<runtime>" + str(full_result["runtime"]) + "</runtime>\n"
        )
    # Pictures
    full_result_art = full_result["art"]
    # if full_result_art['banner']:
    if "banner" in full_result_art:
        tmp_full_result_banner = urllib.parse.unquote(
            full_result_art["banner"]).replace("image://", "")
        nfo_content_tvshow.append(
            '\t<thumb aspect="banner">'
            + tmp_full_result_banner.replace(".jpg/", ".jpg")
            + '</thumb>\n'
        )
    if "fanart" in full_result_art:
        tmp_full_result_fanartl = urllib.parse.unquote(
            full_result_art["fanart"]).replace("image://", "")
        nfo_content_tvshow.append(
            '\t<thumb aspect="landscape">'
            + tmp_full_result_fanartl.replace(".jpg/", ".jpg")
            + '</thumb>\n'
        )
    if "poster" in full_result_art:
        tmp_full_result_poster = urllib.parse.unquote(
            full_result_art["poster"]).replace("image://", "")
        nfo_content_tvshow.append(
            '\t<thumb aspect="poster">'
            + tmp_full_result_poster.replace(".jpg/", ".jpg")
            + '</thumb>\n'
        )
    # More Fanart!!
    fanart_links = ''
    if strFanart1:
        fanart_links = fanart_links + '<thumb colors="" preview=""> ' + strFanart1 + '</thumb>'
    if strFanart2:
        fanart_links = fanart_links + '<thumb colors="" preview=""> ' + strFanart2 + '</thumb>'
    if strFanart3:
        fanart_links = fanart_links + '<thumb colors="" preview=""> ' + strFanart3 + '</thumb>'
    if strFanart4:
        fanart_links = fanart_links + '<thumb colors="" preview=""> ' + strFanart4 + '</thumb>'
    # Fanart
    if fanart_links:
        nfo_content_tvshow.append('\t<fanart>' + fanart_links + '</fanart>\n')
    # Clearlogo
    if "clearlogo" in full_result_art:
        tmp_full_result_clearlogo = urllib.parse.unquote(
            full_result_art["clearlogo"]).replace("image://", "")
        nfo_content_tvshow.append(
            '\t<thumb aspect="clearlogo">'
            + tmp_full_result_clearlogo.replace(".png/", ".png")
            + '</thumb>\n'
        )
    # CharacterArt
    if "characterart" in full_result_art:
        tmp_full_result_characterart = urllib.parse.unquote(
            full_result_art["characterart"]).replace("image://", "")
        nfo_content_tvshow.append(
            '\t<thumb aspect="characterart">'
            + tmp_full_result_characterart.replace(".png/", ".png")
            + '</thumb>\n'
        )
    if "characterart1" in full_result_art:
        tmp_full_result_characterart = urllib.parse.unquote(
            full_result_art["characterart1"]).replace("image://", "")
        nfo_content_tvshow.append(
            '\t<thumb aspect="characterart">'
            + tmp_full_result_characterart.replace(".png/", ".png")
            + '</thumb>\n'
        )
    if "characterart2" in full_result_art:
        tmp_full_result_characterart = urllib.parse.unquote(
            full_result_art["characterart2"]).replace("image://", "")
        nfo_content_tvshow.append(
            '\t<thumb aspect="characterart">'
            + tmp_full_result_characterart.replace(".png/", ".png")
            + '</thumb>\n'
        )
    if "characterart3" in full_result_art:
        tmp_full_result_characterart = urllib.parse.unquote(
            full_result_art["characterart3"]).replace("image://", "")
        nfo_content_tvshow.append(
            '\t<thumb aspect="characterart">'
            + tmp_full_result_characterart.replace(".png/", ".png")
            + '</thumb>\n'
        )
    if "characterart4" in full_result_art:
        tmp_full_result_characterart = urllib.parse.unquote(
            full_result_art["characterart4"]).replace("image://", "")
        nfo_content_tvshow.append(
            '\t<thumb aspect="characterart">'
            + tmp_full_result_characterart.replace(".png/", ".png")
            + '</thumb>\n'
        )
    if "characterart5" in full_result_art:
        tmp_full_result_characterart = urllib.parse.unquote(
            full_result_art["characterart5"]).replace("image://", "")
        nfo_content_tvshow.append(
            '\t<thumb aspect="characterart">'
            + tmp_full_result_characterart.replace(".png/", ".png")
            + '</thumb>\n'
        )
    if "characterart6" in full_result_art:
        tmp_full_result_characterart = urllib.parse.unquote(
            full_result_art["characterart6"]).replace("image://", "")
        nfo_content_tvshow.append(
            '\t<thumb aspect="characterart">'
            + tmp_full_result_characterart.replace(".png/", ".png")
            + '</thumb>\n'
        )
    if "characterart7" in full_result_art:
        tmp_full_result_characterart = urllib.parse.unquote(
            full_result_art["characterart7"]).replace("image://", "")
        nfo_content_tvshow.append(
            '\t<thumb aspect="characterart">'
            + tmp_full_result_characterart.replace(".png/", ".png")
            + '</thumb>\n'
        )
    if "characterart8" in full_result_art:
        tmp_full_result_characterart = urllib.parse.unquote(
            full_result_art["characterart8"]).replace("image://", "")
        nfo_content_tvshow.append(
            '\t<thumb aspect="characterart">'
            + tmp_full_result_characterart.replace(".png/", ".png")
            + '</thumb>\n'
        )
    if "characterart9" in full_result_art:
        tmp_full_result_characterart = urllib.parse.unquote(
            full_result_art["characterart9"]).replace("image://", "")
        nfo_content_tvshow.append(
            '\t<thumb aspect="characterart">'
            + tmp_full_result_characterart.replace(".png/", ".png")
            + '</thumb>\n'
        )
    # Abspieldaten
    # if full_result['playcount']:
    if "playcount" in full_result:
        nfo_content_tvshow.append(
            "\t<playcount>" + str(full_result["playcount"]) + "</playcount>\n"
        )
    # if full_result['lastplayed']:
    if "lastplayed" in full_result:
        nfo_content_tvshow.append(
            "\t<lastplayed>" + full_result["lastplayed"] + "</lastplayed>\n"
        )
    # Databse Kodi ID from Movie
    # if full_result['tvshowid']:
    if "tvshowid" in full_result:
        nfo_content_tvshow.append(
            "\t<id>" + str(full_result["tvshowid"]) + "</id>\n")
    # Database IMDBNumber => Wrong, Scraper saves spdb in imdb
    # if full_result['imdbnumber']:
    if "imdbnumber" in full_result:
        nfo_content_tvshow.append(
            "\t<imdb></imdb> <!-- https://www.imdb.com/ -->\n")
        nfo_content_tvshow.append(
            '\t<uniqueid default="false" type="imdb"></uniqueid> <!-- https://www.imdb.com/ -->\n'
        )
    else:
        nfo_content_tvshow.append(
            '\t<uniqueid default="false" type="imdb"></uniqueid> <!-- https://www.imdb.com/ -->\n'
        )
    # Database Number Sportsdb
    nfo_content_tvshow.append(
        '\t<uniqueid default="true" type="tsdb">'
        + spdb_vdb_id
        + '</uniqueid> <!-- https://www.thesportsdb.com/ --> \n'
    )
    nfo_content_tvshow.append(
        '\t<uniqueid default="false" type="thesportsdb">'
        + spdb_vdb_id
        + '</uniqueid> <!-- https://www.thesportsdb.com/ --> \n'
    )
    nfo_content_tvshow.append(
        "\t<tsdb>" + spdb_vdb_id + "</tsdb> <!-- https://www.thesportsdb.com/ --> \n"
    )
    # Databse ID's IMDB, TMDB, TVDB, ANIDB + WIKIDATA, FACEBOOK, INSTAGRAM & X
    nfo_content_tvshow.append(
        '\t<uniqueid default="false" type="tmdb"></uniqueid> <!-- https://www.themoviedb.com/ -->\n'
    )
    nfo_content_tvshow.append(
        '\t<uniqueid default="false" type="tvdb"></uniqueid> <!-- https://www.thetvdb.com/ -->\n'
    )
    nfo_content_tvshow.append(
        '\t<uniqueid default="false" type="anidb"></uniqueid> <!-- https://anidb.net/ -->\n'
    )
    nfo_content_tvshow.append(
        '\t<uniqueid default="false" type="tvrage"></uniqueid> <!-- https://www.tvrage.com/ -->\n'
    )
    nfo_content_tvshow.append(
        '\t<uniqueid default="false" type="tvmaze"></uniqueid> <!-- https://www.tvmaze.com/ -->\n'
    )
    nfo_content_tvshow.append(
        '\t<uniqueid default="false" type="zap2it"></uniqueid> <!-- https://tvschedule.zap2it.com/ -->\n'
    )
    nfo_content_tvshow.append(
        '\t<uniqueid default="false" type="wikidata"></uniqueid> <!-- https://www.wikidata.org/ -->\n'
    )
    nfo_content_tvshow.append(
        '\t<uniqueid default="false" type="facebook"></uniqueid> <!-- https://www.facebook.com/ -->\n'
    )
    nfo_content_tvshow.append(
        '\t<uniqueid default="false" type="instagram"></uniqueid> <!-- https://www.instagram.com/ -->\n'
    )
    nfo_content_tvshow.append(
        '\t<uniqueid default="false" type="x"></uniqueid> <!-- https://x.com/ -->\n'
    )
    # Episodeguide New
    nfo_content_tvshow.append(
        "\t" + full_result["episodeguide"].replace(" ", "") + "\n"
    )
    # Genres
    # if full_result['genre']:
    if "genre" in full_result:
        for x_genre in full_result["genre"]:
            nfo_content_tvshow.append("\t<genre>" + x_genre + "</genre>\n")
    # Premiered,Year
    # if full_result['premiered']:
    if "premiered" in full_result:
        nfo_content_tvshow.append(
            "\t<premiered>" + full_result["premiered"] + "</premiered>\n"
        )
    # if full_result['year']:
    if "year" in full_result:
        nfo_content_tvshow.append(
            "\t<year>" + str(full_result["year"]) + "</year>\n")
    # Studio - <studio>studio name / resolution / video codec / audio format / number of channels / language / subtitle language1/ subtitle language2... </studio>
    if "studio" in full_result:
        for studios in full_result["studio"]:
            nfo_content_tvshow.append("\t<studio>" + studios + "</studio>\n")

    # Status, Code, Studio,Country, - unbenutzt
    nfo_content_tvshow.append("\t<status></status>\n")
    nfo_content_tvshow.append("\t<code></code>\n")

    if strCountry:
        nfo_content_tvshow.append("\t<country>" + strCountry + "</country>\n")
    if "mpaa" in full_result:
        nfo_content_tvshow.append(
            "\t<mpaa>" + full_result["mpaa"] + "</mpaa>\n")
    # Tags,, empty = ["['[]']"] (filled in wrong with scraper?)
    if "tag" in full_result:
        for tags in full_result["tag"]:
            nfo_content_tvshow.append("\t<tag>" + str(tags) + "</tag>\n")
# Part TV SHOW
# New Part Cast:
    if error == 0:
        if verboselog_adv:
            logger.debug(
                'NFO TV show new part cast: "{}"'.format(casts_nfo))
        for cast_nfo in casts_nfo:
            try:
                if cast_nfo["thumbnail"] is None:
                    if verboselog_adv:
                        logger.debug('create_nfo_content_tvshow => play thumbnail not here!')
                    cast_nfo_thumb = ''    
                else:
                    if verboselog_adv:
                        logger.debug('create_nfo_content_tvshow => play thumbnail is here!') 
                    cast_nfo_thumb = urllib.parse.unquote(cast_nfo["thumbnail"]).replace("image://", "")      
                    cast_nfo_thumb = cast_nfo_thumb.replace(".jpg/", ".jpg")
                    if verboselog_adv:
                        logger.debug('create_nfo_content_tvshow => for cast_nfo in casts_nfo => cast_nfo_thumb: "{}"'.format(cast_nfo_thumb))
                nfo_content_tvshow.append("\t<actor>\n")
                if "name" in cast_nfo:          
                    nfo_content_tvshow.append("\t\t<name>" + cast_nfo["name"] + "</name>\n")
                if "role" in cast_nfo:
                    nfo_content_tvshow.append("\t\t<role>" + cast_nfo["role"] + "</role>\n")
                if "order" in cast_nfo:                   
                    nfo_content_tvshow.append("\t\t<order>" + str(cast_nfo["order"]) + "</order>\n")
                if cast_nfo_thumb:
                    nfo_content_tvshow.append("\t\t<thumbnail>" + cast_nfo_thumb + "</thumbnail>\n")
                if "teaminfosource" in cast_nfo:
                    nfo_content_tvshow.append("\t\t<teaminfosource>" + cast_nfo["teaminfosource"] + "</teaminfosource>\n")
                if "tsdbteamid" in cast_nfo:
                    nfo_content_tvshow.append("\t\t<tsdbteamid>" + cast_nfo["tsdbteamid"] + "</tsdbteamid>\n")
                nfo_content_tvshow.append("\t</actor>\n")
            except Exception as error:
                logger.debug(
                    'create_nfo_content_tvshow => for cast_nfo in casts_nfo => except: "{}"'.format(error))
                logger.debug(
                    'create_nfo_content_tvshow => for cast_nfo in casts_nfo => except: "{}"'.format(type(error)))
                logger.debug(
                    'create_nfo_content_tvshow => for cast_nfo in casts_nfo => except: "{}"'.format(error.args))
                continue
    # Extra - WebSources:
    if cache_use == 1:
        if strWebsite:
            nfo_content_tvshow.append(
                "\t<website>" + strWebsite + "</website>\n")
        if strFacebook:
            nfo_content_tvshow.append(
                "\t<facebook>" + strFacebook + "</facebook>\n")
        if strInstagram:
            nfo_content_tvshow.append(
                "\t<instagram>" + strInstagram + "</instagram>\n")
        if strTwitter:
            nfo_content_tvshow.append(
                "\t<twitter>" + strTwitter + "</twitter>\n")
        if strYoutube:
            nfo_content_tvshow.append(
                "\t<youtube>" + strYoutube + "</youtube>\n")
        if strRSS:
            nfo_content_tvshow.append("\t<rssfeed>" + strRSS + "</rssfeed>\n")
    # Extra01 - TVShow Pfad
    if "file" in full_result:
        nfo_content_tvshow.append(
            "\t<tvshowpath>" + full_result["file"] + "</tvshowpath>\n"
        )
    # Extra02 - Scraper Helper
    nfo_content_tvshow.append(
        "\t<tvshowinfosource>https://www.thesportsdb.com/league/"
        + spdb_vdb_id
        + "</tvshowinfosource>\n"
    )
    # Ende TVSHOW
    nfo_content_tvshow.append("</tvshow>\n")
    return nfo_content_tvshow


def _clean_plot(plot):
    # type: (Text) -> Text
    """Replace HTML tags with Kodi skin tags"""
    for repl in CLEAN_PLOT_REPLACEMENTS:
        plot = plot.replace(repl[0], repl[1])
    plot = TAG_RE.sub("", plot)
    return plot


def _set_episode_cast(episode_info, vtag):
    # type: (InfoType, ListItem) -> ListItem
    """Save rosters info to list item"""
    hometeam = {
        "idTeam": episode_info.get("idHomeTeam"),
        "strName": episode_info.get("strHomeTeam"),
    }
    awayteam = {
        "idTeam": episode_info.get("idAwayTeam"),
        "strName": episode_info.get("strAwayTeam"),
    }
    cast = []
    order = 1
    for team in [hometeam, awayteam]:
        if team["idTeam"] and team["strName"]:
            players = tsdb.load_roster_info(
                team["idTeam"], team["strName"], api_version
            )
            if not players:
                continue
            for player in players:
                # Correct Player Picture?
#https://www.thesportsdb.com/api/v2/json/9863529876235/list/players/Paraguay
# => {"players": "No data found"}
                try:
                    strPlayer = player.get("strPlayer", "")
                    strPosition = player.get("strPosition", "")
                    team_name = team["strName"]
                except:
                    if verboselog_adv:
                        logger.debug('function: _set_episode_cast => strPlayer / strPosition / team-strName not here!')
                    continue

                person = {
                    "name": strPlayer,
                    "role": "%s - %s"
                    % (strPosition, team_name),
                    "order": order,
                }
                thumb = None
                rawthumb = player.get("strThumb")
                if rawthumb:
                    thumb = url_fix(rawthumb)
                cast.append(
                    Actor(person["name"], person["role"],
                          person["order"], thumb)
                )
                order = order + 1
    if cast:
        vtag.setCast(cast)


def set_show_cast_artwork_filter1(character_arts):
    return character_arts["character_art_url_typ"] == "strRender"


def set_show_cast_artwork_filter2(character_arts):
    return character_arts["character_art_url_typ"] == "strCutout"


def save_character_art(save_artwork_chars_x, info_strLeague, info_idLeague):

    logger.debug(
        "Call function: save_character_art: %s [save_artwork_chars]"
        % save_artwork_chars_x
    )
    logger.debug(
        "Call function: info_strLeague: %s [info_strLeague]" % info_strLeague)
    # character_art_switch_name = settings.CHARACTERARTSWITCHNAME => 1 = characterart.png .. characterart9.png | 2 = (tvshowffoldername)-characterart.png .. (tvshowffoldername)-characterart9.png
    # write_character_art_path = settings.WRITECHRACTERARTPATH => true = im TVSerien Ordner bei der Serie / False = eigener Pfad: write_character_art_own_path
    # write_character_art_own_path = settings.WRITECHRACTERARTOWNPATH => der eigene Pfad als String
    # Addon Setting - Which Version of Picture
    if enab_character_art_version == 1:
        results_filtert = filter(
            set_show_cast_artwork_filter1, save_artwork_chars_x)
    elif enab_character_art_version == 2:
        results_filtert = filter(
            set_show_cast_artwork_filter2, save_artwork_chars_x)
    # Get Info in Kodi Databse
    tvshow_kodi_vdb_id = ""

    # payload = {"jsonrpc": "2.0", "method": "VideoLibrary.GetTVShows", "params": { "filter": {"field": "title", "operator": "is", "value": info_strLeague}, "limits": { "start" : 0, "end": 1 }, "properties": ["art", "genre", "plot", "title", "originaltitle", "year", "rating", "thumbnail", "playcount", "file", "fanart"] }, "id": "libTvShows"}
    payload = {
        "jsonrpc": "2.0",
        "method": "VideoLibrary.GetTVShows",
        "params": {
            "filter": {"field": "title", "operator": "is", "value": info_strLeague},
            "limits": {"start": 0, "end": 1},
            "properties": ["title", "file"],
        },
        "id": "libTvShows",
    }

    try:
        info = json.loads(xbmc.executeJSONRPC(json.dumps(payload)))
        tvshow_full_result = info["result"]["tvshows"]
        if verboselog_adv:
            logger.debug(
                'function: save_character_art - RPC - TRY - Info:  "{}"'.format(
                    tvshow_full_result
                )
            )
        save_path_tvshow = tvshow_full_result[0]["file"]
        tvshow_kodi_vdb_id = tvshow_full_result[0]["tvshowid"]
        if verboselog_adv:
            logger.debug(
                'function: save_character_art - RPC - tvshow_full_result - file: "{}"'.format(
                    tvshow_full_result[0]["file"]
                )
            )
            logger.debug(
                'function: save_character_art - RPC - tvshow_full_result - tvshowid: "{}"'.format(
                    tvshow_full_result[0]["tvshowid"]
                )
            )

    except:
        if verboselog_adv:
            logger.debug("function: save_character_art - RPC - except:")

    if verboselog_adv:
        logger.debug(
            'save_character_art - Correct Kodi VideoDatabase TSDB ID:  "{}"'.format(
                info_idLeague
            )
        )
        logger.debug(
            'save_character_art - Correct Kodi VideoDatabase save_path_tvshow:  "{}"'.format(
                save_path_tvshow
            )
        )
        logger.debug(
            'save_character_art - Correct Kodi VideoDatabase tvshow_kodi_vdb_id:  "{}"'.format(
                tvshow_kodi_vdb_id
            )
        )
        logger.debug(
            'save_character_art - Correct Kodi VideoDatabase info_strLeague:  "{}"'.format(
                info_strLeague
            )
        )
    # Create Save Path - in TVShow Folder
    if write_character_art_path:
        save_path = save_path_tvshow
        logger.debug(
            "Call function: save_character_art | IN TVShow Folder | write_character_art_path: %s "
            % write_character_art_path
        )
        logger.debug(
            "Call function: save_character_art | Path: %s " % save_path)
    # Create Save Path - in Own Folder
    else:
        save_path = write_character_art_own_path
        logger.debug(
            "Call function: save_character_art | IN OWN Folder | write_character_art_path: %s "
            % write_character_art_path
        )
        logger.debug(
            "Call function: save_character_art | Path: %s " % save_path)
    file_numb = ""
    # Loop in filteret Object
    for result_val in results_filtert:
        url = result_val.get("character_art_url", "")
        logger.debug("function save_character_art DL - url: {}".format(url))
        full_save_path = save_path + "characterart" + str(file_numb) + ".png"
        logger.debug(
            "function save_character_art DL - full_save_path: {}".format(
                full_save_path)
        )
        # Path OS translation
        full_save_path = xbmcvfs.translatePath(full_save_path)
        logger.debug(
            "function save_character_art DL - full_save_path OS translation: {}".format(
                full_save_path
            )
        )

        try:
            resp = urlopen(url)
            # Notfalls, zuert vcfs.file auf temp pfad, dann weiter auf smb mit cvfs.copy
            if verboselog_adv:
                logger.debug(
                    "NEW WRITER Player art = full_save_path BEFORE VAL: {}".format(
                        full_save_path
                    )
                )
            full_save_path = xbmcvfs.validatePath(full_save_path)
            if verboselog_adv:
                logger.debug(
                    "NEW WRITER Player art = full_save_path AFTER VAL: {}".format(
                        full_save_path
                    )
                )
            xbmcvfs.copy(url, full_save_path)
            if verboselog_adv:
                logger.debug(
                    "NEW WRITER Player art = RESULT url OK: {}".format(url))
                logger.debug(
                    "NEW WRITER Player art = RESULT full_save_path OK: {}".format(
                        full_save_path
                    )
                )
            if file_numb == "":
                file_numb = 0
            file_numb = int(file_numb + 1)
            if file_numb == 10:
                break

        except:
            if verboselog_adv:
                logger.debug("NEW WRITER Player art = EXCEPT: {}".format(url))
            continue


def save_tvshow_art(
    show_info, write_artwork_grp01, write_filename_type, get_strLeague, get_idLeague
):
    # show_info = all catchted infos from tvshow in tsdb (at this time)
    # write_artwork_grp01 = type of artwork: poster,banner,fanart,clearlogo => string
    # write_filename_type = same as settings.WRITEPOSTERFILENAME or banner,fanart an clearlogo => string
    # get_strLeague = Name of the league => string
    # get_idLeague = ID of TVShow in the TSDB
    save_path_filename = ""
    dl_job_season_poster = []
    dl_job_fanart = []
    bulk_job_data = ''
    logger.debug("Call function: save_tvshow_art")
    if verboselog_adv:
        logger.debug(
            'Call function: save_tvshow_art => show_info:  "{}"'.format(
                show_info)
        )
        logger.debug(
            'Call function: save_tvshow_art => write_artwork_grp01:  "{}"'.format(
                write_artwork_grp01
            )
        )
        logger.debug(
            'Call function: save_tvshow_art => write_filename_type:  "{}"'.format(
                write_filename_type
            )
        )
        logger.debug(
            'Call function: save_tvshow_art => get_strLeague:  "{}"'.format(
                get_strLeague
            )
        )
        logger.debug(
            'Call function: save_tvshow_art => get_idLeague:  "{}"'.format(
                get_idLeague)
        )

    tvshow_kodi_vdb_id = ""
    payload = {
        "jsonrpc": "2.0",
        "method": "VideoLibrary.GetTVShows",
        "params": {
            "filter": {"field": "title", "operator": "is", "value": get_strLeague},
            "limits": {"start": 0, "end": 1},
            "properties": ["title", "file"],
        },
        "id": "libTvShows",
    }
    # payload = {"jsonrpc": "2.0", "method": "VideoLibrary.GetTVShows", "params": { "filter": {"field": "title", "operator": "is", "value": get_strLeague}, "limits": { "start" : 0, "end": 1 }, "properties": ["art", "genre", "plot", "title", "originaltitle", "year", "rating", "thumbnail", "playcount", "file", "fanart"] }, "id": "libTvShows"}

    try:

        info = json.loads(xbmc.executeJSONRPC(json.dumps(payload)))
        tvshow_full_result = info["result"]["tvshows"]
        if verboselog_adv:
            logger.debug(
                'function: save_tvshow_art - RPC - TRY - Info:  "{}"'.format(
                    tvshow_full_result
                )
            )

        save_path_tvshow = tvshow_full_result[0]["file"]
        tvshow_kodi_vdb_id = tvshow_full_result[0]["tvshowid"]
        if verboselog_adv:
            logger.debug(
                'function: save_tvshow_art - RPC - tvshow_full_result - file: "{}"'.format(
                    tvshow_full_result[0]["file"]
                )
            )
            logger.debug(
                'function: save_tvshow_art - RPC - tvshow_full_result - tvshowid: "{}"'.format(
                    tvshow_full_result[0]["tvshowid"]
                )
            )

    except:
        if verboselog_adv:
            logger.debug("function: save_tvshow_art - RPC - except:")

    if verboselog_adv:
        logger.debug(
            'save_character_art - Correct TSDB ID:  "{}"'.format(get_idLeague))
        logger.debug(
            'save_character_art - Correct save_path_tvshow:  "{}"'.format(
                save_path_tvshow
            )
        )
        logger.debug(
            'save_character_art - Correct Kodi VideoDatabase tvshow_kodi_vdb_id:  "{}"'.format(
                tvshow_kodi_vdb_id
            )
        )
        logger.debug(
            'save_character_art - Correct get_strLeague:  "{}"'.format(
                get_strLeague)
        )

    # typ of art + create path + filename
    if write_artwork_grp01 == "poster":
        if verboselog_adv:
            logger.debug(
                'Call function: save_tvshow_art - poster?: "{}"'.format(
                    write_artwork_grp01
                )
            )
        if write_filename_type == "1":
            logger.debug(
                'Call function: save_tvshow_art - write_filename_type = tvshow-poster.jpg => 1?: "{}"'.format(
                    write_filename_type
                )
            )
            save_path_filename = save_path_tvshow + "" + get_strLeague + "-poster.jpg"
        elif write_filename_type == "2":
            logger.debug(
                'Call function: save_tvshow_art - write_filename_type = poster.jpg => 2?: "{}"'.format(
                    write_filename_type
                )
            )
            save_path_filename = save_path_tvshow + "poster.jpg"
        dl_url = show_info.get("strPoster", "")
    # Fanarts => Bulk Job
    elif write_artwork_grp01 == "fanarts":
        cache_use = 0

        # Get Information from Cache: get_idLeague
        tvshow_info_cache = cache.load_show_info_from_cache(get_idLeague)
        if tvshow_info_cache is None:
            if verboselog_adv:
                logger.debug(
                    "Fanarts => Bulk Job => TV show info => no cache file found!")
        else:
            cache_use = 1
            strFanart = tvshow_info_cache["strFanart1"]
            strFanart1 = tvshow_info_cache["strFanart2"]
            strFanart2 = tvshow_info_cache["strFanart3"]
            strFanart3 = tvshow_info_cache["strFanart4"]
            if verboselog_adv:
                logger.debug(
                    "Fanarts => Bulk Job => TV show info => Cache file found!")
        if verboselog_adv:
            logger.debug(
                'Call function: save_tvshow_art - fanart?: "{}"'.format(
                    write_artwork_grp01
                )
            )
        if write_filename_type == "1":
            logger.debug(
                'Call function: save_tvshow_art - write_filename_type = tvshow-fanart.jpg => 1?: "{}"'.format(
                    write_filename_type
                )
            )
            if strFanart:
                dl_url = strFanart
                save_path_filename = save_path_tvshow + "" + get_strLeague + "-fanart.jpg"
                dl_job_fanart.append(
                    {"dl_url": dl_url, "save_path_filename": save_path_filename})
            if strFanart1:
                dl_url1 = strFanart1
                save_path_filename1 = save_path_tvshow + "" + get_strLeague + "-fanart1.jpg"
                dl_job_fanart.append(
                    {"dl_url": dl_url1, "save_path_filename": save_path_filename1})
            if strFanart2:
                dl_url2 = strFanart2
                save_path_filename2 = save_path_tvshow + "" + get_strLeague + "-fanart2.jpg"
                dl_job_fanart.append(
                    {"dl_url": dl_url2, "save_path_filename": save_path_filename2})
            if strFanart3:
                dl_url3 = strFanart3
                save_path_filename3 = save_path_tvshow + "" + get_strLeague + "-fanart3.jpg"
                dl_job_fanart.append(
                    {"dl_url": dl_url3, "save_path_filename": save_path_filename3})

        elif write_filename_type == "2":
            logger.debug(
                'Call function: save_tvshow_art - write_filename_type = fanart.jpg => 2?: "{}"'.format(
                    write_filename_type
                )
            )
            if strFanart:
                dl_url = strFanart
                save_path_filename = save_path_tvshow + "fanart.jpg"
                dl_job_fanart.append(
                    {"dl_url": dl_url, "save_path_filename": save_path_filename})
            if strFanart1:
                dl_url1 = strFanart1
                save_path_filename1 = save_path_tvshow + "fanart1.jpg"
                dl_job_fanart.append(
                    {"dl_url": dl_url1, "save_path_filename": save_path_filename1})
            if strFanart2:
                dl_url2 = strFanart2
                save_path_filename2 = save_path_tvshow + "fanart2.jpg"
                dl_job_fanart.append(
                    {"dl_url": dl_url2, "save_path_filename": save_path_filename2})
            if strFanart3:
                dl_url3 = strFanart3
                save_path_filename3 = save_path_tvshow + "fanart3.jpg"
                dl_job_fanart.append(
                    {"dl_url": dl_url3, "save_path_filename": save_path_filename3})
    elif write_artwork_grp01 == "banner":
        if verboselog_adv:
            logger.debug(
                'Call function: save_tvshow_art - banner?: "{}"'.format(
                    write_artwork_grp01
                )
            )
        if write_filename_type == "1":
            logger.debug(
                'Call function: save_tvshow_art - write_filename_type = tvshow-banner.jpg => 1?: "{}"'.format(
                    write_filename_type
                )
            )
            save_path_filename = save_path_tvshow + "" + get_strLeague + "-banner.jpg"
        elif write_filename_type == "2":
            logger.debug(
                'Call function: save_tvshow_art - write_filename_type = banner.jpg => 2?: "{}"'.format(
                    write_filename_type
                )
            )
            save_path_filename = save_path_tvshow + "banner.jpg"
        dl_url = show_info.get("strBanner", "")
    elif write_artwork_grp01 == "clearlogo":
        if verboselog_adv:
            logger.debug(
                'Call function: save_tvshow_art - clearlogo?: "{}"'.format(
                    write_artwork_grp01
                )
            )
        if write_filename_type == "1":
            logger.debug(
                'Call function: save_tvshow_art - write_filename_type = tvshow-clearlogo.png => 1?: "{}"'.format(
                    write_filename_type
                )
            )
            save_path_filename = (
                save_path_tvshow + "" + get_strLeague + "-clearlogo.png"
            )
        elif write_filename_type == "2":
            logger.debug(
                'Call function: save_tvshow_art - write_filename_type = clearlogo.png => 2?: "{}"'.format(
                    write_filename_type
                )
            )
            save_path_filename = save_path_tvshow + "clearlogo.png"
        dl_url = show_info.get("strLogo", "")
    elif write_artwork_grp01 == "seasonposter":
        if verboselog_adv:
            logger.debug(
                'Call function: save_tvshow_art - seasonposter?: "{}"'.format(
                    write_artwork_grp01
                )
            )
        # Need to create
        dl_url = ""
        db_lob = ""

        payload = {
            "jsonrpc": "2.0",
            "method": "Files.GetDirectory",
            "params": {
                "properties": ["showtitle", "title", "season", "episode", "file"],
                "directory": save_path_tvshow,
                "media": "video",
            },
            "id": 1,
        }
        info = json.loads(xbmc.executeJSONRPC(json.dumps(payload)))

        try:
            info_files = info["result"]["files"]
            if verboselog_adv:
                logger.debug("Files.GetDirectory - Result: OK")
                logger.debug("NEW PATH TEST result:  %s " % info)

            ret = []
            for r in info_files:
                ret.append(r)
                if verboselog_adv:
                    logger.debug(
                        'Files.GetDirectory -  - Result loop: r  "{}"'.format(
                            r)
                    )

            if verboselog_adv:
                logger.debug(
                    "Files.GetDirectory - End loop, create listor..:  %s " % ret
                )

        except:
            logger.debug("Files.GetDirectory - Result: NOTHING EXCEPT res")

        # Season Loop from Files.GetDirectory
        for db_path_entry in ret:
            logger.debug(
                'Files.GetDirectory - db_path_entry - Result loop: db_path_entry: "{}"'.format(
                    db_path_entry
                )
            )
            # db_path_entry - Result loop: db_path_entry: "{'file': 'smb://192.168.1.120/Sport-Videos/Serien-tsdb/MotoGP/Season 2010/', 'filetype': 'directory', 'label': 'Season 2010', 'title': '', 'type': 'unknown'}"
            dp_path_entry_label = db_path_entry["label"]
            dp_path_tvshow_season = db_path_entry["file"]
            # Add correct filename + extension
            if verboselog_adv:
                logger.debug(
                    'FILENAME AND PATH NOW: "{}"'.format(dp_path_tvshow_season)
                )
                logger.debug(
                    'Files.GetDirectory - db_path_entry - Result loop: dp_path_entry_label: "{}"'.format(
                        dp_path_entry_label
                    )
                )
            # remove all other chars
            dp_path_entry_label_clean = re.sub(
                "[^0-9]", "", dp_path_entry_label)
            if verboselog_adv:
                logger.debug(
                    'Files.GetDirectory - db_path_entry - Result loop: dp_path_entry_label_clean: "{}"'.format(
                        dp_path_entry_label_clean
                    )
                )
            #  cut [4}] &  make int
            try:
                if verboselog_adv:
                    logger.debug(
                        'Files.GetDirectory - season number check, cut to 4, make int - start with: "{}"'.format(
                            dp_path_entry_label_clean
                        )
                    )

                season_nr = dp_path_entry_label_clean[:4]
                season_nr = int(season_nr)

            except:
                if verboselog_adv:
                    logger.debug(
                        "Files.GetDirectory - season number check, cut to 4, make int => except"
                    )
                continue
            if verboselog_adv:
                logger.debug(
                    'Files.GetDirectory - db_path_entry - Result loop: season_nr: "{}"'.format(
                        season_nr
                    )
                )

            if write_filename_type == "1":
                dp_path_tvshow_season = xbmcvfs.translatePath(
                    save_path_tvshow + "season" + season_nr + ".jpg"
                )
                if verboselog_adv:
                    logger.debug(
                        'Call function: save_tvshow_art - write_filename_type = seasonXX.jpg => 1?: "{}"'.format(
                            write_filename_type
                        )
                    )
                    logger.debug(
                        'FILENAME AND PATH NOW ink.: "{}"'.format(
                            dp_path_tvshow_season)
                    )

            elif write_filename_type == "2":
                dp_path_tvshow_season = xbmcvfs.translatePath(
                    dp_path_tvshow_season + "season.jpg"
                )
                if verboselog_adv:
                    logger.debug(
                        'Call function: save_tvshow_art - write_filename_type = StaffelXX/season.jpg => 2?: "{}"'.format(
                            write_filename_type
                        )
                    )
                    logger.debug(
                        'FILENAME AND PATH NOW ink.: "{}"'.format(
                            dp_path_tvshow_season)
                    )

            # Get URL from Season Poster
            payload2 = {
                "jsonrpc": "2.0",
                "id": 1,
                "method": "VideoLibrary.GetEpisodes",
                "params": {
                    "tvshowid": tvshow_kodi_vdb_id,
                    "season": season_nr,
                    "limits": {"start": 0, "end": 1},
                    "properties": [
                        "title",
                        "art",
                        "file",
                        "tvshowid",
                        "season",
                        "episode",
                        "playcount",
                        "showtitle",
                        "seasonid",
                    ],
                },
            }
            # RPC Call
            info2 = ""
            info2 = json.loads(xbmc.executeJSONRPC(json.dumps(payload2)))
            if verboselog_adv:
                logger.debug(
                    'tvshow_full_art_result2 - Result: info2 "{}"'.format(
                        info2)
                )
            try:
                res = ""
                res = info2["result"]["episodes"][0]["art"]
                logger.debug(
                    'tvshow_full_art_result2 - Result loop: r season_nr: "{}"'.format(
                        season_nr
                    )
                )
                logger.debug(
                    'tvshow_full_art_result2 - Result loop: r kodi_id: "{}"'.format(
                        tvshow_kodi_vdb_id
                    )
                )
                if verboselog_adv:
                    logger.debug(
                        'tvshow_full_art_result2 - Result loop: => dl_url before replace image:// : "{}"'.format(
                            dl_url
                        )
                    )
                dl_url = res["season.poster"].replace("image://", "")
                if verboselog_adv:
                    logger.debug(
                        'tvshow_full_art_result2 - Result loop: => dl_url after replace image:// : "{}"'.format(
                            dl_url
                        )
                    )
                url_last_character = dl_url[-1]
                if verboselog_adv:
                    logger.debug(
                        'tvshow_full_art_result2 - Result loop: => url_last_character: "{}"'.format(
                            url_last_character
                        )
                    )
                if "/" in url_last_character:
                    if verboselog_adv:
                        logger.debug(
                            'tvshow_full_art_result2 - Result loop: => activate => rstrip parse: "{}"'.format(
                                url_last_character
                            )
                        )
                    dl_url = dl_url.rstrip(dl_url[-1])
                    dl_url = urllib.parse.unquote(dl_url)
                if verboselog_adv:
                    logger.debug(
                        'tvshow_full_art_result2 - Result loop: => append => dl_url: "{}"'.format(
                            dl_url
                        )
                    )
                    logger.debug(
                        'tvshow_full_art_result2 - Result loop: => append => dp_path_tvshow_season: "{}"'.format(
                            dp_path_tvshow_season
                        )
                    )
                dl_job_season_poster.append(
                    {"dl_url": dl_url, "save_path_filename": dp_path_tvshow_season}
                )
            except:
                logger.debug(
                    "tvshow_full_art_result2 - Result: NOTHING EXCEPT res => NO SEASON POSTER HERE, if set Season Poster each Season and nothing in TSDB, then this ocur"
                )
            # return res

    # Informations Now: TVShow Path, Save Path/Filenname, Artwork Typ (poster,banner,..), filename (tvshow-poster or poster.jpg), Name von League/TVshow, ID von League bei TSDB
    # Path OS translation
    full_save_path = xbmcvfs.translatePath(save_path_filename)

    # Bulk Job
    if write_artwork_grp01 == "seasonposter" or write_artwork_grp01 == "fanarts":
        if verboselog_adv:
            logger.debug('DL Bulk Job => "{}"'.format(write_artwork_grp01))

        if dl_job_season_poster:
            if verboselog_adv:
                logger.debug('DL Bulk Job => bulk_job_data = dl_job_season_poster: "{}"'.format(
                    dl_job_season_poster))
            bulk_job_data = dl_job_season_poster
        elif dl_job_fanart:
            if verboselog_adv:
                logger.debug(
                    'DL Bulk Job => bulk_job_data = dl_job_fanart: "{}"'.format(dl_job_fanart))
            bulk_job_data = dl_job_fanart

        # Download Jobs - Season Poster
        for db_lob in bulk_job_data:
            if verboselog_adv:
                logger.debug(
                    'Download Jobs => Season Poster Loop: "{}"'.format(db_lob))

            try:
                xbmcvfs.copy(db_lob["dl_url"], db_lob["save_path_filename"])
                if verboselog_adv:
                    logger.debug(
                        "NEW WRITER Bulk Job = RESULT OK db_lob[dl_url]: {}".format(
                            db_lob["dl_url"]
                        )
                    )
                    logger.debug(
                        "NEW WRITER Bulk Job = RESULT OK db_lob[save_path_filename]: {}".format(
                            db_lob["save_path_filename"]
                        )
                    )
            except:
                if verboselog_adv:
                    logger.debug(
                        "NEW WRITER Bulk Job = EXCEPT db_lob[dl_url]: {}".format(
                            db_lob["dl_url"]
                        )
                    )
                    logger.debug(
                        "NEW WRITER Bulk Job = EXCEPT db_lob[save_path_filename]: {}".format(
                            db_lob["save_path_filename"]
                        )
                    )
                continue

    # Solo Job
    else:

        try:
            xbmcvfs.copy(dl_url, full_save_path)
            if verboselog_adv:
                logger.debug(
                    "NEW WRITER Solo Job = RESULT OK dl_url: {}".format(dl_url)
                )
                logger.debug(
                    "NEW WRITER Solo Job = RESULT OK full_save_path: {}".format(
                        full_save_path
                    )
                )
        except:
            if verboselog_adv:
                logger.debug(
                    "NEW WRITER Solo Job = EXCEPT dl_url: {}".format(dl_url))
                logger.debug(
                    "NEW WRITER Solo Job = EXCEPT full_save_path: {}".format(
                        full_save_path
                    )
                )


def _set_show_cast(show_info, vtag):
    # type: (InfoType, ListItem) -> List
    """Save team info to list item"""
    cast = []
    order = 1
    # If Addon Setting enab_character_art are True
    if enab_character_art:
        character_arts = []
        character_art_url = ""
        character_art_url_typ = ""
        character_art_key = 0
    teams = show_info.get("teams")
    if not teams:
        teams = tsdb.load_team_list(
            show_info.get("strLeague", ""), api_version)
    if teams:
        for team in teams:

            try:
                # CAST
                # strTeamBadge?? not strBadge
                team = {
                    "name": team.get("strTeam", ""),
                    "role": "Sport: %s - %s"
                    % (team.get("strSport", ""), team.get("strLeague", "")),
                    "order": order,
                }
                thumb = None
                # rawthumb = team.get("strTeamBadge")
                rawthumb = team.get("strBadge")
                if rawthumb:
                    thumb = url_fix(rawthumb)
                cast.append(
                    Actor(team["name"], team["role"], team["order"], thumb))
                order = order + 1

            except:
                logger.debug("Function => _set_show_cast => Error")
                continue

            # Addon Setting - Artwork - Enable Character Art - Add in DB
            if enab_character_art:
                if verboselog_adv:
                    logger.debug(
                        "Call function: set_show_cast enab_character_art: %s [Addon Setting - Artwork - Enable Character Art - Add in DB]"
                        % enab_character_art
                    )
                # Load Player List for x Team
                try:

                    players = tsdb.load_roster_info(
                        team.get("idTeam", ""), team.get(
                            "strTeam", ""), api_version
                    )
                    if verboselog_adv:
                        logger.debug("Artwork - Enable Character Art => Try")
                except:
                    if verboselog_adv:
                        logger.debug(
                            "Artwork - Enable Character Art => except")
                # continue
                if verboselog_adv:
                    logger.debug(
                        "Call function: load_roster_info: %s [players]" % players
                    )
                # If Player exists, loop:
                if not players:
                    continue
                for player in players:
                    if verboselog_adv:
                        logger.debug(
                            "Call function: load_roster_info strRender: %s [strRender]"
                            % player.get("strRender", "")
                        )
                        logger.debug(
                            "Call function: load_roster_info strCutout: %s [strCutout]"
                            % player.get("strCutout", "")
                        )
                        # Select the correct Version of Art
                        logger.debug(
                            "enab_character_art_version: %s | [if strRender or strCutout, incl. fallback]"
                            % enab_character_art_version
                        )
                    # if here - strRender
                    if player.get("strRender", ""):
                        character_art_url = player.get("strRender", "")
                        character_art_url_typ = "strRender"
                        if verboselog_adv:
                            logger.debug(
                                "OK - chooise strRender ADD : %s | [character_art_url]"
                                % character_art_url
                            )
                        character_art_key = character_art_key + 1
                        character_arts.append(
                            {
                                "character_art_key": character_art_key,
                                "character_art_preferred": enab_character_art_version,
                                "character_art_url": character_art_url,
                                "character_art_url_typ": character_art_url_typ,
                            }
                        )
                    # if here - strCutout
                    if player.get("strCutout", ""):
                        character_art_url = player.get("strCutout", "")
                        character_art_url_typ = "strCutout"
                        if verboselog_adv:
                            logger.debug(
                                "OK - chooise  strCutout ADD: %s | [character_art_url]"
                                % character_art_url
                            )
                        character_art_key = character_art_key + 1
                        character_arts.append(
                            {
                                "character_art_key": character_art_key,
                                "character_art_preferred": enab_character_art_version,
                                "character_art_url": character_art_url,
                                "character_art_url_typ": character_art_url_typ,
                            }
                        )
                # At the end of Player Loop in Teams (Call each Team)
                if verboselog_adv:
                    logger.debug("Loop End, character_arts List: %s" %
                                 character_arts)
                if enab_character_art_version == 1:
                    if verboselog_adv:
                        logger.debug(
                            "enab_character_art_version: %s | [1]"
                            % enab_character_art_version
                        )
                    # Only strRender
                    results_strRender = filter(
                        set_show_cast_artwork_filter1, character_arts
                    )
                    # Add Charakter Art in Kodi
                    if verboselog_adv:
                        logger.debug("All - strRender: %s" % results_strRender)
                    for result_strRender in results_strRender:
                        if verboselog_adv:
                            logger.debug(
                                "strRender - value: {}".format(
                                    result_strRender)
                            )
                        character_art_url = result_strRender.get(
                            "character_art_url", ""
                        )
                        character_art_preview_url = character_art_url + "/preview"
                        if verboselog_adv:
                            logger.debug(
                                "addAvailableArtwork - strRender - arttype=characterart {}".format(
                                    character_art_url
                                )
                            )
                        vtag.addAvailableArtwork(
                            character_art_url,
                            arttype="characterart",
                            preview=character_art_preview_url,
                        )
                elif enab_character_art_version == 2:
                    if verboselog_adv:
                        logger.debug(
                            "enab_character_art_version: %s | [2]"
                            % enab_character_art_version
                        )
                    # Only strCutout
                    results_strCutout = filter(
                        set_show_cast_artwork_filter2, character_arts
                    )
                    # Add Charakter Art in Kodi
                    if verboselog_adv:
                        logger.debug("All - strCutout: %s" % results_strCutout)
                    for result_strCutout in results_strCutout:
                        if verboselog_adv:
                            logger.debug(
                                "strCutout - value: {}".format(
                                    result_strCutout)
                            )
                        character_art_url = result_strCutout.get(
                            "character_art_url", ""
                        )
                        character_art_preview_url = character_art_url + "/preview"
                        if verboselog_adv:
                            logger.debug(
                                "addAvailableArtwork - strCutout - arttype=characterart {}".format(
                                    character_art_url
                                )
                            )
                        vtag.addAvailableArtwork(
                            character_art_url,
                            arttype="characterart",
                            preview=character_art_preview_url,
                        )
                if verboselog_adv:
                    logger.debug(
                        "End of creating List and save characterart -  [Addon Setting - Artwork - Enable Character Art - Add in DB]"
                    )
    # End of Character Art
    if cast:
        vtag.setCast(cast)
    return teams


def _add_season_info(show_info, vtag):
    # type: (InfoType, ListItem) -> ListItem
    """Add info for league seasons"""
    season_list = tsdb.load_season_info(
        show_info.get("idLeague", "0"), api_version)
    if not season_list:
        return []
    seasons = []
    enab_season_poster_overw = settings.ENABSEASONPOSTEROVERW
    # Switch for Leagues Poster for all Seasons - Addon Settings FALSE
    # if not enab_season_poster_overw and api_version == '2':
    if not enab_season_poster_overw:
        logger.debug(
            "enab_season_poster_overw: %s = Season Poster each Season"
            % enab_season_poster_overw
        )
        art_show_id = show_info.get("idLeague", "0")
        if verboselog_adv:
            logger.debug("art_show_id: %s " % art_show_id)
        art_show_seasons = tsdb.load_season_artwork(art_show_id, api_version)
        if verboselog_adv:
            logger.debug("Result: %s from art_show_seasons" % art_show_seasons)
        # No Season Poster for this TVShow
        if art_show_seasons is None or art_show_seasons == "No data found":
            logger.debug(
                "No Season Poster for this TVShow => Switch Addon Setting to TRUE = use League Poster for all Seasons"
            )
            # Fallback to League Poster!
            enab_season_poster_overw = True
        else:
            for art_show_season in art_show_seasons:
                season_strSeason = art_show_season.get("strSeason")
                season_strPoster_url = art_show_season.get("strPoster")
                season_strPoster_preview_url = previewurl = (
                    season_strPoster_url + "/preview"
                )
                # Problem if a Season not 2024, 2024-2025 => season	[opt] integer - number of season in case of season thumb | https://alwinesch.github.io/group__python___info_tag_video.html#gad5dfc6f76921e0127594d1744685eb56
                if season_strSeason:
                    season_num = int(season_strSeason[:4])
                    if verboselog_adv:
                        logger.debug(
                            "Season Number: %s from add_season_info (too long?)"
                            % season_strSeason
                        )
                logger.debug(
                    "Poster each Season: season_num: %s | (cut to max 4 int)"
                    % season_num
                )
                vtag.addAvailableArtwork(
                    season_strPoster_url,
                    arttype="poster",
                    preview=season_strPoster_preview_url,
                    season=season_num,
                )
                if verboselog_adv:
                    logger.debug(
                        "Poster each Season: adding poster for season %s to tvshow item"
                        % season_strSeason
                    )
        if verboselog_adv:
            logger.debug("Poster each Season: End")
    # Switch for Leagues Poster for all Seasons - Addon Settings TRUE
    if enab_season_poster_overw:
        logger.debug(
            "enab_season_poster_overw: %s = League Poster for all Seasons Poster"
            % enab_season_poster_overw
        )
        theurl = show_info.get("strPoster")
    for season in season_list:
        season_name = season.get("strSeason")
        if season_name:
            season_num = int(season_name[:4])
            if verboselog_adv:
                logger.debug(
                    "adding information for season %s to list item" % season_name
                )
            if vtag:
                vtag.addSeason(season_num, season_name)
                # Again: Switch for Leagues Poster for all Seasons - Addon Settings
                if enab_season_poster_overw:
                    if theurl:
                        previewurl = theurl + "/preview"
                        vtag.addAvailableArtwork(
                            theurl,
                            arttype="poster",
                            preview=previewurl,
                            season=season_num,
                        )
                        if verboselog_adv:
                            logger.debug(
                                "adding poster for season %s to tvshow item"
                                % season_name
                            )
            # Hier werden alle verfügbaren Staffel in die Kodi Datenbank geladen => Switch, probleme mit season Poster Dl..
            seasons.append({"season_num": season_num,
                           "season_name": season_name})
    return seasons


def _set_artwork(images, list_item):
    # type: (List, ListItem) -> ListItem
    """set the artwork for the list item"""
    vtag = list_item.getVideoInfoTag()
    fanart_list = []
    for image_type, image in images:
        if image:
            theurl = url_fix(image)
            if image_type == "fanart":
                fanart_list.append({"image": theurl})
            else:
                previewurl = theurl + "/preview"
                vtag.addAvailableArtwork(
                    theurl, arttype=image_type, preview=previewurl)
    if fanart_list:
        list_item.setAvailableFanart(fanart_list)
    return list_item


def set_episode_artwork(episode_info, list_item):
    # type: (InfoType, ListItem) -> ListItem
    """Set available images for an episode"""
    images = []
    images.append(("thumb", episode_info.get("strThumb")))
    images.append(("thumb", episode_info.get("strFanart")))
    images.append(("fanart", episode_info.get("strFanart")))
    return _set_artwork(images, list_item)


def set_show_artwork(show_info, list_item):
    # type: (InfoType, ListItem) -> ListItem
    """Set available images for a show"""
    images = []
    images.append(("fanart", show_info.get("strFanart1")))
    images.append(("fanart", show_info.get("strFanart2")))
    images.append(("fanart", show_info.get("strFanart3")))
    images.append(("fanart", show_info.get("strFanart4")))
    images.append(("poster", show_info.get("strPoster")))
    images.append(("banner", show_info.get("strBanner")))
    images.append(("clearart", show_info.get("strLogo")))
    return _set_artwork(images, list_item)


def add_main_show_info(list_item, show_info, full_info=True):
    # type: (ListItem, InfoType, bool) -> ListItem
    """Add main show info to a list item"""
    vtag = list_item.getVideoInfoTag()
    showname = show_info.get("strLeague")
    vtag.setTitle(showname)
    vtag.setOriginalTitle(showname)

### HERE HERE


#new add sort title for tvshow    
    vtag.setSortTitle(showname)
    vtag.setTvShowTitle(showname)
    vtag.setMediaType("tvshow")
    epguide = {"tsdb": str(show_info["idLeague"])}
    vtag.setEpisodeGuide(json.dumps(epguide))
    # If empty Year, example: Commonwealth Games Swimming
    if show_info.get("intFormedYear", ""):
        vtag.setYear(int(show_info.get("intFormedYear", "")[:4]))
    vtag.setPremiered(show_info.get("dateFirstEvent", ""))
    if full_info:
        _set_plot(show_info, vtag)
        # IMDB ANIDB TVDB TMDB TSDB  talk with zag 21.06.2024
        # vtag.setUniqueID(show_info.get("idLeague"), type="thesportsdb", isdefault=True)
        vtag.setUniqueID(show_info.get("idLeague"),
                         type="tsdb", isdefault=True)
        vtag.setGenres([show_info.get("strSport", "")])
        tvrights = show_info.get("strTvRights", "")
        if tvrights:
            studios = tvrights.split("\r\n")
            if studios:
                vtag.setStudios(studios)
        vtag.setCountries([show_info.get("strCountry", "")])
        list_item = set_show_artwork(show_info, list_item)
        show_info["seasons"] = _add_season_info(show_info, vtag)
        show_info["teams"] = _set_show_cast(show_info, vtag)


# Save Cache Information about League/TV Show
        cache.cache_show_info(show_info)
    else:
        image = show_info.get("strPoster")
        if image:
            theurl = url_fix(image)
            previewurl = theurl + "/preview"
            vtag.addAvailableArtwork(
                theurl, arttype="poster", preview=previewurl)
    logger.debug(
        "adding sports league information for %s to list item" % showname)
    return list_item


def add_episode_info(list_item, episode_info, full_info=True):
    # type: (ListItem, InfoType, bool) -> ListItem
    """Add episode info to a list item"""
    # strSport = episode_info.get("strSport")
    event_ID = str(episode_info.get("idEvent"))
    season = episode_info.get("strSeason", "0000")[:4]
    episode = episode_info.get("strEpisode", "0")
    title = episode_info.get("strEvent", "Episode " + episode)
    vtag = list_item.getVideoInfoTag()
    # Set EventID as TSDB ID for the Episode
    vtag.setUniqueID(event_ID, type="tsdb", isdefault=True)
    vtag.setSeason(int(season))
    vtag.setEpisode(int(episode))
    vtag.setMediaType("episode")
    air_date = episode_info.get("dateEvent")
    if air_date:
        vtag.setFirstAired(air_date)
        if not full_info:
            title = "%s.%s.%s" % (
                episode_info.get("strLeague", ""),
                air_date.replace("-", ""),
                title,
            )
    if verboselog_adv:
        logger.debug("Episode Title in TSDB: %s " % title)
    # Episoden Title
    new_title_for = episode_info["strEvent"]
    new_title_for_org = title
    # We need on too much Leagues the addon Exclude Setting...
    # Problem to dectect special Leagues, example: 'English Premier League' => NAME for Files: English Premier League 20211024 Manchester United vs Liverpool.special if date added!
    excl_strLeague = episode_info.get("strLeague", "").lower()
    if verboselog_adv:
        logger.debug(
            "Ignore League - exclude list (Addon Settings) change_ep_title_excl: %s "
            % change_ep_title_excl
        )
        logger.debug(
            "Ignore League - exclude list (Addon Settings) search excl_strLeague to search: %s "
            % excl_strLeague
        )
    # Addon Settings => Change Episode Title, add Date
    if change_ep_title:
        # Is it on the ignore list, then reset title to normal
        if excl_strLeague in change_ep_title_excl:
            if verboselog_adv:
                logger.debug(
                    "Ignore League - YES: (Addon Settings) exclude reason: %s "
                    % excl_strLeague
                )
            title = new_title_for_org
        else:
            if verboselog_adv:
                logger.debug(
                    "Change Episode Title (Addon Settings): %s " % new_title_for
                )
            # new_title_nr = episode_info['strEpisode']
            # new_title_nr = episode_info['intRound']
            new_title_date = episode_info["dateEvent"]
            new_title_date = time.strptime(new_title_date, "%Y-%m-%d")
            new_title_date = time.strftime("%a %e %b", new_title_date)
            # New Title with Date
            title = new_title_for + " - " + new_title_date
    else:
        title = new_title_for_org
        if verboselog_adv:
            logger.debug("No changes on  Episode Title: %s " % title)


    #Here we set the sort title as changed if wish!
    #vtag.setSortTitle(title)
#https://kodi.wiki/view/Databases/MyVideos#episode

    #Here we set the original title as changed if wish!
    vtag.setOriginalTitle(title)

# Problems: you can not show episode original title in episode view in kodi
# only the title, if we change the title, much tvhshows are not regnorized

# We let change the title at the Moment, Variante 1!

    #1#Here we set the original title without changing from addon setting!  
#    vtag.setTitle(new_title_for_org)     

    #2#Here we set changed title from addon setting!
    vtag.setTitle(title)

    if full_info:
        _set_plot(episode_info, vtag)
        if air_date:
            vtag.setPremiered(air_date)
        list_item = set_episode_artwork(episode_info, list_item)
        _set_episode_cast(episode_info, vtag)
        if settings.ENABTRAILER:
            trailer = _parse_trailer(episode_info.get("strVideo"))
            if trailer:
                vtag.setTrailer(trailer)
    if verboselog_adv:
        logger.debug(
            "adding episode information for S%sE%s - %s to list item"
            % (season, episode, title)
        )
    return list_item


def parse_nfo_url(nfo):
    # type: (Text) -> Optional[UrlParseResult]
    """Extract show ID from NFO file contents"""
    sid_match = None
    for regexp in SHOW_ID_REGEXPS:
        logger.debug("trying regex to match service from parsing nfo:")
        logger.debug(regexp)
        show_id_match = re.search(regexp, nfo, re.I)
        if show_id_match:
            logger.debug("match group 1: " + show_id_match.group(1))
            logger.debug("match group 2: " + show_id_match.group(2))
            # if show_id_match.group(1) == "thesportsdb":
            # IMDB ANIDB TVDB TMDB TSDB  talk with zag 21.06.2024
            if show_id_match.group(1) == "tsdb":
                sid_match = UrlParseResult(
                    show_id_match.group(1), show_id_match.group(2)
                )
                break
    return sid_match


def _set_plot(info, vtag):
    # type: (InfoType, ListItem) -> ListItem
    """Add plot for league or game"""
    desc = info.get("strDescription" + settings.LANGUAGE)
    if verboselog_adv:
        logger.debug("Full Test (language): strDescription" +
                     settings.LANGUAGE + "")
        logger.debug('Seson Descripton: "{}"'.format(desc))
    if not desc:
        desc = info.get("strDescriptionEN")
    if desc:
        plot = _clean_plot(desc)
        vtag.setPlot(plot)
        vtag.setPlotOutline(plot)


def _parse_trailer(raw_trailer):
    # type: (Text) -> Text
    """create a valid Tubed or YouTube plugin trailer URL"""
    if raw_trailer:
        if settings.PLAYERSOPT == "tubed":
            addon_player = "plugin://plugin.video.tubed/?mode=play&video_id="
        elif settings.PLAYERSOPT == "youtube":
            addon_player = "plugin://plugin.video.youtube/?action=play_video&videoid="
        trailer = url_fix(raw_trailer)
        key_matches = re.search(YOUTUBE_REGEXP, trailer, re.I)
        if key_matches:
            youtube_key = key_matches.group(1)
            if _check_youtube(trailer):
                return addon_player + youtube_key
    return None


def _check_youtube(key):
    # type: (Text) -> bool
    """check to see if the YouTube key returns a valid link"""
    chk_link = "https://www.youtube.com/watch?v=" + key
    check = api_utils.load_info(chk_link, resp_type="not_json")
    if not check or "Video unavailable" in check:  # video not available
        return False
    return True
