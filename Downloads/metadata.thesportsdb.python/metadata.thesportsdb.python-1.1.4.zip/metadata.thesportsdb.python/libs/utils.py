# -*- coding: UTF-8 -*-
#
# Copyright (C) 2024, Project Kodi
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# Code attribution:
# core based on metadata.tvshows.thesportsdb.python by pkscout
# and metadata.tvmaze scrapper by Roman Miroshnychenko aka Roman V.M.
# and the metadata.tvshows.themoviedb.org.python scraper by Team Kodi
# all created by improvements to metadata.thesportsdb.com 2015 from Project Kodi (peter0123)
#
# Addon: The Sports Database Python - metadata.thesportsdb.python
# See https://github.com/Project-Kodi/Project-Kodi.github.io/
# pylint: disable=missing-docstring


"""Misc utils"""

from __future__ import absolute_import, unicode_literals

import os
import re
import xbmc
from xbmcaddon import Addon
import urllib.parse
import xbmcvfs
import json
from datetime import datetime
from . import settings

try:
    from typing import Text, Optional, Any, Dict  # pylint: disable=unused-import
except ImportError:
    pass

# Addon Settings - Verbose logging extreme
verboselog_adv = settings.VERBOSELOGADV
overwrite_nfo = settings.OVERWRITENFO

# Addon Data ?
ADDON_ID = "metadata.tvshows.thesportsdb.python"
ADDON = Addon()

# Addon Infos
self_addon_name = ADDON.getAddonInfo("name")
self_addon_id = ADDON.getAddonInfo("id")
self_addon_version = ADDON.getAddonInfo("version")
self_addon_providername = ADDON.getAddonInfo("author")

TimeStamp = datetime.now().strftime("%d-%m-%Y %H:%M:%S")
RepositoryInfo = "https://Project-Kodi.github.io/"


class logger:
    log_message_prefix = "[{} ({})]: ".format(ADDON_ID, ADDON.getAddonInfo("version"))

    @staticmethod
    def log(message, level=xbmc.LOGDEBUG):
        # type: (Text, int) -> None
        if isinstance(message, bytes):
            message = message.decode("utf-8")
        message = logger.log_message_prefix + message
        xbmc.log(message, level)

    @staticmethod
    def info(message):
        # type: (Text) -> None
        logger.log(message, xbmc.LOGINFO)

    @staticmethod
    def error(message):
        # type: (Text) -> None
        logger.log(message, xbmc.LOGERROR)

    @staticmethod
    def debug(message):
        # type: (Text) -> None
        logger.log(message, xbmc.LOGDEBUG)


def url_fix(url):
    # type: (Text) -> Text
    """
    fixes the URL from the API results to remove escaping slashes
    """
    if url:
        return url.replace("\/", "/")
    else:
        return ""


# Function: Remove all control characters
def control_characters(dirty_str):
    clean_str = re.sub(r"[\x00-\x1f]", "", str(dirty_str))
    return clean_str


# Get correct TVShow
def nfo_correct_tvshow(nfo_str_League, spdb_vdb_id, typnfo, season_list):
    if verboselog_adv:
        logger.debug("Start function: nfo_correct_tvshow")
        logger.debug('nfo_str_League parm:  "{}"'.format(nfo_str_League))
        logger.debug('spdb_vdb_id parm:  "{}"'.format(spdb_vdb_id))
        logger.debug('season_list parm:  "{}"'.format(season_list))
    nfo_kodi_vdb_id = ""

    payload = {
        "jsonrpc": "2.0",
        "method": "VideoLibrary.GetTVShows",
        "params": {
            "filter": {"field": "title", "operator": "is", "value": nfo_str_League},
            "limits": {"start": 0, "end": 1},
            "properties": ["title", "file"],
        },
        "id": "libTvShows",
    }

    try:
        info = json.loads(xbmc.executeJSONRPC(json.dumps(payload)))
        result = info["result"]
        nfo_full_result = info["result"]["tvshows"]
        nfo_path = nfo_full_result[0]["file"]
        nfo_kodi_vdb_id = nfo_full_result[0]["tvshowid"]
        nfo_title = nfo_full_result[0]["title"]

        if verboselog_adv:
            logger.debug(
                'function: nfo_full_result - RPC - TRY - Info:  "{}"'.format(
                    nfo_full_result
                )
            )
            logger.debug("function: nfo_full_result - RPC => nfo_path: %s " % nfo_path)
            logger.debug("function: nfo_full_result - RPC => nfo_kodi_vdb_id: %s " % nfo_kodi_vdb_id)
            logger.debug("function: nfo_full_result - RPC => nfo_title: %s " % nfo_title)

    except:
        if verboselog_adv:
            logger.debug("function: nfo_correct_tvshow - RPC - except:")

    if verboselog_adv:
        logger.debug('Correct Kodi VideoDatabase TVShow ID:  "{}"'.format(spdb_vdb_id))
        logger.debug('Correct Kodi VideoDatabase nfo_path:  "{}"'.format(nfo_path))
        logger.debug(
            'Correct Kodi VideoDatabase nfo_kodi_vdb_id:  "{}"'.format(nfo_kodi_vdb_id)
        )
        logger.debug('Correct Kodi VideoDatabase nfo_title:  "{}"'.format(nfo_title))

    if typnfo == 'tvshow':   

#typnfo gegen string bei fuc aufruf austauschen!

        # Call function for NFO => tvshow // 
        if verboselog_adv:
            logger.debug('CALL NFO => TVSHOW')
        write_nfo_get_filepath_content("tvshow", nfo_path, nfo_title, nfo_kodi_vdb_id, nfo_full_result, spdb_vdb_id, season_list)
    elif typnfo == 'season':
        # Call function for NFO => season
        if verboselog_adv:
            logger.debug('CALL NFO => SEASON')
        write_nfo_get_filepath_content("season", nfo_path, nfo_title, nfo_kodi_vdb_id, nfo_full_result, spdb_vdb_id, season_list)
    elif typnfo == 'episode':
        # Call function for NFO => episode
        if verboselog_adv:
            logger.debug('CALL NFO => EPISODE')
        write_nfo_get_filepath_content("episode", nfo_path, nfo_title, nfo_kodi_vdb_id, nfo_full_result, spdb_vdb_id, season_list)



# Function: Write *.nfo file and fill it with content
def write_nfo_file_msg(filepathfull, filecontent):
    if verboselog_adv:
        logger.debug("Start function: write_nfo_file_msg")
        logger.debug('Write *.nfo Data to:  "{}"'.format(filepathfull))
        logger.debug('Write *.nfo Data content:  "{}"'.format(filecontent))
    index = 0
    # NFO - IF File exist and overwrite is off
    if verboselog_adv:
        logger.debug('overwrite_nfo (Addon Setting):  "{}"'.format(overwrite_nfo))
        logger.debug('xbmcvfs.exists:  "{}"'.format(xbmcvfs.exists(filepathfull)))

    if xbmcvfs.exists(filepathfull) and not overwrite_nfo:
        logger.debug("NFO File exist and overwrite is off - Addon Setting")
    else:
        #GIbt es den Pfad, sonst vorher anlegen
        if filepathfull.find("/") > 0:
            logger.debug("write_nfo_file: Slash or Backslah: / ")
            searchlist = filepathfull.rsplit("/", 1)
        elif filepathfull.find("\\") > 0:
            logger.debug("write_nfo_file: Slash or Backslah: \\ ")
            searchlist = filepathfull.rsplit("\\", 1)
 #Add here with one \
        filepathfull_help = searchlist[0]
        # Existiert der Pfad nicht?
        if xbmcvfs.exists(filepathfull):
            logger.debug("write_nfo_file: Pfad existiert")
        else:
            xbmcvfs.mkdirs(filepathfull_help)
            logger.debug('write_nfo_file: MKDIRS:  "{}"'.format(filepathfull_help))
        #Write NFO
        logger.debug("NFO File write is ok - Addon Setting")
        with xbmcvfs.File(filepathfull, "w") as f:
            result = f.write(
                '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
            )
            f.write("<!-- Created by "+ self_addon_name + " Version " + self_addon_version + " | Provider: " + self_addon_providername + " | Addon: " + self_addon_id + " | Repository: " + RepositoryInfo + " | Created on " + TimeStamp + " -->\n")
            while index < len(filecontent):
                f.write(str(filecontent[index]) + "")
                index += 1
            f.close()
            if result:
                logger.debug("write_nfo_file: OK")
            else:
                logger.debug("write_nfo_file: ERROR")
        logger.debug('Write *.nfo Content: "{}"'.format(filecontent))


def write_nfo_get_filepath_content(media_type, media_path, media_name, kodi_vdb_id, media_result, spdb_vdb_id, season_list):
    logger.debug("Start function: write_nfo_get_filepath_content")
    if verboselog_adv:
        logger.debug('media_type: "{}"'.format(media_type))
        logger.debug('media_path: "{}"'.format(media_path))
        logger.debug('media_name: "{}"'.format(media_name))
        logger.debug('kodi_vdb_id: "{}"'.format(kodi_vdb_id))
        logger.debug('media_result: "{}"'.format(media_result))
    # Mediatype => tvshow
    if media_type == "tvshow":
        logger.debug("function: write_nfo_get_filepath_content => Auswahl TVSHOW")

        # Ausgabe im Serien Ordner
        # Wenn Ausgabe im Serien Ordner oder eigener Pfad, write_nfo_default = true
        if settings.WRITENFODEFAULT:
            logger.debug("Auswahl: NFO im Serien Ordner speichern")
            # Dateiname = write_nfo_tvshow_filename // (tvshowtitle).nfo // tvshow.nfo default 2
            if settings.WRITENFOTVSHOWFILENAME == "1":
                logger.debug("Auswahl NFO im Serien Ordner + : (tvshowtitle).nfo")
                # Dateiname und  Pfad ändern für NFO [(tvshowtitle).nfo]
                filepathtvshow = media_path
                filepathtvshow = os.path.join(filepathtvshow)
                logger.debug('filepathtvshow: "{}"'.format(filepathtvshow))
                nfofilenametvshow = media_name
                logger.debug('title: "{}"'.format(nfofilenametvshow))
                nfofilenametvshow = nfofilenametvshow + ".nfo"
                logger.debug('nfofilenametvshow: "{}"'.format(nfofilenametvshow))
                nfofilenametvshow = filepathtvshow + nfofilenametvshow
                logger.debug('nfofilenametvshow: "{}"'.format(nfofilenametvshow))
                # NFO SCHREIBEN
                write_nfo_file_msg(
                    nfofilenametvshow,
                    create_nfo_content_tvshow(kodi_vdb_id, spdb_vdb_id),
                )

            # Dateiname = write_nfo_tvshow_filename // (tvshowtitle).nfo // tvshow.nfo default 2
            elif settings.WRITENFOTVSHOWFILENAME == "2":
                logger.debug("Auswahl NFO im Serien Ordner +: tvshow.nfo")
                filepathtvshow = media_path
                filepathtvshow = os.path.join(filepathtvshow)
                logger.debug('filepathtvshow: "{}"'.format(filepathtvshow))
                nfofilenametvshow = "tvshow.nfo"
                logger.debug('nfofilenametvshow: "{}"'.format(nfofilenametvshow))
                nfofilenametvshow = filepathtvshow + nfofilenametvshow
                logger.debug('nfofilenametvshow: "{}"'.format(nfofilenametvshow))
                # NFO SCHREIBEN
                write_nfo_file_msg(
                    nfofilenametvshow,
                    create_nfo_content_tvshow(kodi_vdb_id, spdb_vdb_id),
                )

        # Wenn Ausgabe im Serien Ordner oder eigener Pfad, write_nfo_default = false
        else:
            logger.debug("Auswahl: NFO in eigenen Ordner speichern")

            # Dateiname = write_nfo_tvshow_filename // (tvshowtitle).nfo // tvshow.nfo default 2
            if settings.WRITENFOTVSHOWFILENAME == "1":
                logger.debug("Auswahl eigener Pfad + : (tvshowtitle).nfo")
                ##Eingegebener Pfad
                nfofilenametvshowp = settings.WRITENFOWNTVSHOWPATH
                logger.debug('Auswahl eigener Pfad: "{}"'.format(nfofilenametvshowp))
                nfofilenametvshown = media_name
                logger.debug('title: "{}"'.format(nfofilenametvshown))
                testy = str(media_name)
                nfofilenametvshowf = testy + ".nfo"
                nfofilenametvshowp = xbmcvfs.translatePath(nfofilenametvshowp)
                nfofilenametvshow = os.path.join(nfofilenametvshowp, testy, nfofilenametvshowf)
                logger.debug('Auswahl eigener Pfad TEST X: "{}"'.format(nfofilenametvshow))
                # NFO SCHREIBEN
                write_nfo_file_msg(
                    nfofilenametvshow,
                    create_nfo_content_tvshow(kodi_vdb_id, spdb_vdb_id),
                )

            # Dateiname = write_nfo_tvshow_filename // (tvshowtitle).nfo // tvshow.nfo default 2
            elif settings.WRITENFOTVSHOWFILENAME == "2":
                logger.debug("Auswahl eigener Pfad +: tvshow.nfo")
                ##Eingegebener Pfad
                nfofilenametvshowp = settings.WRITENFOWNTVSHOWPATH
                logger.debug('Auswahl eigener Pfad: "{}"'.format(nfofilenametvshowp))
                ##Eingegebener Pfad + Dateiname
                testx = str(media_name)
                nfofilenametvshowp = xbmcvfs.translatePath(nfofilenametvshowp)
                nfofilenametvshow = os.path.join(nfofilenametvshowp, testx, 'tvshow.nfo')
                logger.debug('Auswahl eigener Pfad TEST X: "{}"'.format(nfofilenametvshow))
                # NFO SCHREIBEN
                write_nfo_file_msg(
                    nfofilenametvshow,
                    create_nfo_content_tvshow(kodi_vdb_id, spdb_vdb_id),
                )

    # Auswahl SEASON => Hier zu beachten, es gibt mehrere season pro tvshow
    #WRITENFOSEASONFILENAME = source_settings.get(    "write_nfo_season_filename", ADDON.getSettingString("write_nfo_season_filename"))
    elif media_type == "season":
        logger.debug("function: write_nfo_get_filepath_content => Auswahl SEASON")
         

        #Get all seasons directorys
        payload = {
            "jsonrpc": "2.0",
            "method": "Files.GetDirectory",
            "params": {
                "properties": ["showtitle", "title", "season", "episode", "file"],
                "directory": media_path,
                "media": "video",
            },
            "id": 1,
        }
        info = json.loads(xbmc.executeJSONRPC(json.dumps(payload)))
        try:
            info_files = info["result"]["files"]
            if verboselog_adv:
                logger.debug("NEW PATH TEST result:  %s " % info)
            ret = []
            for r in info_files:
                ret.append(r)
        except:
            logger.debug("Files.GetDirectory - Result: NOTHING EXCEPT res")


        # Season Loop from Get all seasons directorys
        # db_path_entry - Result loop: db_path_entry: "{'file': 'smb://192.168.1.120/Sport-Videos/Serien-tsdb/MotoGP/Season 2010/', 'filetype': 'directory', 'label': 'Season 2010', 'title': '', 'type': 'unknown'}"
        for db_path_entry in ret:
            logger.debug(
                'Files.GetDirectory - db_path_entry - Result loop: db_path_entry: "{}"'.format(
                    db_path_entry
                )
            )
            dp_path_entry_label = db_path_entry["label"]
            #Alle Zeichen bis auf 0-9 und - erhalten
            dp_path_entry_label_s = re.sub("[^0-9-]", "", db_path_entry["label"])
            dp_path_tvshow_season = db_path_entry["file"]
            seasonid_db = []

            #Get Session ID
            payload3 = {"jsonrpc":"2.0","method":"VideoLibrary.GetSeasons","params":{"tvshowid":kodi_vdb_id,"limits":{"end":120,"start":0}},"id":1}
            info3 = json.loads(xbmc.executeJSONRPC(json.dumps(payload3)))
            try:
                info_files3 = info3["result"]["seasons"]
                logger.debug('Get Session ID info_files3: "{}"'.format(info_files3))
                #Label suchen
                for r in info_files3:
                    if verboselog_adv:
                        logger.debug('Label search => r-label: "{}"'.format(r["label"]))
                        logger.debug('Label search => db_path_entry-label_s: "{}"'.format(dp_path_entry_label_s))
                    if r["label"] == dp_path_entry_label_s:
                        seasonid_db = r["seasonid"]
                        logger.debug('Found correct seasonid_db: "{}"'.format(seasonid_db))
            except Exception as error:
                logger.debug('Episode Season Loop from Get all seasons episodes directorys X => except: "{}"'.format(error))
                continue

            # remove all other chars
            dp_path_entry_label_clean = re.sub("[^0-9]", "", dp_path_entry_label)
            #  cut [4}] &  make int
            try:
                season_nr_short = int(dp_path_entry_label_clean[:4])
                season_nr = int(dp_path_entry_label_clean)


                # Wenn Ausgabe im Serien Ordner (oder eigener Pfad), write_nfo_default = true
                if settings.WRITENFODEFAULT:
                    logger.debug("Auswahl: NFO im Serien Ordner speichern")
                    # Dateiname = write_nfo_season_filename // seasonXX.nfo // season.nfo default 2

                    if settings.WRITENFOSEASONFILENAME == "1":
                        logger.debug("Auswahl NFO im Serien Ordner + /seasonxx/ + : seasonXX.nfo")
                        # NFO SCHREIBEN
                        dp_path_help = 'season' + str(season_nr_short) + '.nfo'
                        dp_path_tvshow_season = os.path.join(media_path, dp_path_help)
                        #dp_path_tvshow_season = xbmcvfs.translatePath(media_path + "season" + season_nr + ".nfo")
                        logger.debug('WRITE PATH FOR SEASON NFO: "{}"'.format(dp_path_tvshow_season))
                        write_nfo_file_msg(dp_path_tvshow_season, create_nfo_content_season(kodi_vdb_id, spdb_vdb_id, seasonid_db),)

                    # Dateiname = write_nfo_season_filename // seasonXX.nfo // season.nfo default 2
                    elif settings.WRITENFOSEASONFILENAME == "2":
                        logger.debug("Auswahl NFO im Serien Ordner +: season.nfo")
                        # NFO SCHREIBEN
                        dp_path_tvshow_season = os.path.join(dp_path_tvshow_season, 'season.nfo')
                        #dp_path_tvshow_season = xbmcvfs.translatePath(dp_path_tvshow_season + "season.nfo")
                        logger.debug('WRITE PATH FOR SEASON NFO: "{}"'.format(dp_path_tvshow_season))
                        write_nfo_file_msg(dp_path_tvshow_season, create_nfo_content_season(kodi_vdb_id, spdb_vdb_id, seasonid_db),)


                # Wenn eigener Pfad (oder Ausgabe im Serien Ordner), write_nfo_default = false
                #WRITENFOWNSEASONPATH = source_settings.get(    "write_nfo_own_season_path", ADDON.getSettingString("write_nfo_own_season_path"))        
                else:
                    logger.debug("Auswahl: NFO in eigenen Ordner speichern")

                    # Dateiname = write_nfo_season_filename // seasonXX.nfo // season.nfo default 2
                    if settings.WRITENFOSEASONFILENAME == "1":
                        logger.debug("Auswahl eigener Pfad + /tvshwow/ + : seasonXX.nfo")
                        ##Eingegebener Pfad
                        nfofilenameseasonp = settings.WRITENFOWNSEASONPATH
                        logger.debug('Auswahl eigener Pfad: "{}"'.format(nfofilenameseasonp))
                        #=> TV SHow Folder in Path.. eigener pfad/tvshow/seasonxx.nfo              
                        nfofilenameseasonp = xbmcvfs.translatePath(nfofilenameseasonp)     
                        dp_path_help = 'season' + str(season_nr_short) + '.nfo'
                        #dp_path_tvshow_season = nfofilenameseasonp + media_name + "/" + season_nr + ".nfo"
                        dp_path_tvshow_season = os.path.join(nfofilenameseasonp, media_name, dp_path_help)

                        logger.debug('WRITE PATH FOR SEASON NFO: "{}"'.format(dp_path_tvshow_season))
                        # NFO SCHREIBEN
                        write_nfo_file_msg(dp_path_tvshow_season, create_nfo_content_season(kodi_vdb_id, spdb_vdb_id, seasonid_db),)

                    # Dateiname = write_nfo_season_filename // seasonXX.nfo // season.nfo default 2
                    elif settings.WRITENFOSEASONFILENAME == "2":
                        logger.debug("Auswahl eigener Pfad + /tvshwow/seasonXX/ + : season.nfo")
                        ##Eingegebener Pfad
                        nfofilenameseasonp = settings.WRITENFOWNSEASONPATH
                        logger.debug('Auswahl eigener Pfad: "{}"'.format(nfofilenameseasonp))
                        #=> TV SHow Folder in Path.. eigener pfad/tvshow/seasonxx/season.nfo
                        nfofilenameseasonp = xbmcvfs.translatePath(nfofilenameseasonp)
                        #dp_path_tvshow_season = nfofilenameseasonp + media_name + '/' + dp_path_entry_label + '/' + "season.nfo"
                        dp_path_tvshow_season = os.path.join(nfofilenameseasonp, media_name, dp_path_entry_label, 'season.nfo')
                        logger.debug('WRITE PATH FOR SEASON NFO: "{}"'.format(dp_path_tvshow_season))
                        # NFO SCHREIBEN
                        write_nfo_file_msg(dp_path_tvshow_season, create_nfo_content_season(kodi_vdb_id, spdb_vdb_id, seasonid_db),)

            except Exception as error:
                logger.debug('Season Loop from Get all seasons directorys => except: "{}"'.format(error))
                print(type(error))    # the exception type
                print(error.args)     # arguments stored in .args
                print(error)  


                continue

    # Auswahl EPISODE  => Hier zu beachten, es gibt mehrere episoden je season und tvshow
    #WRITENFOEPISODEFILENAME = source_settings.get(    "write_nfo_episode_filename", ADDON.getSettingString("write_nfo_episode_filename"))
    elif media_type == "episode":
        logger.debug("function: write_nfo_get_filepath_content => Auswahl EPISODE")

#Mehr Felder! + => https://kodi.wiki/view/JSON-RPC_API/v13#Video.Details.Episode

#("invalid literal for int() with base 10: 'Seas'",)

        #Get all seasons directorys from kodi db/os
        payload = {
            "jsonrpc": "2.0",
            "method": "Files.GetDirectory",
            "params": {
                "properties": ["showtitle", "title", "season", "episode", "file"],
                "directory": media_path,
                "media": "video",
            },
            "id": 1,
        }
        info = json.loads(xbmc.executeJSONRPC(json.dumps(payload)))
        try:
            info_files = info["result"]["files"]
            if verboselog_adv:
                logger.debug("NEW PATH TEST result episode:  %s " % info)
            ret = []
            for r in info_files:
                ret.append(r)
        except:
            logger.debug("Files.GetDirectory - Result: NOTHING EXCEPT episode res")

            
        #paths from seasons
        for db_path_entry in ret:
            logger.debug('Files.GetDirectory - db_path_entry - episode - Result loop: db_path_entry: "{}"'.format(db_path_entry))
            logger.debug('Files.GetDirectory - db_path_entry - episode - Result loop: db_path_entry file: "{}"'.format(db_path_entry['file'])) 
            dp_path_entry_label = db_path_entry["label"]         

            #Für jeden Tvshow Seasons Ordner, RPC Call, welche Episoden liegen darin
            payload2 = {
                "jsonrpc": "2.0",
                "method": "Files.GetDirectory",
                "params": {
                    "properties": ["showtitle", "title", "season", "episode", "file"],
                    "directory": db_path_entry['file'],
                    "media": "video"
                },
                "type":"episode",
                "id": 1
            }
            info2 = json.loads(xbmc.executeJSONRPC(json.dumps(payload2)))
            try:
                info_files2 = info2["result"]["files"]
                for r2 in info_files2:
                    logger.debug('Loop in Tv show - season - each episode: "{}"'.format(r2))

                    episode_nr = r2["episode"]
                    episode_id = r2["id"]

                    # Wenn Ausgabe im Serien Ordner (oder eigener Pfad), write_nfo_default = true
                    if settings.WRITENFODEFAULT:
                        logger.debug("Auswahl: NFO im Serien Ordner speichern")

                        # Dateiname = write_nfo_episode_filename // (episodefilename).nfo default 1
                        if settings.WRITENFOEPISODEFILENAME == "1":
                            logger.debug("Auswahl NFO im Serien Ordner  tvshow/seasonxx/(episodefilename).nfo")
                            dp_path_r2_file = r2["file"]
                            logger.debug('Loop in Tv show - season - each episode: Problem r2file "{}"'.format(dp_path_r2_file))
                            #Get Filename
                            if dp_path_r2_file.find("/") > 0:
                                logger.debug("write_nfo_file dp_path_r2_file: Slash or Backslah: / ")
                                dp_path_tvshow_episodef = dp_path_r2_file.rsplit("/")[-1]
                            elif dp_path_r2_file.find("\\") > 0:
                                logger.debug("write_nfo_file dp_path_r2_file: Slash or Backslah: \\ ")
                                dp_path_tvshow_episodef = dp_path_r2_file.rsplit("\\")[-1]
                            logger.debug('Loop in Tv show - season - each episode: dp_path_tvshow_episodef "{}"'.format(dp_path_tvshow_episodef))
                            #Create NFO Filename
                            res = dp_path_tvshow_episodef.rsplit('.', 1) 
                            logger.debug('Loop in Tv show - season - each episode: res "{}"'.format(res))                      
                            dp_path_tvshow_episodef = str(res[0]) + '.nfo'
                            logger.debug('Loop in Tv show - season - each episode: dp_path_tvshow_episodef end "{}"'.format(dp_path_tvshow_episodef)) 
                            dp_path_tvshow_episode = os.path.join(db_path_entry['file'], dp_path_tvshow_episodef)
                            logger.debug('WRITE PATH FOR EPISODE NFO: "{}"'.format(dp_path_tvshow_episode))
                            write_nfo_file_msg(dp_path_tvshow_episode, create_nfo_content_episode(kodi_vdb_id, spdb_vdb_id, episode_nr, episode_id, dp_path_entry_label),)

       
                    #WRITENFOWNEPISODEPATH = source_settings.get("write_nfo_own_episode_path", ADDON.getSettingString("write_nfo_own_episode_path"))       
                    else:
                        logger.debug("Auswahl: NFO in eigenen Ordner speichern")

                        # Dateiname = write_nfo_episode_filename // (episodefilename).nfo default 1
                        if settings.WRITENFOEPISODEFILENAME == "1":
                            logger.debug("Auswahl: NFO in eigenen Ordner speichern + /tvshow/seasonxx/(episodefilename).nfo")

                            ##Eingegebener Pfad
                            nfofilenameepisodep = settings.WRITENFOWNEPISODEPATH
                            logger.debug('Auswahl eigener Pfad: "{}"'.format(nfofilenameepisodep))
                            ##Eingegebener Pfad +TVShow Folder/+ Season/ + Dateiname
                            nfofilenameseasonp = xbmcvfs.translatePath(nfofilenameepisodep)
                            dp_path_r2_file = r2["file"]
                            logger.debug('Loop in Tv show - season - each episode: Problem r2file "{}"'.format(dp_path_r2_file))
                            #Create Filename
                            #Get Filename
                            if dp_path_r2_file.find("/") > 0:
                                logger.debug("write_nfo_file dp_path_r2_file: Slash or Backslah: / ")
                                dp_path_tvshow_episodef = dp_path_r2_file.rsplit("/")[-1]
                            elif dp_path_r2_file.find("\\") > 0:
                                logger.debug("write_nfo_file dp_path_r2_file: Slash or Backslah: \\ ")
                                dp_path_tvshow_episodef = dp_path_r2_file.rsplit("\\")[-1]
                            logger.debug('Loop in Tv show - season - each episode: dp_path_tvshow_episodef "{}"'.format(dp_path_tvshow_episodef))
                            #Create NFO Filename
                            res = dp_path_tvshow_episodef.rsplit('.', 1) 
                            logger.debug('Loop in Tv show - season - each episode: res "{}"'.format(res))                      
                            dp_path_tvshow_episodef = str(res[0]) + '.nfo'
                            logger.debug('Loop in Tv show - season - each episode: dp_path_tvshow_episodef end "{}"'.format(dp_path_tvshow_episodef)) 
                            #Build Path
                            dp_path_tvshow_episode = os.path.join(nfofilenameseasonp, media_name, dp_path_entry_label, dp_path_tvshow_episodef)
                            logger.debug('WRITE PATH FOR EPISODE NFO: "{}"'.format(dp_path_tvshow_episode))
                            #Send to writer..
                            logger.debug('WRITE PATH FOR EPISODE NFO: "{}"'.format(dp_path_tvshow_episode))
                            write_nfo_file_msg(dp_path_tvshow_episode, create_nfo_content_episode(kodi_vdb_id, spdb_vdb_id, episode_nr, episode_id, dp_path_entry_label),)

            except Exception as error:
                logger.debug('Episode Season Loop from Get all seasons episodes directorys => except: "{}"'.format(error))
                print(type(error))    # the exception type
                print(error.args)     # arguments stored in .args
                print(error)  
                continue


# Function: NFO Content SEASON => https://kodi.wiki/view/NFO_files/Templates
def create_nfo_content_season(kodi_vdb_id, spdb_vdb_id, season_id):
    logger.debug("Start function: create_nfo_content_season")

###==> Error hier, manchmal leer!
    logger.debug('Start function: create_nfo_content_season = season_id: "{}"'.format(season_id))


    #Get Season Infos
    payload = {
        "jsonrpc": "2.0",
        "method": "VideoLibrary.GetSeasonDetails",
        "params": {
            "properties": [
                "season",
                "showtitle",
                "playcount",
                "episode",
                "fanart",
                "thumbnail",
                "tvshowid",
                "watchedepisodes",
                "art",
                "userrating",
                "title",
            ],
            "seasonid": season_id,
        },
        "id": 1,
    }

    info = json.loads(xbmc.executeJSONRPC(json.dumps(payload)))
    full_result = info["result"]["seasondetails"]
    full_result_art = full_result["art"]
    logger.debug('NEW TEST full_result full_result "{}"'.format(full_result))
    logger.debug('create_nfo_content_season // create_nfo_content_season full_result_art: "{}"'.format(full_result_art))

     # Anfang SEASON
    nfo_content_episode = ["<season>\n"]
    # Titel
    if "title" in full_result:
        nfo_content_episode.append("\t<title>" + full_result["title"] + "</title>\n")
    if "showtitle" in full_result:
        nfo_content_episode.append(
            "\t<showtitle>" + full_result["showtitle"] + "</showtitle>\n"
        )
    if "showtitle" in full_result:
        nfo_content_episode.append(
            "\t<originaltitle>" + full_result["showtitle"] + "</originaltitle>\n"
        )
    if "sorttitle" in full_result:
        nfo_content_episode.append(
            "\t<sorttitle>" + full_result["sorttitle"] + "</sorttitle>\n"
        )
    # Season
    if "season" in full_result:
        nfo_content_episode.append(
            "\t<seasonnumber>" + str(full_result["season"]) + "</seasonnumber>\n"
        )
    # Databse Kodi ID from Movie
    nfo_content_episode.append("\t<id>" + str(kodi_vdb_id) + "</id>\n")
    # Database Number Sportsdb
    nfo_content_episode.append(
        '\t<uniqueid default="true" type="tsdb">'
        + spdb_vdb_id
        + "</uniqueid> <!-- https://www.thesportsdb.com/ --> \n"
    )
    nfo_content_episode.append(
        '\t<uniqueid default="false" type="thesportsdb">'
        + spdb_vdb_id
        + "</uniqueid> <!-- https://www.thesportsdb.com/ --> \n"
    )
    nfo_content_episode.append(
        "\t<tsdb>" + spdb_vdb_id + "</tsdb> <!-- https://www.thesportsdb.com/ --> \n"
    )
    # Pictures
    if "tvshow.banner" in full_result_art:
        tmp_full_result_banner = urllib.parse.unquote(full_result_art["tvshow.banner"]).replace("image://", "")
        nfo_content_episode.append(
            '\t<thumb aspect="banner">'
            + tmp_full_result_banner.replace(".jpg/", ".jpg")
            + "</thumb>\n"
        )
    if "'tvshow.fanart" in full_result_art:
        tmp_full_result_fanartl = urllib.parse.unquote(full_result_art["'tvshow.fanart"]).replace("image://", "")
        nfo_content_episode.append(
            '\t<thumb aspect="landscape">'
            + tmp_full_result_fanartl.replace(".jpg/", ".jpg")
            + "</thumb>\n"
        )
    if "tvshow.poster" in full_result_art:
        tmp_full_result_poster = urllib.parse.unquote(full_result_art["tvshow.poster"]).replace("image://", "")
        nfo_content_episode.append(
            '\t<thumb aspect="poster">'
            + tmp_full_result_poster.replace(".jpg/", ".jpg")
            + "</thumb>\n"
        )
    # Fanart
    if "tvshow.fanart" in full_result_art:
        tmp_full_result_fanart = urllib.parse.unquote(full_result_art["tvshow.fanart"]).replace("image://", "")
        nfo_content_episode.append(
            '\t<fanart><thumb colors="" preview="">'
            + tmp_full_result_fanart.replace(".jpg/", ".jpg")
            + "</thumb></fanart>\n"
        )
    # Clearlogo
    if "tvshow.clearlogo" in full_result_art:
        tmp_full_result_clearlogo = urllib.parse.unquote(full_result_art["tvshow.clearlogo"]).replace("image://", "")
        nfo_content_episode.append(
            '\t<thumb aspect="clearlogo">'
            + tmp_full_result_clearlogo.replace(".png/", ".png")
            + "</thumb>\n"
        )
    # Clearart
    if "tvshow.clearart" in full_result_art:
        tmp_full_result_clearlogo = urllib.parse.unquote(full_result_art["tvshow.clearart"]).replace("image://", "")
        nfo_content_episode.append(
            '\t<thumb aspect="clearart">'
            + tmp_full_result_clearlogo.replace(".png/", ".png")
            + "</clearart>\n"
        )
    # CharacterArt
    if "tvshow.characterart" in full_result_art:
        tmp_full_result_characterart = urllib.parse.unquote(full_result_art["tvshow.characterart"]).replace("image://", "")
        nfo_content_episode.append(
            '\t<thumb aspect="characterart">'
            + tmp_full_result_characterart.replace(".png/", ".png")
            + "</thumb>\n"
        )
    if "tvshow.characterart1" in full_result_art:
        tmp_full_result_characterart =  urllib.parse.unquote(full_result_art["tvshow.characterart1"]).replace("image://", "")
        nfo_content_episode.append(
            '\t<thumb aspect="characterart">'
            + tmp_full_result_characterart.replace(".png/", ".png")
            + "</thumb>\n"
        )
    if "tvshow.characterart2" in full_result_art:
        tmp_full_result_characterart = urllib.parse.unquote(full_result_art["tvshow.characterart2"]).replace("image://", "")
        nfo_content_episode.append(
            '\t<thumb aspect="characterart">'
            + tmp_full_result_characterart.replace(".png/", ".png")
            + "</thumb>\n"
        )
    if "tvshow.characterart3" in full_result_art:
        tmp_full_result_characterart = urllib.parse.unquote(full_result_art["tvshow.characterart3"]).replace("image://", "")
        nfo_content_episode.append(
            '\t<thumb aspect="characterart">'
            + tmp_full_result_characterart.replace(".png/", ".png")
            + "</thumb>\n"
        )
    if "tvshow.characterart4" in full_result_art:
        tmp_full_result_characterart = urllib.parse.unquote(full_result_art["tvshow.characterart4"]).replace("image://", "")
        nfo_content_episode.append(
            '\t<thumb aspect="characterart">'
            + tmp_full_result_characterart.replace(".png/", ".png")
            + "</thumb>\n"
        )
    if "tvshow.characterart5" in full_result_art:
        tmp_full_result_characterart = urllib.parse.unquote(full_result_art["tvshow.characterart5"]).replace("image://", "")
        nfo_content_episode.append(
            '\t<thumb aspect="characterart">'
            + tmp_full_result_characterart.replace(".png/", ".png")
            + "</thumb>\n"
        )
    if "tvshow.characterart6" in full_result_art:
        tmp_full_result_characterart = urllib.parse.unquote(full_result_art["tvshow.characterart6"]).replace("image://", "")
        nfo_content_episode.append(
            '\t<thumb aspect="characterart">'
            + tmp_full_result_characterart.replace(".png/", ".png")
            + "</thumb>\n"
        )
    if "tvshow.characterart7" in full_result_art:
        tmp_full_result_characterart = urllib.parse.unquote(full_result_art["tvshow.characterart7"]).replace("image://", "")
        nfo_content_episode.append(
            '\t<thumb aspect="characterart">'
            + tmp_full_result_characterart.replace(".png/", ".png")
            + "</thumb>\n"
        )
    if "tvshow.characterart8" in full_result_art:
        tmp_full_result_characterart = urllib.parse.unquote(full_result_art["tvshow.characterart8"]).replace("image://", "")
        nfo_content_episode.append(
            '\t<thumb aspect="characterart">'
            + tmp_full_result_characterart.replace(".png/", ".png")
            + "</thumb>\n"
        )
    if "tvshow.characterart9" in full_result_art:
        tmp_full_result_characterart = urllib.parse.unquote(full_result_art["tvshow.characterart9"]).replace("image://", "")
        nfo_content_episode.append(
            '\t<thumb aspect="characterart">'
            + tmp_full_result_characterart.replace(".png/", ".png")
            + "</thumb>\n"
        )

    # Ende SEASON
    nfo_content_episode.append("</season>\n")
    return nfo_content_episode






# Function: NFO Content EPISODE => https://kodi.wiki/view/NFO_files/Templates
# Shit RPC GetEpisodeDetails is broken.... other way..
def create_nfo_content_episode(kodi_vdb_id, spdb_vdb_id, episode_nr, episode_id, season_nr):    
    logger.debug("Start function: create_nfo_content_episode")


##ERROR IST HIER! erledigt
    season_label = season_nr
    season_nr = re.sub("[^0-9]", "", season_label)
    season_nr = int(season_nr[:4])
    payload3 = {"params": { "season": season_nr, "tvshowid": kodi_vdb_id, "properties": ["title","firstaired","playcount","runtime","season","episode","showtitle","streamdetails","lastplayed","file","tvshowid","dateadded","uniqueid","seasonid"]}, "jsonrpc": "2.0", "method": "VideoLibrary.GetEpisodes", "id": 1}
    info3 = json.loads(xbmc.executeJSONRPC(json.dumps(payload3)))
    full_result3 = info3["result"]["episodes"]
    logger.debug('create_nfo_content_episode => full_result3: "{}"'.format(full_result3))
#Achtung episode_id = idEpisode // episode_nr = in tvshow/season/explizit episode.

    #Search Episode
    correct_episode_info = []
    for r in full_result3:
        if r["episodeid"] == episode_id:
            correct_episode_info.append(r)
            logger.debug('Found correct Episode with episodeID: "{}"'.format(r["episodeid"]))
    logger.debug('Found correct Episode correct_episode_info: "{}"'.format(correct_episode_info))
    search_str = str(correct_episode_info)
    correct_episode_info_stream = correct_episode_info[0]["streamdetails"]
    #logger.debug('Found correct Episode correct_episode_info_stream - all: "{}"'.format(correct_episode_info_stream))
    # Anfang EPISODE
    nfo_content_episode = ["<episodedetails>\n"]
    logger.debug('Found correct Episode correct_episode_info => correct_episode_info-title: "{}"'.format(correct_episode_info[0]["title"]))
    # Titel
    if "title" in search_str:
        nfo_content_episode.append("\t<title>" + correct_episode_info[0]["title"] + "</title>\n")
 
    if "showtitle" in search_str:
         nfo_content_episode.append(
            "\t<showtitle>" + correct_episode_info[0]["showtitle"] + "</showtitle>\n"
        )
    #Original Title
    if "title" in search_str:
         nfo_content_episode.append(
            "\t<originaltitle>" + correct_episode_info[0]["title"] + "</originaltitle>\n"
        )
    #Sorttitle     
    if "label" in search_str:
        nfo_content_episode.append(
            "\t<sorttitle>" + correct_episode_info[0]["label"] + "</sorttitle>\n"
        )      
    # Season
    if "season" in search_str:
        nfo_content_episode.append(
            "\t<season>" + str(correct_episode_info[0]["season"]) + "</season>\n"
        )
    # Episoden Anzahl
    if "episode" in search_str:
        nfo_content_episode.append(
            "\t<episode>" + str(correct_episode_info[0]["episode"]) + "</episode>\n"
        )
##Other IDS this are from league/tvshow
    # Database Number Sportsdb - 
    nfo_content_episode.append(
        '\t<uniqueid default="true" type="tsdb">'
        + spdb_vdb_id
        + "</uniqueid> <!-- https://www.thesportsdb.com/ --> \n"
    )
    nfo_content_episode.append(
        '\t<uniqueid default="false" type="thesportsdb">'
        + spdb_vdb_id
        + "</uniqueid> <!-- https://www.thesportsdb.com/ --> \n"
    )
    nfo_content_episode.append(
        "\t<tsdb>" + spdb_vdb_id + "</tsdb> <!-- https://www.thesportsdb.com/ --> \n"
    )
    if "firstaired" in search_str:
        nfo_content_episode.append(
            "\t<firstaired>" + correct_episode_info[0]["firstaired"] + "</firstaired>\n"
        )

    if "playcount" in search_str:
        nfo_content_episode.append(
            "\t<playcount>" + str(correct_episode_info[0]["playcount"]) + "</playcount>\n"
        )

    if "firstaired" in search_str:
        nfo_content_episode.append(
            "\t<firstaired>" + correct_episode_info[0]["firstaired"] + "</firstaired>\n"
        )

    if "runtime" in search_str:
        nfo_content_episode.append(
            "\t<runtime>" + str(correct_episode_info[0]["runtime"]) + "</runtime>\n"
        )
    # Extra01 - TVShow Pfad
    if "file" in search_str:
        nfo_content_episode.append(
            "\t<episodepath>" + str(correct_episode_info[0]["file"]) + "</tvshowpath>\n"
        )



    # Ende EPISODE
    nfo_content_episode.append("</episodedetails>\n")
    return nfo_content_episode



# Function: NFO Content TVSHOW => https://kodi.wiki/view/NFO_files/Templates
def create_nfo_content_tvshow(kodi_vdb_id, spdb_vdb_id):
    logger.debug("Start function: create_nfo_content_tvshow")
    if verboselog_adv:
        logger.debug('kodi_vdb_id: "{}"'.format(kodi_vdb_id))

    payload = {
        "jsonrpc": "2.0",
        "method": "VideoLibrary.GetTVShowDetails",
        "params": {
            "properties": [
                "title",
                "genre",
                "year",
                "rating",
                "plot",
                "studio",
                "mpaa",
                "cast",
                "playcount",
                "episode",
                "imdbnumber",
                "premiered",
                "votes",
                "lastplayed",
                "fanart",
                "thumbnail",
                "file",
                "originaltitle",
                "sorttitle",
                "episodeguide",
                "season",
                "watchedepisodes",
                "dateadded",
                "tag",
                "art",
                "userrating",
                "ratings",
                "runtime",
                "uniqueid",
            ],
            "tvshowid": kodi_vdb_id,
        },
        "id": 1,
    }
    info = json.loads(xbmc.executeJSONRPC(json.dumps(payload)))
    result = info["result"]
    full_result = info["result"]["tvshowdetails"]
    if verboselog_adv:
        logger.debug('RPC CALL Result: "{}"'.format(result))
    # Anfang TVSHOW
    nfo_content_tvshow = ["<tvshow>\n"]
    nfo_content_tvshow.append(
        "\t<dateadded>" + full_result["dateadded"] + "</dateadded>\n"
    )
    # Titel
    # if full_result['title']:
    if "title" in full_result:
        nfo_content_tvshow.append("\t<title>" + full_result["title"] + "</title>\n")
    # if full_result['label']:
    if "label" in full_result:
        nfo_content_tvshow.append(
            "\t<showtitle>" + full_result["label"] + "</showtitle>\n"
        )
    # if full_result['originaltitle']:
    if "originaltitle" in full_result:
        nfo_content_tvshow.append(
            "\t<originaltitle>" + full_result["originaltitle"] + "</originaltitle>\n"
        )
    # if full_result['sorttitle']:
    if "sorttitle" in full_result:
        nfo_content_tvshow.append(
            "\t<sorttitle>" + full_result["sorttitle"] + "</sorttitle>\n"
        )
    # Season
    # if full_result['season']:
    if "season" in full_result:
        nfo_content_tvshow.append(
            "\t<season>" + str(full_result["season"]) + "</season>\n"
        )
    # Episoden Anzahl! - Achtung, Anzahl an gespeicherten Kodi Episoden und nicht von Scraper! = zeigt eventuell weniger als es zur Gänze gibt
    # if full_result['episode']:
    if "episode" in full_result:
        nfo_content_tvshow.append(
            "\t<episode>" + str(full_result["episode"]) + "</episode>\n"
        )
    # Votes - TSDB
    # if full_result['votes']:
    if "votes" in full_result:
        nfo_content_tvshow.append("\t<votes>" + full_result["votes"] + "</votes>\n")
    # User Ratings
    # if full_result['userrating']:
    if "userrating" in full_result:
        nfo_content_tvshow.append(
            "\t<userrating>" + str(full_result["userrating"]) + "</userrating>\n"
        )
    nfo_content_tvshow.append("\t<top250></top250>\n")
    # Plot and Tags
    # if full_result['plot']:
    if "plot" in full_result:
        nfo_content_tvshow.append(
            "\t<outline>" + control_characters(full_result["plot"]) + "</outline>\n"
        )
    # if full_result['plot']:
    if "plot" in full_result:
        nfo_content_tvshow.append(
            "\t<plot>" + control_characters(full_result["plot"]) + "</plot>\n"
        )
    # if full_result['runtime']:
    if "runtime" in full_result:
        nfo_content_tvshow.append(
            "\t<runtime>" + str(full_result["runtime"]) + "</runtime>\n"
        )
    # Pictures
    full_result_art = full_result["art"]
    # if full_result_art['banner']:
    if "banner" in full_result_art:
        tmp_full_result_banner = urllib.parse.unquote(full_result_art["banner"]).replace("image://", "")
        nfo_content_tvshow.append(
            '\t<thumb aspect="banner">'
            + tmp_full_result_banner.replace(".jpg/", ".jpg")
            + "</thumb>\n"
        )
    if "fanart" in full_result_art:
        tmp_full_result_fanartl = urllib.parse.unquote(full_result_art["fanart"]).replace("image://", "")
        nfo_content_tvshow.append(
            '\t<thumb aspect="landscape">'
            + tmp_full_result_fanartl.replace(".jpg/", ".jpg")
            + "</thumb>\n"
        )
    if "poster" in full_result_art:
        tmp_full_result_poster = urllib.parse.unquote(full_result_art["poster"]).replace("image://", "")
        nfo_content_tvshow.append(
            '\t<thumb aspect="poster">'
            + tmp_full_result_poster.replace(".jpg/", ".jpg")
            + "</thumb>\n"
        )
# More Fanart!!
    # Fanart
    if "fanart" in full_result_art:
        tmp_full_result_fanart = urllib.parse.unquote(full_result_art["fanart"]).replace("image://", "")
        nfo_content_tvshow.append(
            '\t<fanart><thumb colors="" preview="">'
            + tmp_full_result_fanart.replace(".jpg/", ".jpg")
            + "</thumb></fanart>\n"
        )
    # Clearlogo
    if "clearlogo" in full_result_art:
        tmp_full_result_clearlogo = urllib.parse.unquote(full_result_art["clearlogo"]).replace("image://", "")
        nfo_content_tvshow.append(
            '\t<thumb aspect="clearlogo">'
            + tmp_full_result_clearlogo.replace(".png/", ".png")
            + "</thumb>\n"
        )
    # CharacterArt
    if "characterart" in full_result_art:
        tmp_full_result_characterart = urllib.parse.unquote(full_result_art["characterart"]).replace("image://", "")
        nfo_content_tvshow.append(
            '\t<thumb aspect="characterart">'
            + tmp_full_result_characterart.replace(".png/", ".png")
            + "</thumb>\n"
        )
    if "characterart1" in full_result_art:
        tmp_full_result_characterart =  urllib.parse.unquote(full_result_art["characterart1"]).replace("image://", "")
        nfo_content_tvshow.append(
            '\t<thumb aspect="characterart">'
            + tmp_full_result_characterart.replace(".png/", ".png")
            + "</thumb>\n"
        )
    if "characterart2" in full_result_art:
        tmp_full_result_characterart = urllib.parse.unquote(full_result_art["characterart2"]).replace("image://", "")
        nfo_content_tvshow.append(
            '\t<thumb aspect="characterart">'
            + tmp_full_result_characterart.replace(".png/", ".png")
            + "</thumb>\n"
        )
    if "characterart3" in full_result_art:
        tmp_full_result_characterart = urllib.parse.unquote(full_result_art["characterart3"]).replace("image://", "")
        nfo_content_tvshow.append(
            '\t<thumb aspect="characterart">'
            + tmp_full_result_characterart.replace(".png/", ".png")
            + "</thumb>\n"
        )
    if "characterart4" in full_result_art:
        tmp_full_result_characterart = urllib.parse.unquote(full_result_art["characterart4"]).replace("image://", "")
        nfo_content_tvshow.append(
            '\t<thumb aspect="characterart">'
            + tmp_full_result_characterart.replace(".png/", ".png")
            + "</thumb>\n"
        )
    if "characterart5" in full_result_art:
        tmp_full_result_characterart = urllib.parse.unquote(full_result_art["characterart5"]).replace("image://", "")
        nfo_content_tvshow.append(
            '\t<thumb aspect="characterart">'
            + tmp_full_result_characterart.replace(".png/", ".png")
            + "</thumb>\n"
        )
    if "characterart6" in full_result_art:
        tmp_full_result_characterart = urllib.parse.unquote(full_result_art["characterart6"]).replace("image://", "")
        nfo_content_tvshow.append(
            '\t<thumb aspect="characterart">'
            + tmp_full_result_characterart.replace(".png/", ".png")
            + "</thumb>\n"
        )
    if "characterart7" in full_result_art:
        tmp_full_result_characterart = urllib.parse.unquote(full_result_art["characterart7"]).replace("image://", "")
        nfo_content_tvshow.append(
            '\t<thumb aspect="characterart">'
            + tmp_full_result_characterart.replace(".png/", ".png")
            + "</thumb>\n"
        )
    if "characterart8" in full_result_art:
        tmp_full_result_characterart = urllib.parse.unquote(full_result_art["characterart8"]).replace("image://", "")
        nfo_content_tvshow.append(
            '\t<thumb aspect="characterart">'
            + tmp_full_result_characterart.replace(".png/", ".png")
            + "</thumb>\n"
        )
    if "characterart9" in full_result_art:
        tmp_full_result_characterart = urllib.parse.unquote(full_result_art["characterart9"]).replace("image://", "")
        nfo_content_tvshow.append(
            '\t<thumb aspect="characterart">'
            + tmp_full_result_characterart.replace(".png/", ".png")
            + "</thumb>\n"
        )

    # Season Poster
    # <thumb aspect="poster" season="0" type="season">https://image.tmdb.org/t/p/original/65fnzCKkyx8xZPvmIf7PhhyXZI9.jpg</thumb>
    # <thumb aspect="poster" season="1" type="season">https://image.tmdb.org/t/p/original/tGII1c84fhml9jYclHJiB3Yy4Vc.jpg</thumb>
    # Other Artwork
    # <thumb aspect="clearart">http://assets.fanart.tv/fanart/tv/72173/hdclearart/arrested-development-51581b135e99e.png</thumb>
    # nfo_content_tvshow.append('\t<thumb spoof="" cache="" aspect="discart" preview="">https://assets.fanart.tv/fanart/movies/476669/moviedisc/the-kings-man-617786bba9b7f.png</thumb>\n')
    # nfo_content_tvshow.append('\t<thumb spoof="" cache="" aspect="keyart" preview="">https://assets.fanart.tv/fanart/movies/476669/movieposter/the-kings-man-5f468bd247c3b.jpg</thumb>\n')
    # Set Artwork
    # nfo_content_tvshow.append('\t<thumb spoof="" cache="" aspect="set.clearlogo" preview="">https://assets.fanart.tv/fanart/movies/391860/hdmovielogo/kingsman-collection-5a69d2e6eaa21.png</thumb>\n')
    # nfo_content_tvshow.append('\t<thumb spoof="" cache="" aspect="set.keyart" preview="">https://assets.fanart.tv/fanart/movies/391860/movieposter/kingsman-collection-5add0aa47e577.jpg</thumb>\n')
    # nfo_content_tvshow.append('\t<thumb spoof="" cache="" aspect="set.banner" preview="">https://assets.fanart.tv/fanart/movies/391860/moviebanner/kingsman-collection-5a691aee3c1e1.jpg</thumb>\n')
    # nfo_content_tvshow.append('\t<thumb spoof="" cache="" aspect="set.poster" preview="">https://image.tmdb.org/t/p/original/xMsRZIkUGUuHsNHCQBDyZH7l53M.jpg</thumb>\n')
    # nfo_content_tvshow.append('\t<thumb spoof="" cache="" aspect="set.landscape" preview="">https://image.tmdb.org/t/p/original/mkusMBRJyXJCcJ5RKlrKK2SC0Qv.jpg</thumb>\n')
    # nfo_content_tvshow.append('\t<thumb spoof="" cache="" aspect="set.fanart" preview="">https://image.tmdb.org/t/p/original/3Odw3MJymLLbFuOnmQjmvndKhOr.jpg</thumb>\n')

    # Abspieldaten
    # if full_result['playcount']:
    if "playcount" in full_result:
        nfo_content_tvshow.append(
            "\t<playcount>" + str(full_result["playcount"]) + "</playcount>\n"
        )
    # if full_result['lastplayed']:
    if "lastplayed" in full_result:
        nfo_content_tvshow.append(
            "\t<lastplayed>" + full_result["lastplayed"] + "</lastplayed>\n"
        )
    # Databse Kodi ID from Movie
    # if full_result['tvshowid']:
    if "tvshowid" in full_result:
        nfo_content_tvshow.append("\t<id>" + str(full_result["tvshowid"]) + "</id>\n")
    # Database IMDBNumber => Wrong, Scraper saves spdb in imdb
    # if full_result['imdbnumber']:
    if "imdbnumber" in full_result:
        nfo_content_tvshow.append("\t<imdb></imdb> <!-- https://www.imdb.com/ -->\n")
        nfo_content_tvshow.append(
            '\t<uniqueid default="false" type="imdb"></uniqueid> <!-- https://www.imdb.com/ -->\n'
        )
    else:
        nfo_content_tvshow.append(
            '\t<uniqueid default="false" type="imdb"></uniqueid> <!-- https://www.imdb.com/ -->\n'
        )
    # Database Number Sportsdb
    nfo_content_tvshow.append(
        '\t<uniqueid default="true" type="tsdb">'
        + spdb_vdb_id
        + "</uniqueid> <!-- https://www.thesportsdb.com/ --> \n"
    )
    nfo_content_tvshow.append(
        '\t<uniqueid default="false" type="thesportsdb">'
        + spdb_vdb_id
        + "</uniqueid> <!-- https://www.thesportsdb.com/ --> \n"
    )
    nfo_content_tvshow.append(
        "\t<tsdb>" + spdb_vdb_id + "</tsdb> <!-- https://www.thesportsdb.com/ --> \n"
    )
    # Databse ID's IMDB, TMDB, TVDB, ANIDB + WIKIDATA, FACEBOOK, INSTAGRAM & X
    nfo_content_tvshow.append(
        '\t<uniqueid default="false" type="tmdb"></uniqueid> <!-- https://www.themoviedb.com/ -->\n'
    )
    nfo_content_tvshow.append(
        '\t<uniqueid default="false" type="tvdb"></uniqueid> <!-- https://www.thetvdb.com/ -->\n'
    )
    nfo_content_tvshow.append(
        '\t<uniqueid default="false" type="anidb"></uniqueid> <!-- https://anidb.net/ -->\n'
    )
    nfo_content_tvshow.append(
        '\t<uniqueid default="false" type="tvrage"></uniqueid> <!-- https://www.tvrage.com/ -->\n'
    )
    nfo_content_tvshow.append(
        '\t<uniqueid default="false" type="tvmaze"></uniqueid> <!-- https://www.tvmaze.com/ -->\n'
    )
    nfo_content_tvshow.append(
        '\t<uniqueid default="false" type="zap2it"></uniqueid> <!-- https://tvschedule.zap2it.com/ -->\n'
    )
    nfo_content_tvshow.append(
        '\t<uniqueid default="false" type="wikidata"></uniqueid> <!-- https://www.wikidata.org/ -->\n'
    )
    nfo_content_tvshow.append(
        '\t<uniqueid default="false" type="facebook"></uniqueid> <!-- https://www.facebook.com/ -->\n'
    )
    nfo_content_tvshow.append(
        '\t<uniqueid default="false" type="instagram"></uniqueid> <!-- https://www.instagram.com/ -->\n'
    )
    nfo_content_tvshow.append(
        '\t<uniqueid default="false" type="x"></uniqueid> <!-- https://x.com/ -->\n'
    )
    # Episodeguide New
    nfo_content_tvshow.append(
        "\t" + full_result["episodeguide"].replace(" ", "") + "\n"
    )
    # Genres
    # if full_result['genre']:
    if "genre" in full_result:
        for x_genre in full_result["genre"]:
            nfo_content_tvshow.append("\t<genre>" + x_genre + "</genre>\n")
    # Premiered,Year
    # if full_result['premiered']:
    if "premiered" in full_result:
        nfo_content_tvshow.append(
            "\t<premiered>" + full_result["premiered"] + "</premiered>\n"
        )
    # if full_result['year']:
    if "year" in full_result:
        nfo_content_tvshow.append("\t<year>" + str(full_result["year"]) + "</year>\n")
    # Studio - <studio>studio name / resolution / video codec / audio format / number of channels / language / subtitle language1/ subtitle language2... </studio>
    if "studio" in full_result:
        for studios in full_result["studio"]:
            nfo_content_tvshow.append("\t<studio>" + studios + "</studio>\n")
    # Status, Code, Studio,Country, - unbenutzt
    nfo_content_tvshow.append("\t<status></status>\n")
    nfo_content_tvshow.append("\t<code></code>\n")
    nfo_content_tvshow.append("\t<country></country>\n")
    if "mpaa" in full_result:
        nfo_content_tvshow.append("\t<mpaa>" + full_result["mpaa"] + "</mpaa>\n")
    # Tags,, empty = ["['[]']"] (filled in wrong with scraper?)
    if "tag" in full_result:
        for tags in full_result["tag"]:
            nfo_content_tvshow.append("\t<tag>" + str(tags) + "</tag>\n")
    # Cast/Actors
    # if full_result['cast']:
    if "cast" in full_result:
        if verboselog_adv:
            logger.debug('NFO writing, full CAST: "{}"'.format(full_result["cast"]))
        for casts in full_result["cast"]:
            nfo_content_tvshow.append("\t<actor>\n")
# Hier eine Verbesserung: tsdbid = ID von Spieler bei TSDB
            # <tsdbid>
            nfo_content_tvshow.append(
                "\t\t<tsdbid></tsdbid> <!-- tsdbid = PlayerId from TSDB (in work) -->\n"
            )
# Hier eine Verbesserung: profile = Link zu Profil auf TSDB: https://www.thesportsdb.com/player/34172989-Antony
            # <profile>
            nfo_content_tvshow.append(
                "\t\t<profile></profile> <!-- profile = Link to TSDB player profile page (in work)  -->\n"
            )

            if casts["name"]:
                # if "name" in full_result:
                nfo_content_tvshow.append(
                    "\t\t<name>" + str(casts["name"]) + "</name>\n"
                )
            if casts["role"]:
                # if "role" in full_result:
                nfo_content_tvshow.append(
                    "\t\t<role>" + str(casts["role"]) + "</role>\n"
                )
            if casts["order"]:
                # if "order" in full_result:
                nfo_content_tvshow.append(
                    "\t\t<order>" + str(casts["order"]) + "</order>\n"
                )
            try:
                if casts["thumbnail"]:
                    # nfo_cast_thumb = urllib.parse.unquote(casts['thumbnail'])
                    # nfo_content_tvshow.append('\t\t<thumb>' + str(casts['thumbnail']) + '</thumb>\n')
                    nfo_tmp_actor_thumb = urllib.parse.unquote(
                        casts["thumbnail"]
                    ).replace("image://", "")
                    nfo_tmp_actor_thumb = nfo_tmp_actor_thumb.replace(".png/", ".png")
                    nfo_content_tvshow.append(
                        "\t\t<thumb>"
                        + nfo_tmp_actor_thumb.replace("///", "")
                        + "</thumb>\n"
                    )
            except:
                if verboselog_adv:
                    logger.debug(
                        "Create NFO - Cast - Thumbnail => except, no thumbnail!"
                    )
                nfo_content_tvshow.append("\t</actor>\n")
                continue
            nfo_content_tvshow.append("\t</actor>\n")
    # Extra01 - TVShow Pfad
    # if full_result['file']:
    if "file" in full_result:
        nfo_content_tvshow.append(
            "\t<tvshowpath>" + full_result["file"] + "</tvshowpath>\n"
        )
    # Extra02 - Scraper Helper
    nfo_content_tvshow.append(
        "\t<tvshowsource>https://www.thesportsdb.com/league/"
        + spdb_vdb_id
        + "</tvshowsource>\n"
    )
    # Ende TVSHOW
    nfo_content_tvshow.append("</tvshow>\n")
    return nfo_content_tvshow
