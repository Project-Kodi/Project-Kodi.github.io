# -*- coding: UTF-8 -*-
#
# Copyright (C) 2024, Project Kodi
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# Code attribution:
# core based on metadata.tvshows.thesportsdb.python by pkscout
# and metadata.tvmaze scrapper by Roman Miroshnychenko aka Roman V.M.
# and the metadata.tvshows.themoviedb.org.python scraper by Team Kodi
# all created by improvements to metadata.thesportsdb.com 2015 from Project Kodi (peter0123)
#
# Addon: The Sports Database Python - metadata.thesportsdb.python
# See https://github.com/Project-Kodi/Project-Kodi.github.io/
# pylint: disable=missing-docstring


"""Functions to interact with various web site APIs"""

from __future__ import absolute_import, unicode_literals

import json
import time
from urllib.request import Request, urlopen
from urllib.error import URLError
from urllib.parse import urlencode
from pprint import pformat
from .utils import logger
from . import settings

try:
    from typing import (
        Text,
        Optional,
        Union,
        List,
        Dict,
        Any,
    )  # pylint: disable=unused-import

    InfoType = Dict[Text, Any]  # pylint: disable=invalid-name
except ImportError:
    pass

HEADERS = {}


def set_headers(headers):
    # type: (Dict) -> None
    HEADERS.update(headers)


def load_info(url, params=None, default=None, resp_type="json", verboselog=False):
    # type: (Text, Dict, Text, Text, bool) -> Optional[Text]

    # Brake for API, get to often API Blocks, Scraper handle the error wrong.
    sleephelper = settings.SLEEPHELPER
    logger.debug('Sleep Start:  "{}"'.format(sleephelper))
    time.sleep(sleephelper)

    # Api Version -> Settings
    api_version = settings.APIVERSION
    logger.debug('API Version:  "{}"'.format(api_version))
    """
    Load info from external api

    :param url: API endpoint URL
    :param params: URL query params
    :default: object to return if there is an error
    :resp_type: what to return to the calling function
    :return: API response or default on error
    """

    # API HELPER - > MIGRATION
    print('api_utily.py => Running with URL: "{}"'.format(url))
    print('api_utily.py => Running with PARAMS: "{}"'.format(params))

    # API V1:
    if api_version == "1":
        logger.debug("api_utily.py => V1 API Settings load")
        if params:
            url = url + "?" + urlencode(params)
        logger.debug('Calling URL "{}"'.format(url))

    # API V2:
    elif api_version == "2":
        logger.debug("api_utily.py => V2 API Settings load")
        if params:

            if "lookup/league/" in url:
                logger.debug('api_utily.py URL => lookup/league/ "{}"'.format(url))
                x = params["id"]
                logger.debug('api_utily.py => lookup/league/ ID:  "{}"'.format(x))
                url = url + x
            elif "lookup/event/" in url:
                logger.debug('api_utily.py URL => lookup/event/ "{}"'.format(url))
                x = params["id"]
                logger.debug('api_utily.py => lookup/event/ ID:  "{}"'.format(x))
                url = url + x
            elif "list/players/" in url:
                logger.debug('api_utily.py URL => list/players/ "{}"'.format(url))
                y = params["t"]
                logger.debug('api_utily.py => list/players/ T:  "{}"'.format(y))
                url = url + y
            elif "all/leagues" in url:
                logger.debug('api_utily.py URL => all/leagues "{}"'.format(url))
                url = url
            elif "list/seasons/" in url:
                logger.debug('api_utily.py URL => list/seasons/ "{}"'.format(url))
                x = params["id"]
                logger.debug('api_utily.py => list/seasons/ ID:  "{}"'.format(x))
                url = url + x
            elif "filter/events/" in url:
                logger.debug('api_utily.py URL => filter/events/ "{}"'.format(url))
                x = params["id"]
                w = params["s"]
                logger.debug('api_utily.py => filter/events/ ID:  "{}"'.format(x))
                logger.debug('api_utily.py => filter/events/ S:  "{}"'.format(w))
                url = url + x + "/" + w
            elif "list/teams/" in url:
                logger.debug('api_utily.py URL => list/teams/"{}"'.format(url))
                z = params["l"]
                logger.debug('api_utily.py => list/teams/ L:  "{}"'.format(z))
                url = url + z

        logger.debug('api_utily.py => Calling URL => "{}"'.format(url))
    req = Request(url, headers=HEADERS)
    try:
        response = urlopen(req)
    except URLError as e:
        if hasattr(e, "reason"):
            logger.debug("failed to reach the remote site\nReason: {}".format(e.reason))
        elif hasattr(e, "code"):
            logger.debug(
                "remote site unable to fulfill the request\nError code: {}".format(
                    e.code
                )
            )
        response = None
    if response is None:
        resp = default
    elif resp_type.lower() == "json":
        try:
            resp = json.loads(response.read().decode("utf-8"))
        except json.decoder.JSONDecodeError:
            logger.debug("remote site sent back bad JSON")
            resp = default
    else:
        resp = response.read().decode("utf-8")
    if verboselog:
        logger.debug("the api response:\n{}".format(pformat(resp)))
    return resp
