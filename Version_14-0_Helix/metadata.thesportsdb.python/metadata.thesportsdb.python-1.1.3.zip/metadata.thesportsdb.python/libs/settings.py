# -*- coding: UTF-8 -*-
#
# Copyright (C) 2024, Project Kodi
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# Code attribution:
# core based on metadata.tvshows.thesportsdb.python by pkscout
# and metadata.tvmaze scrapper by Roman Miroshnychenko aka Roman V.M.
# and the metadata.tvshows.themoviedb.org.python scraper by Team Kodi
# all created by improvements to metadata.thesportsdb.com 2015 from Project Kodi (peter0123)
#
# Addon: The Sports Database Python - metadata.thesportsdb.python
# See https://github.com/Project-Kodi/Project-Kodi.github.io/
# pylint: disable=missing-docstring


import json
import sys
import urllib.parse
from xbmcaddon import Addon

ADDON = Addon()

try:
    source_params = dict(urllib.parse.parse_qsl(sys.argv[2]))
except IndexError:
    source_params = {}
source_settings = json.loads(source_params.get("pathSettings", "{}"))

LANGUAGE = source_settings.get("language", ADDON.getSettingString("language")).upper()
ENABTRAILER = source_settings.get("enab_trailer", ADDON.getSettingBool("enab_trailer"))
# ENABTRAILER = False
PLAYERSOPT = source_settings.get(
    "players_opt", ADDON.getSettingString("players_opt")
).lower()
VERBOSELOG = source_settings.get("verboselog", ADDON.getSettingBool("verboselog"))
SLEEPHELPER = source_settings.get(
    "sleep_helper", ADDON.getSettingNumber("sleep_helper")
)
APIVERSION = source_settings.get("api_version", ADDON.getSettingString("api_version"))
IGNORELOCALNFO = source_settings.get(
    "ignore_local_nfo", ADDON.getSettingBool("ignore_local_nfo")
)
CHANGEEPTITLE = source_settings.get(
    "change_ep_title", ADDON.getSettingBool("change_ep_title")
)
CHANGEEPTITLEEXCL = source_settings.get(
    "change_ep_title_excl", ADDON.getSettingString("change_ep_title_excl")
).lower()
VERBOSELOGADV = source_settings.get(
    "verboselog_adv", ADDON.getSettingBool("verboselog_adv")
)
WRITENFO = source_settings.get("write_nfo", ADDON.getSettingBool("write_nfo"))
OVERWRITENFO = source_settings.get(
    "overwrite_nfo", ADDON.getSettingBool("overwrite_nfo")
)
WRITENFODEFAULT = source_settings.get(
    "write_nfo_default", ADDON.getSettingBool("write_nfo_default")
)
WRITENFOWNTVSHOWPATH = source_settings.get(
    "write_nfo_own_tvshow_path", ADDON.getSettingString("write_nfo_own_tvshow_path")
)
WRITENFOWNSEASONPATH = source_settings.get(
    "write_nfo_own_season_path", ADDON.getSettingString("write_nfo_own_season_path")
)
WRITENFOWNEPISODEPATH = source_settings.get(
    "write_nfo_own_episode_path", ADDON.getSettingString("write_nfo_own_episode_path")
)
WRITENFOTVSHOWFILENAME = source_settings.get(
    "write_nfo_tvshow_filename", ADDON.getSettingString("write_nfo_tvshow_filename")
)
WRITENFOSEASONFILENAME = source_settings.get(
    "write_nfo_season_filename", ADDON.getSettingString("write_nfo_season_filename")
)
WRITENFOEPISODEFILENAME = source_settings.get(
    "write_nfo_episode_filename", ADDON.getSettingString("write_nfo_episode_filename")
)
ENABSEASONPOSTEROVERW = source_settings.get(
    "enab_season_poster_overw", ADDON.getSettingBool("enab_season_poster_overw")
)
CHANGEAPIKEY = source_settings.get(
    "change_api_key", ADDON.getSettingString("change_api_key")
)
ENABCHARACTERART = source_settings.get(
    "enab_character_art", ADDON.getSettingBool("enab_character_art")
)
ENABCHARACTERARTVERSION = source_settings.get(
    "enab_character_art_version", ADDON.getSettingInt("enab_character_art_version")
)
ENABCHARACTERARTDL = source_settings.get(
    "enab_character_art_dl", ADDON.getSettingBool("enab_character_art_dl")
)
CHARACTERARTSWITCHNAME = source_settings.get(
    "character_art_switch_name", ADDON.getSettingString("character_art_switch_name")
)
WRITECHRACTERARTPATH = source_settings.get(
    "write_character_art_path", ADDON.getSettingBool("write_character_art_path")
)
WRITECHRACTERARTOWNPATH = source_settings.get(
    "write_character_art_own_path", ADDON.getSettingString("write_character_art_own_path")
)
WRITEPOSTER = source_settings.get(
    "write_poster", ADDON.getSettingBool("write_poster")
)
WRITEPOSTERFILENAME = source_settings.get(
    "write_poster_filename", ADDON.getSettingString("write_poster_filename")
)
WRITEFANART = source_settings.get(
    "write_fanart", ADDON.getSettingBool("write_fanart")
)
WRITEFANARTFILENAME = source_settings.get(
    "write_fanart_filename", ADDON.getSettingString("write_fanart_filename")
)
WRITEBANNER = source_settings.get(
    "write_banner", ADDON.getSettingBool("write_banner")
)
WRITEBANNERFILENAME = source_settings.get(
    "write_banner_filename", ADDON.getSettingString("write_banner_filename")
)
WRITECLEARLOGO = source_settings.get(
    "write_clearlogo", ADDON.getSettingBool("write_clearlogo")
)
WRITECLEARLOGOFILENAME = source_settings.get(
    "write_clearlogo_filename", ADDON.getSettingString("write_clearlogo_filename")
)
