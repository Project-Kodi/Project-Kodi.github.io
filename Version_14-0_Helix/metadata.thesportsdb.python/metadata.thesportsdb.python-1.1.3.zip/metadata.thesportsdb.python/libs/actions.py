# -*- coding: UTF-8 -*-
#
# Copyright (C) 2024, Project Kodi
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# Code attribution:
# core based on metadata.tvshows.thesportsdb.python by pkscout
# and metadata.tvmaze scrapper by Roman Miroshnychenko aka Roman V.M.
# and the metadata.tvshows.themoviedb.org.python scraper by Team Kodi
# all created by improvements to metadata.thesportsdb.com 2015 from Project Kodi (peter0123)
#
# Addon: The Sports Database Python - metadata.thesportsdb.python
# See https://github.com/Project-Kodi/Project-Kodi.github.io/
# pylint: disable=missing-docstring


"""Plugin route actions"""

from __future__ import absolute_import, unicode_literals

import sys
import json
import urllib.parse
import re
import xbmcgui
import xbmcplugin
from . import tsdb, data_utils, cache, settings, utils
from .utils import logger
import xml.etree.ElementTree as ET

try:
    from typing import (
        Optional,
        Text,
        Union,
        ByteString,
    )  # pylint: disable=unused-import
except ImportError:
    pass

HANDLE = int(sys.argv[1])  # type: int

# Addon Settings - API Version/Ignore local NFO/Verbose logging extreme
api_version = settings.APIVERSION
ignore_local_nfo = settings.IGNORELOCALNFO
verboselog_adv = settings.VERBOSELOGADV
write_nfo = settings.WRITENFO
enab_season_poster_overw = settings.ENABSEASONPOSTEROVERW
enab_character_art = settings.ENABCHARACTERART
enab_character_art_version = settings.ENABCHARACTERARTVERSION
enab_character_art_dl = settings.ENABCHARACTERARTDL
write_poster = settings.WRITEPOSTER
write_poster_filename = settings.WRITEPOSTERFILENAME
write_fanart = settings.WRITEFANART
write_fanart_filename = settings.WRITEFANARTFILENAME
write_banner = settings.WRITEBANNER
write_banner_filename = settings.WRITEBANNERFILENAME
write_clearlogo = settings.WRITECLEARLOGO
write_clearlogo_filename = settings.WRITECLEARLOGOFILENAME


def find_show(title):
    # type: (Union[Text, bytes]) -> None
    """Find a show by title"""
    if not isinstance(title, str):
        title = title.decode("utf-8")
    logger.debug("Searching for sports event {}".format(title))
    search_results = tsdb.search_show(title, api_version)
    for search_result in search_results:
        show_name = search_result.get("strLeague")
        list_item = xbmcgui.ListItem(show_name, offscreen=True)
        list_item = data_utils.add_main_show_info(
            list_item, search_result, full_info=False
        )
        # Below "url" is some unique ID string (may be an actual URL to a show page)
        # that is used to get information about a specific league.
        xbmcplugin.addDirectoryItem(
            HANDLE,
            url=str(search_result["idLeague"]),
            listitem=list_item,
            isFolder=True,
        )


def get_show_id_from_nfo(nfo):
    # type: (Text) -> None
    """
    Get show ID by NFO file contents

    This function is called first instead of find_show
    if a NFO file is found in a TV show folder.

    :param nfo: the contents of a NFO file
    """
    if isinstance(nfo, bytes):
        nfo = nfo.decode("utf-8", "replace")
    parse_result = data_utils.parse_nfo_url(nfo)
    if verboselog_adv:
        logger.debug('NFO URL/Content parse_result: "{}"'.format(parse_result))
    if parse_result:
        # IMDB ANIDB TVDB TMDB TSDB  talk with zag 21.06.2024
        #       if parse_result.provider == "thesportsdb":

        logger.debug('NFO URL parse_result provider: "{}"'.format(parse_result.provider))

        if parse_result.provider == "tsdb":
            show_info = tsdb.load_show_info(parse_result.show_id, api_version)
        else:
            show_info = None
        if show_info is not None:
            list_item = xbmcgui.ListItem(show_info["strLeague"], offscreen=True)
            # "url" is some string that unique identifies a league.
            # It may be an actual URL of a TV show page.
            xbmcplugin.addDirectoryItem(
                HANDLE,
                url=str(show_info["idLeague"]),
                listitem=list_item,
                isFolder=True,
            )


def get_details(show_id):
    # type: (Text) -> None
    """Get details about a specific league"""
    logger.debug("Getting details for league id {}".format(show_id))
    show_info = tsdb.load_show_info(show_id, api_version)
    if show_info is not None:
        list_item = xbmcgui.ListItem(show_info["strLeague"], offscreen=True)
        list_item = data_utils.add_main_show_info(list_item, show_info, full_info=True)
        xbmcplugin.setResolvedUrl(HANDLE, True, list_item)
    else:
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem(offscreen=True))


def get_episode_list(show_ids):
    # type: (Text) -> None
    """Get games in a league"""
    # Kodi has a bug: when a show directory contains an XML NFO file with
    # episodeguide URL, that URL is always passed here regardless of
    # the actual parsing result in get_show_from_nfo()
    # so much of this weird logic is to deal with that
    try:
        all_ids = json.loads(show_ids)
        # IMDB ANIDB TVDB TMDB TSDB  talk with zag 21.06.2024
        #       show_id = all_ids.get("thesportsdb")
        show_id = all_ids.get("tsdb")
    except (ValueError, AttributeError):
        show_id = str(show_ids)
        if show_id.isdigit():
            logger.error(
                "using deprecated episodeguide format, this league should be refreshed or rescraped"
            )
    if not show_id:
        raise RuntimeError(
            "No The SportsDB league id found in episode guide, this league should be refreshed or rescraped"
        )
    elif not show_id.isdigit():
        parsed = False
        parse_result = data_utils.parse_nfo_url(show_id)
        if parse_result:
            # IMDB ANIDB TVDB TMDB TSDB  talk with zag 21.06.2024
            #           if parse_result.provider == "thesportsdb":
            if parse_result.provider == "tsdb":
                show_info = tsdb.load_show_info(parse_result.show_id, api_version)
                parsed = True
        if not parsed:
            raise RuntimeError(
                "No SportsDB league id found in episode guide, this league should be refreshed or rescraped"
            )
    logger.debug("Getting event list for sports show id {}".format(show_id))
    show_info = tsdb.load_show_info(show_id, api_version)
    if show_info is not None:


        #First Part New - Start 
        #If Addon Setting enab_character_art are True
        if enab_character_art_dl:
            character_arts = []
            character_art_url = ''
            character_art_url_typ = ''
            character_art_key = 0
            info_strLeague = show_info.get("strLeague", "")
            info_idLeague = show_info.get("idLeague", "")

        teams = show_info.get("teams")
        if not teams:
            teams = tsdb.load_team_list(show_info.get("strLeague", ""), api_version)
        if teams:
            for team in teams:
                if verboselog_adv:
                    logger.debug("Call function: get_episode_list: Artwork %s [idTeam]" % team.get("idTeam", ""))  
                    logger.debug("Call function: get_episode_list:  Artwork %s [strTeam]" % team.get("strTeam", ""))   

                # Addon Setting - Artwork - Enable Character Art - Download Files
                if enab_character_art_dl:
                    if verboselog_adv:
                        logger.debug("Call function: set_show_cast enab_character_art: %s [Addon Setting - Artwork - Enable Character Art - Download Files]" % enab_character_art)
                    #Load Player List for x Team
                    players = tsdb.load_roster_info(team.get("idTeam", ""), team.get("strTeam", ""), api_version)
                    if verboselog_adv:
                        logger.debug("Call function: load_roster_info: %s [players]" % players)
                    #If Player exists, loop:
                    if not players:
                        continue
                    for player in players:
                        if verboselog_adv:
                            logger.debug("Call function: load_roster_info strRender: %s [strRender]" % player.get("strRender", ""))            
                            logger.debug("Call function: load_roster_info strCutout: %s [strCutout]" % player.get("strCutout", ""))
                            #Select the correct Version of Art
                            logger.debug("enab_character_art_version: %s | [if strRender or strCutout, incl. fallback]" % enab_character_art_version)
                        #if here - strRender
                        if player.get("strRender", ""):
                            character_art_url = player.get("strRender", "")
                            character_art_url_typ = 'strRender'
                            if verboselog_adv:
                                logger.debug("OK - chooise strRender ADD : %s | [character_art_url]" % character_art_url)
                            character_art_key = character_art_key + 1
                            character_arts.append({"character_art_key": character_art_key, "character_art_preferred": enab_character_art_version, "character_art_url": character_art_url, "character_art_url_typ": character_art_url_typ})
                        #if here - strCutout
                        if player.get("strCutout", ""):
                            character_art_url = player.get("strCutout", "")
                            character_art_url_typ = 'strCutout'
                            if verboselog_adv:
                                logger.debug("OK - chooise  strCutout ADD: %s | [character_art_url]" % character_art_url)
                            character_art_key = character_art_key + 1
                            character_arts.append({"character_art_key": character_art_key, "character_art_preferred": enab_character_art_version, "character_art_url": character_art_url, "character_art_url_typ": character_art_url_typ})
                    #At the end of Player Loop in Teams (Call each Team)
                    if verboselog_adv:
                        logger.debug("Loop End, character_arts List: %s" % character_arts)

                    #Sace Charakter Art on filesystem  
                    data_utils.save_character_art(character_arts, info_strLeague, info_idLeague)
            if verboselog_adv:
                logger.debug("End of creating List and save characterart -  [Addon Setting - Artwork - Enable Character Art  - Download Files]")

        #First Part New - End 

        #Download Jobs for: poster,fanart,banner & clearlogo
        #DL Poster True
        if write_poster:
            write_artwork_grp01 = 'poster'
            logger.debug("Calling write_poster")
            data_utils.save_tvshow_art(show_info, write_artwork_grp01, write_poster_filename, show_info.get("strLeague", ""), info_idLeague)
        #DL Fanart True
        if write_fanart:
            write_artwork_grp01 = 'fanart'           
            logger.debug("Calling write_fanart")
            data_utils.save_tvshow_art(show_info, write_artwork_grp01, write_fanart_filename, show_info.get("strLeague", ""), info_idLeague)
        #DL Banner True
        if write_banner:
            write_artwork_grp01 = 'banner'
            logger.debug("Calling write_banner")
            data_utils.save_tvshow_art(show_info, write_artwork_grp01, write_banner_filename, show_info.get("strLeague", ""), info_idLeague)
        #DL Clearlogo True
        if write_clearlogo:
            write_artwork_grp01 = 'clearlogo'
            logger.debug("Calling write_clearlogo")
            data_utils.save_tvshow_art(show_info, write_artwork_grp01, write_clearlogo_filename, show_info.get("strLeague", ""), info_idLeague)

        # Später hier die Season Poster hinzufügen

        #Run NFO - TVShows (strLeague/) Addon Settings
        if write_nfo:
            utils.nfo_correct_tvshow(show_info.get("strLeague", ""), show_id)

        idLeague = show_info.get("idLeague", 0)
        seasons = show_info.get("seasons")
        if verboselog_adv:
            logger.debug("Show Info idLeague: {}".format(idLeague))
            logger.debug("Show Info seasons: {}".format(seasons))
        if not seasons:
            seasons = show_info["seasons"] = data_utils._add_season_info(
                show_info, None
            )
        event_list = []
        for season in seasons:
            if verboselog_adv:
                logger.debug("Show Info season: {}".format(season))
            events = tsdb.load_season_episodes(
                idLeague, season.get("season_name", ""), api_version
            )
            if verboselog_adv:
                logger.debug("Show Info events: {}".format(events))
            if events:
                ep_num = 1
                for event in events:
                    event["strEpisode"] = str(ep_num)
                    event["strLeague"] = show_info.get("strLeague", "")
                    event_list.append(event)
                    encoded_ids = urllib.parse.urlencode(
                        {"show_id": idLeague, "episode_id": event.get("idEvent", 0)}
                    )
                    if verboselog_adv:
                        logger.debug(
                            "function get_episode_list =>  strEpisode: {}".format(
                                str(ep_num)
                            )
                        )
                    if verboselog_adv:
                        logger.debug(
                            "function get_episode_list =>  strLeague: {}".format(
                                show_info.get("strLeague", "")
                            )
                        )
                    if verboselog_adv:
                        logger.debug(
                            "function get_episode_list =>  show_id: {}".format(idLeague)
                        )
                    if verboselog_adv:
                        logger.debug(
                            "function get_episode_list =>  episode_id: {}".format(
                                event.get("idEvent", 0)
                            )
                        )
                    list_item = xbmcgui.ListItem(
                        event.get("strEvent", ""), offscreen=True
                    )
                    list_item = data_utils.add_episode_info(
                        list_item, event, full_info=False
                    )
                    # Below "url" is some unique ID string (may be an actual URL to an episode page)
                    # that allows to retrieve information about a specific episode.
                    url = urllib.parse.quote(encoded_ids)
                    if verboselog_adv:
                        logger.debug(
                            "Below 'url' is some unique ID string: {}".format(url)
                        )
                    xbmcplugin.addDirectoryItem(
                        HANDLE, url=url, listitem=list_item, isFolder=True
                    )
                    ep_num = ep_num + 1
        show_info["event_list"] = event_list
        cache.cache_show_info(show_info)


def get_episode_details(encoded_ids):  # pylint: disable=missing-docstring
    # type: (Text) -> None
    """Get details about a specific game"""
    encoded_ids = urllib.parse.unquote(encoded_ids)
    decoded_ids = dict(urllib.parse.parse_qsl(encoded_ids))
    logger.debug("Getting event details for {}".format(decoded_ids))

    episode_info = tsdb.load_episode_info(
        decoded_ids["show_id"], decoded_ids["episode_id"], api_version
    )
    if verboselog_adv:
        logger.debug("Episode episode_info: {}".format(episode_info))
    if episode_info:
        list_item = xbmcgui.ListItem(episode_info.get("strEvent", ""), offscreen=True)
        list_item = data_utils.add_episode_info(list_item, episode_info, full_info=True)
        xbmcplugin.setResolvedUrl(HANDLE, True, list_item)
    else:
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem(offscreen=True))


def get_artwork(show_id):
    # type: (Text) -> None
    """
    Get available artwork for a show

    :param show_id: default unique ID set by setUniqueIDs() method
    """
    if not show_id:
        return
    logger.debug("Getting artwork for show ID {}".format(show_id))
    show_info = tsdb.load_show_info(show_id, api_version)
    if show_info is not None:
        list_item = xbmcgui.ListItem(show_info.get("strLeague", ""), offscreen=True)
        list_item = data_utils.set_show_artwork(show_info, list_item)
        xbmcplugin.setResolvedUrl(HANDLE, True, list_item)
    else:
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem(offscreen=True))


def router(paramstring):
    # type: (Text) -> None
    """
    Route addon calls

    :param paramstring: url-encoded query string
    :raises RuntimeError: on unknown call action
    """
    params = dict(urllib.parse.parse_qsl(paramstring))
    logger.debug("Called addon with params: {}".format(sys.argv))
    if params["action"] == "find":
        logger.debug("performing find action")
        find_show(params["title"])
    elif params["action"].lower() == "nfourl":
        logger.debug("performing nfourl action")
        #Overruel Kodi, ignore local founded NFO File
        if ignore_local_nfo:
            logger.debug("Do not use local NFO File (Addon Settings): %s " % params["nfo"])
            nfo_search_string = str((params["nfo"]))
            #1 Attempt: Need to extract League Name or tsdb, episodeguide
### == >    #Hier eine Verbesserung, Tag vorhanden und nicht leer!
            if "<title>" in nfo_search_string:
                nfo_search_title = ''.join(nfo_search_string.split("<title>")[1].split("</title>")[0])
                logger.debug("nfo_search_title: %s " % nfo_search_title)
                if nfo_search_title:
                    logger.debug("nfo_search_title: OK")
                    find_show(nfo_search_title)
            elif "<showtitle>" in nfo_search_string:
                nfo_search_showtitle = ''.join(nfo_search_string.split("<showtitle>")[1].split("</showtitle>")[0])
                logger.debug("nfo_search_showtitle: %s " % nfo_search_showtitle)
                if nfo_search_showtitle:
                    logger.debug("nfo_search_showtitle: OK")
                    find_show(nfo_search_showtitle)
            elif "<originaltitle>" in nfo_search_string:
                nfo_search_originaltitle = ''.join(nfo_search_string.split("<originaltitle>")[1].split("</originaltitle>")[0])
                logger.debug("nfo_search_originaltitle: %s " % nfo_search_originaltitle)
                if nfo_search_originaltitle:
                    logger.debug("nfo_search_originaltitle: OK")
                    find_show(nfo_search_originaltitle)
            elif "<strLeague>" in nfo_search_string:
                nfo_search_strLeague = ''.join(nfo_search_string.split("<strLeague>")[1].split("</strLeague>")[0])
                logger.debug("nfo_search_strLeague: %s " % nfo_search_strLeague)
                if nfo_search_strLeague:
                    logger.debug("nfo_search_strLeague: OK")
                    find_show(nfo_search_strLeague)                   
            elif "<tsdb>" in nfo_search_string:
                nfo_search_tsdb = ''.join(nfo_search_string.split("<tsdb>")[1].split("</tsdb>")[0])
                logger.debug("nfo_search_tsdb: %s " % nfo_search_tsdb)
                if nfo_search_tsdb:
                    logger.debug("nfo_search_tsdb: OK")
                    show_info = tsdb.load_show_info(nfo_search_tsdb, api_version)
                    logger.debug("RESULT show_info: %s " % show_info)
                    nfo_search_strLeague = show_info['strLeague']
                    logger.debug("RESULT nfo_search_strLeague: %s " % nfo_search_strLeague)
                    find_show(nfo_search_strLeague)
            elif "<thesportsdb>" in nfo_search_string:
                nfo_search_thesportsdb = ''.join(nfo_search_string.split("<thesportsdb>")[1].split("</thesportsdb>")[0])
                logger.debug("nfo_search_tsdb: %s " % nfo_search_thesportsdb)
                if nfo_search_thesportsdb:
                    logger.debug("nfo_search_thesportsdb: OK")
                    show_info = tsdb.load_show_info(nfo_search_thesportsdb, api_version)
                    logger.debug("RESULT show_info: %s " % show_info)
                    nfo_search_strLeague = show_info['strLeague']
                    logger.debug("RESULT nfo_search_strLeague: %s " % nfo_search_strLeague)
                    find_show(nfo_search_strLeague)                    
            elif "<episodeguide>" in nfo_search_string:
                nfo_search_episodeguide = ''.join(nfo_search_string.split("<episodeguide>")[1].split("</episodeguide>")[0])
                logger.debug("nfo_search_episodeguide: %s " % nfo_search_episodeguide)
                nfo_search_episodeguide_j = json.loads(nfo_search_episodeguide)
                nfo_search_episodeguide = nfo_search_episodeguide_j["tsdb"]
                if nfo_search_episodeguide:
                    logger.debug("nfo_search_episodeguide: %s " % nfo_search_episodeguide)       
                    show_info = tsdb.load_show_info(nfo_search_episodeguide, api_version)
                    logger.debug("RESULT show_info: %s " % show_info)
                    nfo_search_strLeague = show_info['strLeague']
                    logger.debug("RESULT nfo_search_strLeague: %s " % nfo_search_strLeague)
                    find_show(nfo_search_strLeague)
            elif "<tvshowsource>" in nfo_search_string:
                nfo_search_tvshowsource = ''.join(nfo_search_string.split("<tvshowsource>")[1].split("</tvshowsource>")[0])
                logger.debug("nfo_search_tvshowsource: %s " % nfo_search_tvshowsource)
                if nfo_search_tvshowsource:
                    logger.debug("nfo_search_tvshowsource: OK")
                    # Regular expressions for various parsing
                    regex_search_league_id= [r"(thesportsdb)\.com/league/(\d+)"]
                    for regexp in regex_search_league_id:
                        logger.debug("Rexexp: show_id_match: %s " % regexp)
                        show_id_match = re.search(regexp, nfo_search_tvshowsource, re.I)
                        if show_id_match:
                            show_id = show_id_match.group(2)
                            logger.debug("show_id: %s " % show_id)
                            show_info = tsdb.load_show_info(show_id, api_version)
                            logger.debug("RESULT show_info: %s " % show_info)
                            nfo_search_strLeague = show_info['strLeague']
                            logger.debug("RESULT nfo_search_strLeague: %s " % nfo_search_strLeague)
                            find_show(nfo_search_strLeague)
            else:
                #Normalen Weg weitergehen, läuft ohne gescrpate Daten weiter.
                logger.debug("No Change, <title>, <showtitle>, <originaltitle>, <strLeague>, <tsdb>, <episodeguide> and <tvshowsource> are empty or not exists ")     
                get_show_id_from_nfo(params["nfo"])
        #Normal Wy if not overrule
        else:
            logger.debug("Use local NFO File (Addon Settings): %s " % params["nfo"])
            get_show_id_from_nfo(params["nfo"])
    elif params["action"] == "getdetails":
        logger.debug("performing getdetails action")
        get_details(params["url"])
    elif params["action"] == "getepisodelist":
        logger.debug("performing getepisodelist action")
        get_episode_list(params["url"])
        #Run NFO - TVShows
    elif params["action"] == "getepisodedetails":
        logger.debug("performing getepisodedetails action")

        get_episode_details(params["url"])
    elif params["action"] == "getartwork":
        logger.debug("performing getartwork action")
        get_artwork(params.get("id"))
    else:
        raise RuntimeError("Invalid addon call: {}".format(sys.argv))
    xbmcplugin.endOfDirectory(HANDLE)
