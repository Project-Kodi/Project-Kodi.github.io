# -*- coding: UTF-8 -*-
#
# Copyright (C) 2024, Project Kodi => Peter Streimelweger
#
# Addon: The Sports Database Python - metadata.thesportsdb.python
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# Code attribution:
# core based on metadata.tvshows.thesportsdb.python by pkscout
# and metadata.tvmaze scrapper by Roman Miroshnychenko aka Roman V.M.
# and the metadata.tvshows.themoviedb.org.python scraper by Team Kodi
# all created by improvements to metadata.thesportsdb.com 2015 from Project Kodi (peter0123)
# The owner "ZAG" of TheSportsdb.com!! He supported all of the people mentioned!
# Big praise, it's been 10 years, we'll soon have sports series integrated into Kodi!
#
# Kodi Forum: https://forum.kodi.tv/showthread.php?tid=256198
# Support - Join us at Discord: TheDataDB => https://discord.com/channels/481047912286257152/481047912286257155
# Source and Information, see  https://project-kodi.github.io/ or https://github.com/Project-Kodi/Project-Kodi.github.io/
# Emergency contact to continue the scraper: kodi-support@streimelweger.eu
#
# Open
#
# => https://kodi.wiki/view/Add-on:Embuary_Info / Wenn man mehr informationen über zb. Premier League anfordert, danach ein Team wählt und informationen holt, geht das Plugin nur zur MOVIE DB!
# diverse Vorbereitungen für Player / Team Details: Team Details: https://www.thesportsdb.com/api/v2/json/3/lookup/team/133675 =>  TEAM_DETAIL_URL
# Title "label" not title
# BEI NFO, die Sprach Einstellung beachten, aktuell nur EN?
# Cast Import von TSDB zu KODI, immer nur ein Actor/Cast??? NFO Verarbeitung passt, dort nur 1 Ergebnis da nur 1x in kodi?
# filter smb/nfs passwords from logging
# ##Expand extra Fanart  => data_utily.py sowie season
# addAvailableArtwork(   , at the end data_utilis.py
# print("All attributes and methods:", OBJECT.__dir__())
# pylint: disable=missing-docstring


"""Functions to interact with TSDb API"""

from __future__ import absolute_import, unicode_literals

import unicodedata
from math import floor
from pprint import pformat
from . import cache, api_utils, settings
from .utils import logger

try:
    from typing import (
        Text,
        Optional,
        Union,
        List,
        Dict,
        Any,
    )  # pylint: disable=unused-import

    InfoType = Dict[Text, Any]  # pylint: disable=invalid-name
except ImportError:
    pass

# Addon Settings - API Version/Verbose logging extreme
api_version = settings.APIVERSION
verboselog_adv = settings.VERBOSELOGADV
change_api_key = settings.CHANGEAPIKEY
# Check Settings - API Version:
logger.debug("API CALLS {}".format(settings.APIVERSION))


# Free Test API Key Url - Fallback (Integration...)
base_url_free_api = "https://www.thesportsdb.com/api/v2/json/3/{}"

# API Key Change - Addon Settings
if change_api_key == "Only if available" or change_api_key == "":
    change_api_key = 9863529876235

############################################# OVERVIEW OF API V1/V2 - TSDB used in this scraper #############################################
# API V1                  | API V2               | - used from Scraper             | - Possible API V1
# all_leagues.php         | all/leagues/         | {}                              | all_leagues.php
# search_all_seasons.php  | list/seasons/        | {'id': '4372'}                  | search_all_seasons.php?id=4328
# eventsseason.php        | filter/events/       | {'id': '4328', 's': '1992-1993'}| eventsseason.php?id=4328&s=2014-2015
# search_all_teams.php    | list/teams/          | {'l': 'English Premier League'} | search_all_teams.php?l=English%20Premier%20League | search_all_teams.php?s=Soccer&c=Spain
# lookupleague.php        | lookup/league/       | {'id': '4328'}                  | lookupleague.php?id=4346
# lookupevent.php         | lookup/event/        | {'id': '448758'}                | lookupevent.php?id=441613
# searchplayers.php       | list/players/        | ?{'t': 'Brentford'}             | searchplayers.php?p=Danny_Welbeck | searchplayers.php?t={TeamName}&p={Playername}
# lookupteam.php          | lookup/team/         | {'id': '133675'}                | lookupteam.php?id=133675
# lookuplineup.php        | lookup/event_lineup  | {'id': '1818398'}               | lookuplineup.php?id=1818398
# eventresults.php        | lookup/event_results | {'id': '1662932'}               | eventresults.php?id=1662932
# lookupplayer.php        | lookup/player/       | {'id': '34145937'}              | lookupplayer.php?id=34145937
# - no API V1 Feature!    | list/seasonposters/  | {'id': '4372'}                  | - no API V1 Feature!


# API V1:
if api_version == "1":
    # API Key for Project-Kodi & Project-Plex
    base_url = "https://www.thesportsdb.com/api/v1/json/" + \
        str(change_api_key) + "/{}"
    SEARCH_URL = base_url.format("all_leagues.php")
    SHOW_URL = base_url.format("lookupleague.php")
    SEASON_URL = base_url.format("search_all_seasons.php")
    EVENTLIST_URL = base_url.format("eventsseason.php")
    EPISODE_URL = base_url.format("lookupevent.php")
    ROSTER_URL = base_url.format("searchplayers.php")
    TEAMLIST_URL = base_url.format("search_all_teams.php")
    TEAMLIST_URL2 = base_url.format("lookup_all_teams.php")
    TEAM_DETAIL_URL = base_url.format("lookupteam.php")
    EPISODE_LINEUP_URL = base_url.format("lookuplineup.php")
    EPISODE_RESULT_URL = base_url.format("eventresults.php")
    PLAYER_URL = base_url.format("lookupplayer.php")
    # SEASON_ARTWORK_URL = base_url.format("no php file")  # new in API V2 and only V2, switch in addon settings.
    HEADERS = (
        (
            "User-Agent",
            "Kodi sports events scraper by Project Kodi - metadata.thesportsdb.python; contact kodi-support@streimelweger.eu; API Version 1.0",
        ),
        ("Accept", "application/json"),
    )
    logger.debug("V1 API Settings load")

# API V2:
elif api_version == "2":
    # API Key for Project-Kodi & Project-Plex
    base_url = "https://www.thesportsdb.com/api/v2/json/" + \
        str(change_api_key) + "/{}"
    SEARCH_URL = base_url.format(
        "all/leagues"
    )  # all_leagues.php => https://www.thesportsdb.com/api/v2/json/3/all/leagues
    SHOW_URL = base_url.format(
        "lookup/league/"
    )  # lookupleague.php => https://www.thesportsdb.com/api/v2/json/3/lookup/league/4328
    SEASON_URL = base_url.format(
        "list/seasons/"
    )  # search_all_seasons.php => https://www.thesportsdb.com/api/v2/json/3/list/seasons/4328
    EVENTLIST_URL = base_url.format(
        "filter/events/"
    )  # eventsseason.php https://www.thesportsdb.com/api/v2/json/3/filter/events/4370/1850
    EPISODE_URL = base_url.format(
        "lookup/event/"
    )  # lookupevent.php => https://www.thesportsdb.com/api/v2/json/3/lookup/event/1448310
    ROSTER_URL = base_url.format(
        "list/players/"
    )  # searchplayers.php => https://www.thesportsdb.com/api/v2/json/3/list/players/133604
    TEAMLIST_URL = base_url.format(
        "list/teams/"
    )  # search_all_teams.php => https://www.thesportsdb.com/api/v2/json/3/list/teams/4328 /OR/ https://www.thesportsdb.com/api/v2/json/3/list/teams/Manchester_United
    # Extra url, for API1: TEAMLIST_URL2 (lookup_all_teams.php / list/teams/) use same as TEAMLIST_URL (search_all_teams.php) for API2, but for API1 we need to use 2 php files!
    TEAMLIST_URL2 = base_url.format(
        "list/teams/"
    )  # lookup_all_teams.php => https://www.thesportsdb.com/api/v2/json/3/list/teams/4328 /OR/ https://www.thesportsdb.com/api/v2/json/3/list/teams/Manchester_United
    TEAM_DETAIL_URL = base_url.format(
        "lookup/team/"
    )  # lookupteam.php => https://www.thesportsdb.com/api/v2/json/3/lookup/team/133675
    EPISODE_LINEUP_URL = base_url.format(
        "lookup/event_lineup/"
    )  # lookuplineup.php => https://www.thesportsdb.com/api/v2/json/3/lookup/event_lineup/1818398
    EPISODE_RESULT_URL = base_url.format(
        "lookup/event_results/"
    )  # eventresults.php => https://www.thesportsdb.com/api/v2/json/3/lookup/event_results/1662932
    PLAYER_URL = base_url.format(
        "lookup/player/"
    )  # lookupplayer.php => https://www.thesportsdb.com/api/v2/json/3/lookup/player/34145937
    SEASON_ARTWORK_URL = base_url.format(
        "list/seasonposters/")  # new in API V2 and only V2!
    HEADERS = (
        (
            "User-Agent",
            "Kodi sports events scraper by Project Kodi - metadata.thesportsdb.python; contact kodi-support@streimelweger.eu; API Version 2.0",
        ),
        ("Accept", "application/json"),
    )
    logger.debug("V2 API Settings load")
api_utils.set_headers(dict(HEADERS))


def get_nfo_tvshow_cast(idLeague):
    logger.debug(
        'Start function: get_nfo_tvshow_cast => parms idLeague"{}"'.format(idLeague))
    params = {}
    params["id"] = idLeague
    resp = api_utils.load_info(
        TEAMLIST_URL2, params=params, verboselog=settings.VERBOSELOG
    )
    if resp is None:
        return 'No data found'
    tvshowcast_info = resp["teams"]
    # tvshowcast_info = resp.get("teams")
    return tvshowcast_info


def get_nfo_episode_cast(idEvent):
    logger.debug(
        'Start function: get_nfo_episode_cast => parms idLeague"{}"'.format(idEvent))
    params = {}
    params["id"] = idEvent
    # First we check LineUp - Example Football,..
    resp1 = api_utils.load_info(
        EPISODE_LINEUP_URL, params=params, verboselog=settings.VERBOSELOG
    )
    # Fallback 1 - Example Golf, Formula 1, Poker,..
    logger.debug('get_nfo_episode_cast => resp1: "{}"'.format(resp1))
    if resp1['lineups'] != 'No data found':
        episodecast_info = resp1.get("lineups")
        logger.debug('get_nfo_episode_cast => resp1 => episodecast_info: OK "{}"'.format(
            episodecast_info))
    else:
        logger.debug(
            'get_nfo_episode_cast => resp1 => episodecast_info: NOT OK')
        resp2 = api_utils.load_info(
            EPISODE_RESULT_URL, params=params, verboselog=settings.VERBOSELOG
        )
        logger.debug('get_nfo_episode_cast => resp2: "{}"'.format(resp2))

        if resp2['results'] != 'No data found':
            episodecast_info = resp2.get("results")
            logger.debug(
                'get_nfo_episode_cast => resp2: OK "{}"'.format(episodecast_info))
        else:
            # Fallback 2 - Use TV show cast
            logger.debug('get_nfo_episode_cast => resp2: NOT OK')
            return 'No data found'
    # Ok or Fallback 1, not Fallback 2
    return episodecast_info


def get_nfo_episode_cast2(idPlayers):
    logger.debug(
        'Start function: get_nfo_episode_cast2 => parms idPlayers"{}"'.format(idPlayers))
    # loop => PLAYER_URL / (here: idPlayer / strPlayer / strTeam)
    nfo_episode_player = []
    for idPlayer in idPlayers:
        params = {}
        params["id"] = idPlayer["idPlayer"]
        # Call each Player
        resp1 = api_utils.load_info(
            PLAYER_URL, params=params, verboselog=settings.VERBOSELOG
        )
        if resp1['players'] != 'No data found':
            nfo_episode_player.append(resp1)
    # Nothing found => None
    if not nfo_episode_player:
        return 'No data found'
    # Return Results
    return nfo_episode_player


def search_show(title, api_version):
    # type: (Text ,int) -> Optional[List]
    """
    Search for a single sports league

    :param title: Sports League title to search
    :param api_version: API Version
    :return: a dict with the matching sports league
    """
    params = {}
    results = []
    logger.debug("using title of %s to find league" % title)
    resp = api_utils.load_info(
        SEARCH_URL, params=params, verboselog=settings.VERBOSELOG
    )
    if resp is not None:
        for league in resp.get("leagues"):
            if league.get("strLeague") == title:
                params["id"] = league.get("idLeague")
                resp_d = api_utils.load_info(
                    SHOW_URL, params=params, verboselog=settings.VERBOSELOG
                )
                if resp_d is not None:
                    results = resp_d.get("leagues")
                break
    if verboselog_adv:
        logger.debug('Function search_show results: "{}"'.format(results))
    return results


def load_show_info(show_id, api_version):
    # type: (Text ,int) -> Optional[InfoType]
    """Save rosters info to list item"""
    """
    Get full info for a single league

    :param show_id: thesportsDB League ID
    :param api_version: API Version   
    :return: show info or None
    """
    show_info = cache.load_show_info_from_cache(show_id)
    if show_info is None:
        logger.debug("no cache file found, loading from scratch")
        params = {}
        params["id"] = show_id
        resp = api_utils.load_info(
            SHOW_URL, params=params, verboselog=settings.VERBOSELOG
        )
        if resp is None:
            return None
        show_info = resp.get("leagues", [])[0]
        logger.debug("saving show info to the cache")
        if settings.VERBOSELOG:
            logger.debug(format(pformat(show_info)))
        cache.cache_show_info(show_info)
    else:
        logger.debug("using cached show info")
    if verboselog_adv:
        logger.debug(
            'Function load_show_info show_info: "{}"'.format(show_info))
    return show_info


def load_episode_info(show_id, episode_id, api_version):
    # type: (Text, Text ,int) -> Optional[InfoType]
    """
    Load episode info

    :param show_id:
    :param episode_id:
    :param api_version: API Version
    :return: episode info or None
    """
    show_info = load_show_info(show_id, api_version)
    found_event = False
    if show_info is not None:
        for event in show_info.get("event_list"):
            if event.get("idEvent") == episode_id:
                episode_info = event
                found_event = True
                break
        if not found_event:
            return None
        params = {"id": episode_id}
        resp = api_utils.load_info(
            EPISODE_URL, params=params, verboselog=settings.VERBOSELOG
        )
        if resp is None:
            return None
        ep_return = resp.get("events", [])[0]
        # ep_return["strEvent"] = episode_info.get("strEvent", "0")
        ep_return["strEpisode"] = episode_info.get("strEpisode", "0")
        if verboselog_adv:
            logger.debug(
                'Function load_episode_info ep_return: "{}"'.format(ep_return))
        return ep_return
    return None


def load_episode_info_short(spdb_edb_id):
    # type: (int) -> Optional[InfoType]
    """
    Load episode info

    :param spdb_edb_id:
    :return: ep_return or 'No data found'
    """
    if spdb_edb_id is not None:
        params = {"id": spdb_edb_id}
        resp = api_utils.load_info(
            EPISODE_URL, params=params, verboselog=settings.VERBOSELOG
        )
        if resp is None:
            return 'No data found'
        ep_return = resp.get("events", [])[0]
    return ep_return


def load_roster_info(team_id, team_name, api_version):
    if verboselog_adv:
        logger.debug('Start function => load_roster_info => team_id: "{}"'.format(team_id))
        logger.debug('Start function => load_roster_info => team_id: "{}"'.format(team_name))
    # type: (Text, Text ,int) -> Optional[InfoType]
    """
    Load roster info

    :param team_id:
    :param team_name:
    :param api_version: API Version
    :return: team roster or None
    """
    players = None
    resp = cache.load_show_info_from_cache(team_id)
    if not resp:
        params = {"t": team_name.replace(" ", "_")}
        resp = api_utils.load_info(
            ROSTER_URL, params=params, verboselog=settings.VERBOSELOG
        )
    if resp:
        # API V1:
        if api_version == "1":
            players = resp.get("player")
        # API V2: + Cache V1?
        elif api_version == "2":
            players = resp.get("players")
            if players is None:
                players = resp.get("player") 



        if verboselog_adv:
            logger.debug(
                'Function load_roster_info Respong ROSTER_URL: "{}"'.format(
                    resp)
            )
            logger.debug(
                'Function load_roster_info Respong ROSTER_URL => players: "{}"'.format(
                    players
                )
            )

        # Save all Information about Player from one Team in Cache
        info = {"idTeam": team_id, "player": players}
        cache.cache_show_info(info, info_type="roster")
    if verboselog_adv:
        logger.debug('Function load_roster_info players: "{}"'.format(players))
    return players


def load_team_list(league_name, api_version):
    # type: (Text ,int) -> Optional[InfoType]
    """
    Load team list for league

    :param league_name:
    :param api_version: API Version
    :return: team list or None
    """
    teams = None
    params = {"l": league_name.replace(" ", "_")}
    resp = api_utils.load_info(
        TEAMLIST_URL, params=params, verboselog=settings.VERBOSELOG
    )
    if resp:
        teams = resp.get("teams")
    if verboselog_adv:
        logger.debug('Function load_team_list teams: "{}"'.format(teams))
    return teams


def load_season_info(show_id, api_version):
    # type: (Text ,int) -> Optional[InfoType]
    """
    Load season info

    :param show_id:
    :param api_version: API Version
    :return: season list or None
    """
    params = {"id": show_id}
    resp = api_utils.load_info(
        SEASON_URL, params=params, verboselog=settings.VERBOSELOG
    )
    if resp:
        if verboselog_adv:
            logger.debug(
                'Function load_season_info seasons: "{}"'.format(
                    resp.get("seasons"))
            )
        return resp.get("seasons")
    return None


def load_season_episodes(idLeague, season_name, api_version):
    # type: (int, Text ,int) -> Optional[InfoType]
    """
    Load episode list for given season

    :param idLeague:
    :param season_name:
    :param api_version: API Version
    :return: episode list or None
    """
    params = {}
    params["id"] = idLeague
    params["s"] = season_name
    resp = api_utils.load_info(
        EVENTLIST_URL, params=params, verboselog=settings.VERBOSELOG
    )
    if resp:
        if verboselog_adv:
            logger.debug(
                'Function load_season_episodes events: "{}"'.format(
                    resp.get("events"))
            )
        return resp.get("events")
    return None


def load_season_artwork(show_id, api_version):
    # type: (Text ,int) -> Optional[InfoType]
    """
    Load season artwork

    :param show_id:
    :param api_version: API Version
    :return: season poster list or None
    """
    params = {"id": show_id}
    resp = api_utils.load_info(
        SEASON_ARTWORK_URL, params=params, verboselog=settings.VERBOSELOG
    )
    if resp:
        if verboselog_adv:
            logger.debug(
                'Function load_season_artwork posters: "{}"'.format(
                    resp.get("seasonposters")
                )
            )
        return resp.get("seasonposters")
    return None
