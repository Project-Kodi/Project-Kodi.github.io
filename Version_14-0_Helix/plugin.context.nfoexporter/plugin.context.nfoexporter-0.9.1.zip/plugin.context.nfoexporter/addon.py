"""
    Plugin: NFO Exporter
    See https://github.com/Project-Kodi/Project-Kodi.github.io
    
"""

# Imports
import subprocess
import os
import sys
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
import urllib3
import json
import time
import re
from pathlib import Path
from functools import partial
from datetime import datetime

# Addon Infos
self = xbmcaddon.Addon()
self_addon_name = self.getAddonInfo('name')
self_addon_id = self.getAddonInfo('id')
self_addon_version = self.getAddonInfo('version')
self_addon_providername = self.getAddonInfo('author')
self_addon_icon = self.getAddonInfo('icon')

# Fixed values/configs
time2000 = 2000
time4000 = 4000
TimeStamp = datetime.now().strftime('%d-%m-%Y %H:%M:%S')
RepositoryInfo = 'https://Project-Kodi.github.io/'

# Function: Info Log
def log_info(log_entry):
    if self.getSettingBool('utility_logging01'):
        xbmc.log( 'plugin.context.nfoexporter: Info: %s' % log_entry, xbmc.LOGINFO)

# Function: Debug Log
def log_debug(log_entry):
    if self.getSettingBool('utility_logging02'):
        xbmc.log( 'plugin.context.nfoexporter: DEBUG: %s' % log_entry)

# Function: datetime
def show_datetime():
    clean_show_datetime = str(datetime.now())
    return clean_show_datetime

# Function: Remove all control characters
def control_characters(dirty_str):
    clean_str = re.sub(r'[\x00-\x1f]', '', str(dirty_str))
    return clean_str

# Function: Show Notification
def notification(not_head, not_msg, not_time):
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(not_head, not_msg, not_time, self_addon_icon))

# Function: Write *.nfo file and fill it with content
def write_nfo_file_msg(filepathfull, filecontent):
    log_debug('Write *.nfo Data to: ' + filepathfull)
    #old version
    #with xbmcvfs.File(filepathfull, 'w') as f:
        #result = f.write(filecontent)
    index = 0
    with xbmcvfs.File(filepathfull, 'w') as f:
        result = f.write('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n')
        f.write('<!-- Created by ' + self_addon_name + ' Version ' + self_addon_version + ' | Provider: ' + self_addon_providername + ' | Addon: ' + self_addon_id + ' | Repository: ' + RepositoryInfo + ' | Created on ' + TimeStamp + ' -->\n')
        while index < len(filecontent):
            #print(filecontent[index])
            #f.write(str(filecontent[index]) + '\n')            
            f.write(str(filecontent[index]) + '')
            index += 1
        f.close()
        if result:
            log_info('write_nfo_file: OK')
            notification('NFO Exporter', 'Exported to: ' + filepathfull + '', time4000)
            #xbmcgui.Dialog().notification("NFO Exporter", "Exported to: " + filepathfull)
        else:    
            log_info('write_nfo_file: ERROR')
            #Fehler Behandlung
            #searchlist = ''
            if filepathfull.find("/") > 0:
                print('DEV: ---- Slash or Backslah: / ')
                searchlist = filepathfull.rsplit('/', 1)
            if filepathfull.find("\\") > 0:
                print('DEV: ---- Slash or Backslah: \ ')
                searchlist = filepathfull.rsplit('\\', 1)
            filepathfull_help = searchlist[0]
            #Existiert der Pfad nicht?
            if xbmcvfs.exists(filepathfull):
                log_info('write_nfo_file: Pfad existiert')
            else:
                xbmcvfs.mkdirs(filepathfull_help)                         
                log_info('write_nfo_file: MKDIRS: ' + filepathfull_help)
                with xbmcvfs.File(filepathfull, 'w') as f:
                    result = f.write(filecontent)
                if result:                
                    log_info('Again.. write_nfo_file: OK')
                else:    
                    log_info('Again.. write_nfo_file: ERROR')
            #xbmcgui.Dialog().notification("NFO Exporter", "Exported to: " + filepathfull)
            notification('NFO Exporter', 'Exported to: ' + filepathfull + '', time4000)            
    log_debug('Write *.nfo Content: ' + str(filecontent))   

# Function: NFO Content MOVIE => https://kodi.wiki/view/NFO_files/Templates
def create_nfo_content_movie():
    log_debug('DEV: ---- Running function: create_nfo_content_movie')
    getvit = sys.listitem.getVideoInfoTag()
    
    #Anfang Movies
    nfo_content_movie = ['<movie>\n']
    #Movie + Title's    
    if getvit.getTitle():
        nfo_content_movie.append('\t<title>' + getvit.getTitle() + '</title>\n')
        nfo_content_movie.append('\t<sorttitle>' + getvit.getTitle() + '</sorttitle>\n')
    if getvit.getOriginalTitle():    
        nfo_content_movie.append('\t<originaltitle>' + getvit.getOriginalTitle() + '</originaltitle>\n') 
    #Ratings - IMDB
    nfo_content_movie.append('\t<ratings>\n')
    if getvit.getRating('imdb'):
        nfo_content_movie.append('\t\t<rating name="imdb" max="10" default="true">\n')
        nfo_content_movie.append('\t\t\t<value>' + str(getvit.getRating('imdb')) + '</value>\n')
    if getvit.getVotesAsInt('imdb'):    
        nfo_content_movie.append('\t\t\t<votes>' + str(getvit.getVotesAsInt('imdb')) + '</votes>\n')
    if getvit.getRating('imdb'):
        nfo_content_movie.append('\t\t</rating>\n')
    #Ratings - TMDB
    if getvit.getRating('tmdb'):
        nfo_content_movie.append('\t\t<rating name="tmdb" max="10" default="true">\n')
        nfo_content_movie.append('\t\t\t<value>' + str(getvit.getRating('tmdb')) + '</value>\n')
    if getvit.getVotesAsInt('tmdb'):    
        nfo_content_movie.append('\t\t\t<votes>' + str(getvit.getVotesAsInt('tmdb')) + '</votes>\n')
    if getvit.getRating('tmdb'):
        nfo_content_movie.append('\t\t</rating>\n')
    #Ratings - ANID
    if getvit.getRating('anidb'):
        nfo_content_movie.append('\t\t<rating name="anidb" max="10" default="true">\n')
        nfo_content_movie.append('\t\t\t<value>' + str(getvit.getRating('anidb')) + '</value>\n')
    if getvit.getVotesAsInt('anidb'):    
        nfo_content_movie.append('\t\t\t<votes>' + str(getvit.getVotesAsInt('anidb')) + '</votes>\n')
    if getvit.getRating('anidb'):
        nfo_content_movie.append('\t\t</rating>\n')
    #Ratings - TVDB
    if getvit.getRating('tvdb'):
        nfo_content_movie.append('\t\t<rating name="tvdb" max="10" default="true">\n')
        nfo_content_movie.append('\t\t\t<value>' + str(getvit.getRating('tvdb')) + '</value>\n')
    if getvit.getVotesAsInt('tvdb'):    
        nfo_content_movie.append('\t\t\t<votes>' + str(getvit.getVotesAsInt('tvdb')) + '</votes>\n')
    if getvit.getRating('tvdb'):
        nfo_content_movie.append('\t\t</rating>\n')
    nfo_content_movie.append('\t</ratings>\n')
    #User Ratings
    if getvit.getUserRating():
        nfo_content_movie.append('\t<userrating>' + str(getvit.getUserRating()) + '</userrating>\n')
    nfo_content_movie.append('\t<top250></top250>\n')
    #Plot and Tags
    if getvit.getPlotOutline():
        nfo_content_movie.append('\t<outline>' + getvit.getPlotOutline() + '</outline>\n')
    if getvit.getPlot():
        nfo_content_movie.append('\t<plot>' + getvit.getPlot() + '</plot>\n')
    if getvit.getTagLine():
        nfo_content_movie.append('\t<tagline>' + getvit.getTagLine() + '</tagline>\n')
    if getvit.getDuration():    
        nfo_content_movie.append('\t<runtime>' + str(getvit.getDuration()) + '</runtime>\n')

    #nfo_content_movie.append('\t<thumb spoof="" cache="" aspect="poster" preview="">https://image.tmdb.org/t/p/original/nEVjOpekbcdBqAexiWu7zXuFlYU.jpg</thumb>\n')
    #nfo_content_movie.append('\t<thumb spoof="" cache="" aspect="landscape" preview="">https://image.tmdb.org/t/p/original/iBXBqas9DMzesltQEBNM6BH3akt.jpg</thumb>\n')
    #nfo_content_movie.append('\t<thumb spoof="" cache="" aspect="set.poster" preview="">https://image.tmdb.org/t/p/original/xMsRZIkUGUuHsNHCQBDyZH7l53M.jpg</thumb>\n')
    #nfo_content_movie.append('\t<thumb spoof="" cache="" aspect="set.landscape" preview="">https://image.tmdb.org/t/p/original/mkusMBRJyXJCcJ5RKlrKK2SC0Qv.jpg</thumb>\n')
    #nfo_content_movie.append('\t<thumb spoof="" cache="" aspect="set.fanart" preview="">https://image.tmdb.org/t/p/original/3Odw3MJymLLbFuOnmQjmvndKhOr.jpg</thumb>\n')
    #nfo_content_movie.append('\t<thumb spoof="" cache="" aspect="clearlogo" preview="">https://assets.fanart.tv/fanart/movies/476669/hdmovielogo/the-kings-man-601651c77c528.png</thumb>\n')
    #nfo_content_movie.append('\t<thumb spoof="" cache="" aspect="discart" preview="">https://assets.fanart.tv/fanart/movies/476669/moviedisc/the-kings-man-617786bba9b7f.png</thumb>\n')
    #nfo_content_movie.append('\t<thumb spoof="" cache="" aspect="clearart" preview="">https://assets.fanart.tv/fanart/movies/476669/hdmovieclearart/the-kings-man-61c1bf1b46f3b.png</thumb>\n')
    #nfo_content_movie.append('\t<thumb spoof="" cache="" aspect="keyart" preview="">https://assets.fanart.tv/fanart/movies/476669/movieposter/the-kings-man-5f468bd247c3b.jpg</thumb>\n')
    #nfo_content_movie.append('\t<thumb spoof="" cache="" aspect="banner" preview="">https://assets.fanart.tv/fanart/movies/476669/moviebanner/the-kings-man-5e86bd6f81322.jpg</thumb>\n')
    #nfo_content_movie.append('\t<thumb spoof="" cache="" aspect="set.clearlogo" preview="">https://assets.fanart.tv/fanart/movies/391860/hdmovielogo/kingsman-collection-5a69d2e6eaa21.png</thumb>\n')
    #nfo_content_movie.append('\t<thumb spoof="" cache="" aspect="set.keyart" preview="">https://assets.fanart.tv/fanart/movies/391860/movieposter/kingsman-collection-5add0aa47e577.jpg</thumb>\n')
    #nfo_content_movie.append('\t<thumb spoof="" cache="" aspect="set.banner" preview="">https://assets.fanart.tv/fanart/movies/391860/moviebanner/kingsman-collection-5a691aee3c1e1.jpg</thumb>\n')
    #nfo_content_movie.append('\t<fanart>\n')
    #nfo_content_movie.append('\t\t<thumb colors="" preview="https://image.tmdb.org/t/p/w780/A49NScAT4ZcgeC6HeSvkUPVNJaF.jpg">https://image.tmdb.org/t/p/original/A49NScAT4ZcgeC6HeSvkUPVNJaF.jpg</thumb>\n')
    #nfo_content_movie.append('\t</fanart>\n')

    #Abspieldaten
    if getvit.getPlayCount():
        nfo_content_movie.append('\t<playcount>' + str(getvit.getPlayCount()) + '</playcount>\n')
    if getvit.getLastPlayedAsW3C():    
        nfo_content_movie.append('\t<lastplayed>' + getvit.getLastPlayedAsW3C() + '</lastplayed>\n')
    #Databse Kodi ID from Movie    
    if getvit.getDbId():
        nfo_content_movie.append('\t<id>' + str(getvit.getDbId()) + '</id>\n')
    #Database IMDBNumber
    if getvit.getIMDBNumber():
        nfo_content_movie.append('\t<imdb>' + str(getvit.getIMDBNumber()) + '</imdb> <!-- https://www.imdb.com/ -->\n')
    #Databse ID's IMDB, TMDB, TVDB, ANIDB + WIKIDATA, FACEBOOK, INSTAGRAM & X    
    if getvit.getUniqueID('imdb'):
        nfo_content_movie.append('\t<uniqueid type="imdb" default="true">' + str(getvit.getUniqueID('imdb')) + '</uniqueid> <!-- https://www.imdb.com/ -->\n')
    if getvit.getUniqueID('tmdb'):
        nfo_content_movie.append('\t<uniqueid default="false" type="tmdb">' + str(getvit.getUniqueID('tmdb')) + '</uniqueid> <!-- https://www.themoviedb.com/ -->\n')
    if getvit.getUniqueID('tvdb'):
        nfo_content_movie.append('\t<uniqueid default="false" type="tvdb">' + str(getvit.getUniqueID('tvdb')) + '</uniqueid> <!-- https://www.thetvdb.com/ -->\n')
    if getvit.getUniqueID('anidb'):
        nfo_content_movie.append('\t<uniqueid default="false" type="anidb">' + str(getvit.getUniqueID('anidb')) + '</uniqueid> <!-- https://anidb.net/ -->\n')
    nfo_content_movie.append('\t<uniqueid default="false" type="wikidata"></uniqueid> <!-- https://www.wikidata.org/ -->\n')
    nfo_content_movie.append('\t<uniqueid default="false" type="facebook"></uniqueid> <!-- https://www.facebook.com/ -->\n')
    nfo_content_movie.append('\t<uniqueid default="false" type="instagram"></uniqueid> <!-- https://www.instagram.com/ -->\n')
    nfo_content_movie.append('\t<uniqueid default="false" type="x"></uniqueid> <!-- https://x.com/ -->\n')
    #Genres
    if getvit.getGenres(): 
        for x_genre in getvit.getGenres():
            nfo_content_movie.append('\t<genre>' + x_genre + '</genre>\n')

    #Movie Set
    #nfo_content_movie.append('\t<set>\n')
    #nfo_content_movie.append('\t\t<name></name>\n')
    #nfo_content_movie.append('\t\t<overview></overview>\n')
    #nfo_content_movie.append('\t</set>\n')

    #Feature? setVideoAssetTitle() // but not get.. 
    ##### Einfach leer als Platzhalter..    
    nfo_content_movie.append('\t<videoassettitle>Standard Edition</videoassettitle>\n')
    nfo_content_movie.append('\t<videoassetid>40400</videoassetid>\n')
    nfo_content_movie.append('\t<videoassettype>0</videoassettype>\n')
    nfo_content_movie.append('\t<hasvideoversions>false</hasvideoversions>\n')
    nfo_content_movie.append('\t<hasvideoextras>false</hasvideoextras>\n')
    nfo_content_movie.append('\t<isdefaultvideoversion>true</isdefaultvideoversion>\n')
    #Director,Premiered,Year,First Aired,Trailer..
    if getvit.getWritingCredits():
        nfo_content_movie.append('\t<credits>' + getvit.getWritingCredits() + '</credits>\n')
    if getvit.getDirector():
        nfo_content_movie.append('\t<director>' + getvit.getDirector() + '</director>\n')
    if getvit.getPremieredAsW3C():
        nfo_content_movie.append('\t<premiered>' + getvit.getPremieredAsW3C() + '</premiered>\n')
    if getvit.getYear():
        nfo_content_movie.append('\t<year>' + str(getvit.getYear()) + '</year>\n')
    if getvit.getFirstAiredAsW3C():
        nfo_content_movie.append('\t<aired>' + getvit.getFirstAiredAsW3C() + '</aired>\n')
    if getvit.getTrailer():
        nfo_content_movie.append('\t<trailer>' + getvit.getTrailer() + '</trailer>\n')
    #Status, Code, Studio,Country, - unbenutzt    
    nfo_content_movie.append('\t<status></status>\n')
    nfo_content_movie.append('\t<code></code>\n')
    nfo_content_movie.append('\t<studio></studio>\n')
    nfo_content_movie.append('\t<country></country>\n')
    nfo_content_movie.append('\t<mpaa></mpaa>\n')
    nfo_content_movie.append('\t<tag></tag>\n')    
    #Datei Informationen
    #nfo_content_movie.append('\t<fileinfo>\n')
    #nfo_content_movie.append('\t\t<streamdetails>\n')
    #nfo_content_movie.append('\t\t\t<video>\n')
    #nfo_content_movie.append('\t\t\t\t<codec>h264</codec>\n')
    #nfo_content_movie.append('\t\t\t\t<aspect>1.777778</aspect>\n')
    #nfo_content_movie.append('\t\t\t\t<width>1920</width>\n')
    #nfo_content_movie.append('\t\t\t\t<height>1080</height>\n')
    #nfo_content_movie.append('\t\t\t\t<durationinseconds>7838</durationinseconds>\n')
    #nfo_content_movie.append('\t\t\t\t<stereomode></stereomode>\n')
    #nfo_content_movie.append('\t\t\t\t<hdrtype></hdrtype>\n')
    #nfo_content_movie.append('\t\t\t</video>\n')
    #nfo_content_movie.append('\t\t\t<audio>\n')
    #nfo_content_movie.append('\t\t\t\t<codec>dtshd_ma</codec>\n')
    #nfo_content_movie.append('\t\t\t\t<language>eng</language>\n')
    #nfo_content_movie.append('\t\t\t\t<channels>8</channels>\n')
    #nfo_content_movie.append('\t\t\t</audio>\n')
    #nfo_content_movie.append('\t\t\t<subtitle>\n')
    #nfo_content_movie.append('\t\t\t\t<language>eng</language>\n')
    #nfo_content_movie.append('\t\t\t</subtitle>\n')
    #nfo_content_movie.append('\t\t</streamdetails>\n')
    #nfo_content_movie.append('\t</fileinfo>\n')
    
    #Actors
    #nfo_content_movie.append('\t<actor>\n')
    #nfo_content_movie.append('\t\t<name></name>\n')
    #nfo_content_movie.append('\t\t<role></role>\n')
    #nfo_content_movie.append('\t\t<order></order>\n')
    #nfo_content_movie.append('\t\t<thumb>https://image.tmdb.org/t/p/original/tJr9GcmGNHhLVVEH3i7QYbj6hBi.jpg</thumb>\n')
    #nfo_content_movie.append('\t</actor>\n')

    #Cast?

    #Writer - unknown tag..
    if getvit.getWriters(): 
        for x_writer in getvit.getWriters():
            nfo_content_movie.append('\t<writer>' + x_writer + '</writer\n')
    #Ende Movie
    nfo_content_movie.append('</movie>\n')
    return nfo_content_movie


# Function: NFO Content TVSHOW => https://kodi.wiki/view/NFO_files/Templates
def create_nfo_content_tvshow():
    log_debug('DEV: ---- Running function: create_nfo_content_tvshow')
    getvit = sys.listitem.getVideoInfoTag()
 
    #Episodeguide New: dictionaries
    episodeguide_dict = dict()

    #Anfang TVSHOW
    nfo_content_tvshow = ['<tvshow>\n']
    #Titel
    if getvit.getTitle():
        nfo_content_tvshow.append('\t<title>' + getvit.getTitle() + '</title>\n')
        nfo_content_tvshow.append('\t<sorttitle>' + getvit.getTitle() + '</sorttitle>\n')
        nfo_content_tvshow.append('\t<showtitle>' + getvit.getTitle() + '</showtitle>\n')
    if getvit.getOriginalTitle():    
        nfo_content_tvshow.append('\t<originaltitle>' + getvit.getOriginalTitle() + '</originaltitle>\n') 
    #Season
    if getvit.getSeason():
        nfo_content_tvshow.append('\t<season>' + str(getvit.getSeason()) + '</season>\n')
    #Episoden Anzahl! - Achtung, Anzahl an gespeicherten Kodi Episoden und nicht von Scraper! = zeigt eventuell weniger als es zur Gänze gibt
    if getvit.getEpisode():
        nfo_content_tvshow.append('\t<episode>' + str(getvit.getEpisode()) + '</episode>\n')
    #Ratings - IMDB
    nfo_content_tvshow.append('\t<ratings>\n')
    if getvit.getRating('imdb'):
        nfo_content_tvshow.append('\t\t<rating name="imdb" max="10" default="true">\n')
        nfo_content_tvshow.append('\t\t\t<value>' + str(getvit.getRating('imdb')) + '</value>\n')
    if getvit.getVotesAsInt('imdb'):    
        nfo_content_tvshow.append('\t\t\t<votes>' + str(getvit.getVotesAsInt('imdb')) + '</votes>\n')
    if getvit.getRating('imdb'):
        nfo_content_tvshow.append('\t\t</rating>\n')
    #Ratings - TMDB
    if getvit.getRating('tmdb'):
        nfo_content_tvshow.append('\t\t<rating name="tmdb" max="10" default="true">\n')
        nfo_content_tvshow.append('\t\t\t<value>' + str(getvit.getRating('tmdb')) + '</value>\n')
    if getvit.getVotesAsInt('tmdb'):    
        nfo_content_tvshow.append('\t\t\t<votes>' + str(getvit.getVotesAsInt('tmdb')) + '</votes>\n')
    if getvit.getRating('tmdb'):
        nfo_content_tvshow.append('\t\t</rating>\n')
    #Ratings - ANID
    if getvit.getRating('anidb'):
        nfo_content_tvshow.append('\t\t<rating name="anidb" max="10" default="true">\n')
        nfo_content_tvshow.append('\t\t\t<value>' + str(getvit.getRating('anidb')) + '</value>\n')
    if getvit.getVotesAsInt('anidb'):    
        nfo_content_tvshow.append('\t\t\t<votes>' + str(getvit.getVotesAsInt('anidb')) + '</votes>\n')
    if getvit.getRating('anidb'):
        nfo_content_tvshow.append('\t\t</rating>\n')
    #Ratings - TVDB
    if getvit.getRating('tvdb'):
        nfo_content_tvshow.append('\t\t<rating name="tvdb" max="10" default="true">\n')
        nfo_content_tvshow.append('\t\t\t<value>' + str(getvit.getRating('tvdb')) + '</value>\n')
    if getvit.getVotesAsInt('tvdb'):    
        nfo_content_tvshow.append('\t\t\t<votes>' + str(getvit.getVotesAsInt('tvdb')) + '</votes>\n')
    if getvit.getRating('tvdb'):
        nfo_content_tvshow.append('\t\t</rating>\n')
    nfo_content_tvshow.append('\t</ratings>\n')
    #User Ratings
    if getvit.getUserRating():
        nfo_content_tvshow.append('\t<userrating>' + str(getvit.getUserRating()) + '</userrating>\n')
    nfo_content_tvshow.append('\t<top250></top250>\n')
    #Plot and Tags
    if getvit.getPlotOutline():
        nfo_content_tvshow.append('\t<outline>' + getvit.getPlotOutline() + '</outline>\n')
    if getvit.getPlot():
        nfo_content_tvshow.append('\t<plot>' + getvit.getPlot() + '</plot>\n')
    if getvit.getTagLine():
        nfo_content_tvshow.append('\t<tagline>' + getvit.getTagLine() + '</tagline>\n')
    if getvit.getDuration():    
        nfo_content_tvshow.append('\t<runtime>' + str(getvit.getDuration()) + '</runtime>\n')    

    #nfo_content_tvshow.append('\t<thumb spoof="" cache="" aspect="poster" preview="">https://image.tmdb.org/t/p/original/nEVjOpekbcdBqAexiWu7zXuFlYU.jpg</thumb>\n')
    #nfo_content_tvshow.append('\t<thumb spoof="" cache="" aspect="landscape" preview="">https://image.tmdb.org/t/p/original/iBXBqas9DMzesltQEBNM6BH3akt.jpg</thumb>\n')
    #nfo_content_tvshow.append('\t<thumb spoof="" cache="" aspect="set.poster" preview="">https://image.tmdb.org/t/p/original/xMsRZIkUGUuHsNHCQBDyZH7l53M.jpg</thumb>\n')
    #nfo_content_tvshow.append('\t<thumb spoof="" cache="" aspect="set.landscape" preview="">https://image.tmdb.org/t/p/original/mkusMBRJyXJCcJ5RKlrKK2SC0Qv.jpg</thumb>\n')
    #nfo_content_tvshow.append('\t<thumb spoof="" cache="" aspect="set.fanart" preview="">https://image.tmdb.org/t/p/original/3Odw3MJymLLbFuOnmQjmvndKhOr.jpg</thumb>\n')
    #nfo_content_tvshow.append('\t<thumb spoof="" cache="" aspect="clearlogo" preview="">https://assets.fanart.tv/fanart/movies/476669/hdmovielogo/the-kings-man-601651c77c528.png</thumb>\n')
    #nfo_content_tvshow.append('\t<thumb spoof="" cache="" aspect="discart" preview="">https://assets.fanart.tv/fanart/movies/476669/moviedisc/the-kings-man-617786bba9b7f.png</thumb>\n')
    #nfo_content_tvshow.append('\t<thumb spoof="" cache="" aspect="clearart" preview="">https://assets.fanart.tv/fanart/movies/476669/hdmovieclearart/the-kings-man-61c1bf1b46f3b.png</thumb>\n')
    #nfo_content_tvshow.append('\t<thumb spoof="" cache="" aspect="keyart" preview="">https://assets.fanart.tv/fanart/movies/476669/movieposter/the-kings-man-5f468bd247c3b.jpg</thumb>\n')
    #nfo_content_tvshow.append('\t<thumb spoof="" cache="" aspect="banner" preview="">https://assets.fanart.tv/fanart/movies/476669/moviebanner/the-kings-man-5e86bd6f81322.jpg</thumb>\n')
    #nfo_content_tvshow.append('\t<thumb spoof="" cache="" aspect="set.clearlogo" preview="">https://assets.fanart.tv/fanart/movies/391860/hdmovielogo/kingsman-collection-5a69d2e6eaa21.png</thumb>\n')
    #nfo_content_tvshow.append('\t<thumb spoof="" cache="" aspect="set.keyart" preview="">https://assets.fanart.tv/fanart/movies/391860/movieposter/kingsman-collection-5add0aa47e577.jpg</thumb>\n')
    #nfo_content_tvshow.append('\t<thumb spoof="" cache="" aspect="set.banner" preview="">https://assets.fanart.tv/fanart/movies/391860/moviebanner/kingsman-collection-5a691aee3c1e1.jpg</thumb>\n')
    #nfo_content_tvshow.append('\t<fanart>\n')
    #nfo_content_tvshow.append('\t\t<thumb colors="" preview="https://image.tmdb.org/t/p/w780/A49NScAT4ZcgeC6HeSvkUPVNJaF.jpg">https://image.tmdb.org/t/p/original/A49NScAT4ZcgeC6HeSvkUPVNJaF.jpg</thumb>\n')
    #nfo_content_tvshow.append('\t</fanart>\n')

    #Abspieldaten
    if getvit.getPlayCount():
        nfo_content_tvshow.append('\t<playcount>' + str(getvit.getPlayCount()) + '</playcount>\n')
    if getvit.getLastPlayedAsW3C():    
        nfo_content_tvshow.append('\t<lastplayed>' + getvit.getLastPlayedAsW3C() + '</lastplayed>\n')
    #Databse Kodi ID from Movie    
    if getvit.getDbId():
        nfo_content_tvshow.append('\t<id>' + str(getvit.getDbId()) + '</id>\n')
    #Database IMDBNumber
    if getvit.getIMDBNumber():
        nfo_content_tvshow.append('\t<imdb>' + str(getvit.getIMDBNumber()) + '</imdb> <!-- https://www.imdb.com/ -->\n')
        episodeguide_dict["imdb"] = getvit.getIMDBNumber()
    #Databse ID's IMDB, TMDB, TVDB, ANIDB + WIKIDATA, FACEBOOK, INSTAGRAM & X    
    if getvit.getUniqueID('imdb'):
        nfo_content_tvshow.append('\t<uniqueid type="imdb" default="true">' + str(getvit.getUniqueID('imdb')) + '</uniqueid> <!-- https://www.imdb.com/ -->\n')
        episodeguide_dict["imdb"] = getvit.getUniqueID('imdb')       
    if getvit.getUniqueID('tmdb'):
        nfo_content_tvshow.append('\t<uniqueid default="false" type="tmdb">' + str(getvit.getUniqueID('tmdb')) + '</uniqueid> <!-- https://www.themoviedb.com/ -->\n')
        episodeguide_dict["tmdb"] = getvit.getUniqueID('tmdb') 
    if getvit.getUniqueID('tvdb'):
        nfo_content_tvshow.append('\t<uniqueid default="false" type="tvdb">' + str(getvit.getUniqueID('tvdb')) + '</uniqueid> <!-- https://www.thetvdb.com/ -->\n')
        episodeguide_dict["tvdb"] = getvit.getUniqueID('tvdb') 
    if getvit.getUniqueID('anidb'):
        nfo_content_tvshow.append('\t<uniqueid default="false" type="anidb">' + str(getvit.getUniqueID('anidb')) + '</uniqueid> <!-- https://anidb.net/ -->\n')
        episodeguide_dict["anidb"] = getvit.getUniqueID('anidb') 

    nfo_content_tvshow.append('\t<uniqueid default="false" type="tvrage"></uniqueid> <!-- https://www.tvrage.com/ -->\n')
    nfo_content_tvshow.append('\t<uniqueid default="false" type="tvmaze"></uniqueid> <!-- https://www.tvmaze.com/ -->\n')
    nfo_content_tvshow.append('\t<uniqueid default="false" type="zap2it"></uniqueid> <!-- https://tvschedule.zap2it.com/ -->\n')                
    nfo_content_tvshow.append('\t<uniqueid default="false" type="tsdb"></uniqueid> <!-- https://www.thesportsdb.com/ --> \n')    
    nfo_content_tvshow.append('\t<uniqueid default="false" type="wikidata"></uniqueid> <!-- https://www.wikidata.org/ -->\n')
    nfo_content_tvshow.append('\t<uniqueid default="false" type="facebook"></uniqueid> <!-- https://www.facebook.com/ -->\n')
    nfo_content_tvshow.append('\t<uniqueid default="false" type="instagram"></uniqueid> <!-- https://www.instagram.com/ -->\n')
    nfo_content_tvshow.append('\t<uniqueid default="false" type="x"></uniqueid> <!-- https://x.com/ -->\n')
    
    #Episodeguide New
    json_episodeguide = json.dumps(episodeguide_dict)
    nfo_content_tvshow.append('\t<episodeguide>' + json_episodeguide + '</episodeguide>\n')

    #Genres
    if getvit.getGenres(): 
        for x_genre in getvit.getGenres():
            nfo_content_tvshow.append('\t<genre>' + x_genre + '</genre>\n')

    #Director,Premiered,Year,First Aired,Trailer..
    if getvit.getWritingCredits():
        nfo_content_tvshow.append('\t<credits>' + getvit.getWritingCredits() + '</credits>\n')
    if getvit.getDirector():
        nfo_content_tvshow.append('\t<director>' + getvit.getDirector() + '</director>\n')
    if getvit.getPremieredAsW3C():
        nfo_content_tvshow.append('\t<premiered>' + getvit.getPremieredAsW3C() + '</premiered>\n')
    if getvit.getYear():
        nfo_content_tvshow.append('\t<year>' + str(getvit.getYear()) + '</year>\n')
    if getvit.getFirstAiredAsW3C():
        nfo_content_tvshow.append('\t<aired>' + getvit.getFirstAiredAsW3C() + '</aired>\n')
    if getvit.getTrailer():
        nfo_content_tvshow.append('\t<trailer>' + getvit.getTrailer() + '</trailer>\n')
    #Status, Code, Studio,Country, - unbenutzt    
    nfo_content_tvshow.append('\t<status></status>\n')
    nfo_content_tvshow.append('\t<code></code>\n')
    nfo_content_tvshow.append('\t<studio></studio>\n')
    nfo_content_tvshow.append('\t<country></country>\n')
    nfo_content_tvshow.append('\t<mpaa></mpaa>\n')
    nfo_content_tvshow.append('\t<tag></tag>\n')    
    
    #Actors
    #nfo_content_tvshow.append('\t<actor>\n')
    #nfo_content_tvshow.append('\t\t<name></name>\n')
    #nfo_content_tvshow.append('\t\t<role></role>\n')
    #nfo_content_tvshow.append('\t\t<order></order>\n')
    #nfo_content_tvshow.append('\t\t<thumb>https://image.tmdb.org/t/p/original/tJr9GcmGNHhLVVEH3i7QYbj6hBi.jpg</thumb>\n')
    #nfo_content_tvshow.append('\t</actor>\n')

    #Cast?

    #Writer - unknown tag..
    if getvit.getWriters(): 
        for x_writer in getvit.getWriters():
            nfo_content_tvshow.append('\t<writer>' + x_writer + '</writer\n')

    #Ende TVSHOW
    nfo_content_tvshow.append('</tvshow>\n')
    return nfo_content_tvshow

# Function: NFO Content SEASON => https://kodi.wiki/view/NFO_files/Templates
def create_nfo_content_season():
    log_debug('DEV: ---- Running function: create_nfo_content_season')
    getvit = sys.listitem.getVideoInfoTag()
    #Episodeguide New: dictionaries
    episodeguide_dict = dict()

    #Anfang Season
    nfo_content_season = ['<season>\n']
    #Season Number
    if getvit.getSeason():
        nfo_content_season.append('\t<seasonnumber>' + str(getvit.getSeason()) + '</seasonnumber>\n')
    #Titel - Hier Staffel xx
    if getvit.getTitle():
        nfo_content_season.append('\t<sorttitle>' + getvit.getTitle() + '</sorttitle>\n')
        nfo_content_season.append('\t<title>' + getvit.getTitle() + '</title>\n')

    #TVShow Name
    payload = {'jsonrpc': '2.0', 'method': "Files.GetDirectory", 'params': {"properties": ['showtitle','title', 'season', 'episode', 'file'],"directory": playpath, "media": "video"}, 'id': 1}
    info = json.loads(xbmc.executeJSONRPC(json.dumps(payload)))
    info = info["result"]
    showtitle=info['files'][0]['showtitle']
    nfo_content_season.append('\t<showtitle>' + str(showtitle) + '</showtitle>\n')    

    if getvit.getOriginalTitle():    
        nfo_content_season.append('\t<originaltitle>' + getvit.getOriginalTitle() + '</originaltitle>\n') 

    #Databse Kodi ID from Movie    
    if getvit.getDbId():
        nfo_content_season.append('\t<id>' + str(getvit.getDbId()) + '</id>\n')
    #Database IMDBNumber
    if getvit.getIMDBNumber():
        nfo_content_season.append('\t<imdb>' + str(getvit.getIMDBNumber()) + '</imdb> <!-- https://www.imdb.com/ -->\n')
        episodeguide_dict["imdb"] = getvit.getIMDBNumber()
    #Databse ID's IMDB, TMDB, TVDB, ANIDB + WIKIDATA, FACEBOOK, INSTAGRAM & X    
    if getvit.getUniqueID('imdb'):
        nfo_content_season.append('\t<uniqueid type="imdb" default="true">' + str(getvit.getUniqueID('imdb')) + '</uniqueid> <!-- https://www.imdb.com/ -->\n')
        episodeguide_dict["imdb"] = getvit.getUniqueID('imdb')       
    if getvit.getUniqueID('tmdb'):
        nfo_content_season.append('\t<uniqueid default="false" type="tmdb">' + str(getvit.getUniqueID('tmdb')) + '</uniqueid> <!-- https://www.themoviedb.com/ -->\n')
        episodeguide_dict["tmdb"] = getvit.getUniqueID('tmdb') 
    if getvit.getUniqueID('tvdb'):
        nfo_content_season.append('\t<uniqueid default="false" type="tvdb">' + str(getvit.getUniqueID('tvdb')) + '</uniqueid> <!-- https://www.thetvdb.com/ -->\n')
        episodeguide_dict["tvdb"] = getvit.getUniqueID('tvdb') 
    if getvit.getUniqueID('anidb'):
        nfo_content_season.append('\t<uniqueid default="false" type="anidb">' + str(getvit.getUniqueID('anidb')) + '</uniqueid> <!-- https://anidb.net/ -->\n')
        episodeguide_dict["anidb"] = getvit.getUniqueID('anidb') 
    nfo_content_season.append('\t<uniqueid default="false" type="tvrage"></uniqueid> <!-- https://www.tvrage.com/ -->\n')
    nfo_content_season.append('\t<uniqueid default="false" type="tvmaze"></uniqueid> <!-- https://www.tvmaze.com/ -->\n')
    nfo_content_season.append('\t<uniqueid default="false" type="zap2it"></uniqueid> <!-- https://tvschedule.zap2it.com/ -->\n')                
    nfo_content_season.append('\t<uniqueid default="false" type="tsdb"></uniqueid> <!-- https://www.thesportsdb.com/ --> \n')    
    nfo_content_season.append('\t<uniqueid default="false" type="wikidata"></uniqueid> <!-- https://www.wikidata.org/ -->\n')
    nfo_content_season.append('\t<uniqueid default="false" type="facebook"></uniqueid> <!-- https://www.facebook.com/ -->\n')
    nfo_content_season.append('\t<uniqueid default="false" type="instagram"></uniqueid> <!-- https://www.instagram.com/ -->\n')
    nfo_content_season.append('\t<uniqueid default="false" type="x"></uniqueid> <!-- https://x.com/ -->\n')
    #Episodeguide New
    json_episodeguide = json.dumps(episodeguide_dict)
    nfo_content_season.append('\t<episodeguide>' + json_episodeguide + '</episodeguide>\n')
    #User Ratings
    if getvit.getUserRating():
        nfo_content_season.append('\t<userrating>' + str(getvit.getUserRating()) + '</userrating>\n')
    nfo_content_season.append('\t<top250></top250>\n')
    #Plot and Tags
    if getvit.getPlotOutline():
        nfo_content_season.append('\t<outline>' + getvit.getPlotOutline() + '</outline>\n')
    if getvit.getPlot():
        nfo_content_season.append('\t<plot>' + getvit.getPlot() + '</plot>\n')
    if getvit.getTagLine():
        nfo_content_season.append('\t<tagline>' + getvit.getTagLine() + '</tagline>\n')
    if getvit.getDuration():    
        nfo_content_season.append('\t<runtime>' + str(getvit.getDuration()) + '</runtime>\n')  

    #nfo_content_season.append('\t<thumb spoof="" cache="" aspect="poster" preview="">https://image.tmdb.org/t/p/original/nEVjOpekbcdBqAexiWu7zXuFlYU.jpg</thumb>\n')
    #nfo_content_season.append('\t<thumb spoof="" cache="" aspect="landscape" preview="">https://image.tmdb.org/t/p/original/iBXBqas9DMzesltQEBNM6BH3akt.jpg</thumb>\n')
    #nfo_content_season.append('\t<thumb spoof="" cache="" aspect="set.poster" preview="">https://image.tmdb.org/t/p/original/xMsRZIkUGUuHsNHCQBDyZH7l53M.jpg</thumb>\n')
    #nfo_content_season.append('\t<thumb spoof="" cache="" aspect="set.landscape" preview="">https://image.tmdb.org/t/p/original/mkusMBRJyXJCcJ5RKlrKK2SC0Qv.jpg</thumb>\n')
    #nfo_content_season.append('\t<thumb spoof="" cache="" aspect="set.fanart" preview="">https://image.tmdb.org/t/p/original/3Odw3MJymLLbFuOnmQjmvndKhOr.jpg</thumb>\n')
    #nfo_content_season.append('\t<thumb spoof="" cache="" aspect="clearlogo" preview="">https://assets.fanart.tv/fanart/movies/476669/hdmovielogo/the-kings-man-601651c77c528.png</thumb>\n')
    #nfo_content_season.append('\t<thumb spoof="" cache="" aspect="discart" preview="">https://assets.fanart.tv/fanart/movies/476669/moviedisc/the-kings-man-617786bba9b7f.png</thumb>\n')
    #nfo_content_season.append('\t<thumb spoof="" cache="" aspect="clearart" preview="">https://assets.fanart.tv/fanart/movies/476669/hdmovieclearart/the-kings-man-61c1bf1b46f3b.png</thumb>\n')
    #nfo_content_season.append('\t<thumb spoof="" cache="" aspect="keyart" preview="">https://assets.fanart.tv/fanart/movies/476669/movieposter/the-kings-man-5f468bd247c3b.jpg</thumb>\n')
    #nfo_content_season.append('\t<thumb spoof="" cache="" aspect="banner" preview="">https://assets.fanart.tv/fanart/movies/476669/moviebanner/the-kings-man-5e86bd6f81322.jpg</thumb>\n')
    #nfo_content_season.append('\t<thumb spoof="" cache="" aspect="set.clearlogo" preview="">https://assets.fanart.tv/fanart/movies/391860/hdmovielogo/kingsman-collection-5a69d2e6eaa21.png</thumb>\n')
    #nfo_content_season.append('\t<thumb spoof="" cache="" aspect="set.keyart" preview="">https://assets.fanart.tv/fanart/movies/391860/movieposter/kingsman-collection-5add0aa47e577.jpg</thumb>\n')
    #nfo_content_season.append('\t<thumb spoof="" cache="" aspect="set.banner" preview="">https://assets.fanart.tv/fanart/movies/391860/moviebanner/kingsman-collection-5a691aee3c1e1.jpg</thumb>\n')
    #nfo_content_season.append('\t<fanart>\n')
    #nfo_content_season.append('\t\t<thumb colors="" preview="https://image.tmdb.org/t/p/w780/A49NScAT4ZcgeC6HeSvkUPVNJaF.jpg">https://image.tmdb.org/t/p/original/A49NScAT4ZcgeC6HeSvkUPVNJaF.jpg</thumb>\n')
    #nfo_content_season.append('\t</fanart>\n')

    #Genres
    if getvit.getGenres(): 
        for x_genre in getvit.getGenres():
            nfo_content_season.append('\t<genre>' + x_genre + '</genre>\n')
    #Director,Premiered,Year,First Aired,Trailer..
    if getvit.getWritingCredits():
        nfo_content_season.append('\t<credits>' + getvit.getWritingCredits() + '</credits>\n')
    if getvit.getDirector():
        nfo_content_season.append('\t<director>' + getvit.getDirector() + '</director>\n')
    if getvit.getPremieredAsW3C():
        nfo_content_season.append('\t<premiered>' + getvit.getPremieredAsW3C() + '</premiered>\n')
    if getvit.getYear():
        nfo_content_season.append('\t<year>' + str(getvit.getYear()) + '</year>\n')
    if getvit.getFirstAiredAsW3C():
        nfo_content_season.append('\t<aired>' + getvit.getFirstAiredAsW3C() + '</aired>\n')
    if getvit.getTrailer():
        nfo_content_season.append('\t<trailer>' + getvit.getTrailer() + '</trailer>\n')
    #Writer - unknown tag..
    if getvit.getWriters(): 
        for x_writer in getvit.getWriters():
            nfo_content_season.append('\t<writer>' + x_writer + '</writer\n')
    #Ende Season
    nfo_content_season.append('</season>\n')
    return nfo_content_season


# Function: NFO Content EPISODE => https://kodi.wiki/view/NFO_files/Templates
def create_nfo_content_episode():
    log_debug('DEV: ---- Running function: create_nfo_content_episode')
    #Episodeguide New: dictionaries
    episodeguide_dict = dict()

    getvit = sys.listitem.getVideoInfoTag()

    #Titel holen
    payload = {'jsonrpc': '2.0', 'method': "Files.GetDirectory", 'params': {"properties": ['showtitle','title', 'season', 'episode', 'file'],"directory": playpath, "media": "video"}, 'id': 1}
    info = json.loads(xbmc.executeJSONRPC(json.dumps(payload)))
    info = info["result"]
    showtitle=info['files'][0]['showtitle']

    #Anfang Episoden
    nfo_content_episode = ['<episodedetails>\n']
    #Titel - hier der Name der Episode
    if getvit.getTitle():
        nfo_content_episode.append('\t<title>' + str(getvit.getTitle()) + '</title>\n')
    #Season
    if getvit.getSeason():
        nfo_content_episode.append('\t<season>' + str(getvit.getSeason()) + '</season>\n')
    #Episode
    if getvit.getEpisode():
        nfo_content_episode.append('\t<episode>' + str(getvit.getEpisode()) + '</episode>\n')        
    #Show Title
    nfo_content_episode.append('\t<showtitle>' + showtitle + '</showtitle>\n')     
    #Original Tile - korrekt oder Episoden Titel?
    if getvit.getOriginalTitle():    
        nfo_content_episode.append('\t<originaltitle>' + showtitle + '</originaltitle>\n') 

    #Databse Kodi ID from Movie    
    if getvit.getDbId():
        nfo_content_episode.append('\t<id>' + str(getvit.getDbId()) + '</id>\n')
    #Database IMDBNumber
    if getvit.getIMDBNumber():
        nfo_content_episode.append('\t<imdb>' + str(getvit.getIMDBNumber()) + '</imdb> <!-- https://www.imdb.com/ -->\n')
        episodeguide_dict["imdb"] = getvit.getIMDBNumber()
    #Databse ID's IMDB, TMDB, TVDB, ANIDB + WIKIDATA, FACEBOOK, INSTAGRAM & X    
    if getvit.getUniqueID('imdb'):
        nfo_content_episode.append('\t<uniqueid type="imdb" default="true">' + str(getvit.getUniqueID('imdb')) + '</uniqueid> <!-- https://www.imdb.com/ -->\n')
        episodeguide_dict["imdb"] = getvit.getUniqueID('imdb')       
    if getvit.getUniqueID('tmdb'):
        nfo_content_episode.append('\t<uniqueid default="false" type="tmdb">' + str(getvit.getUniqueID('tmdb')) + '</uniqueid> <!-- https://www.themoviedb.com/ -->\n')
        episodeguide_dict["tmdb"] = getvit.getUniqueID('tmdb') 
    if getvit.getUniqueID('tvdb'):
        nfo_content_episode.append('\t<uniqueid default="false" type="tvdb">' + str(getvit.getUniqueID('tvdb')) + '</uniqueid> <!-- https://www.thetvdb.com/ -->\n')
        episodeguide_dict["tvdb"] = getvit.getUniqueID('tvdb') 
    if getvit.getUniqueID('anidb'):
        nfo_content_episode.append('\t<uniqueid default="false" type="anidb">' + str(getvit.getUniqueID('anidb')) + '</uniqueid> <!-- https://anidb.net/ -->\n')
        episodeguide_dict["anidb"] = getvit.getUniqueID('anidb') 
    nfo_content_episode.append('\t<uniqueid default="false" type="tvrage"></uniqueid> <!-- https://www.tvrage.com/ -->\n')
    nfo_content_episode.append('\t<uniqueid default="false" type="tvmaze"></uniqueid> <!-- https://www.tvmaze.com/ -->\n')
    nfo_content_episode.append('\t<uniqueid default="false" type="zap2it"></uniqueid> <!-- https://tvschedule.zap2it.com/ -->\n')                
    nfo_content_episode.append('\t<uniqueid default="false" type="tsdb"></uniqueid> <!-- https://www.thesportsdb.com/ --> \n')    
    nfo_content_episode.append('\t<uniqueid default="false" type="wikidata"></uniqueid> <!-- https://www.wikidata.org/ -->\n')
    nfo_content_episode.append('\t<uniqueid default="false" type="facebook"></uniqueid> <!-- https://www.facebook.com/ -->\n')
    nfo_content_episode.append('\t<uniqueid default="false" type="instagram"></uniqueid> <!-- https://www.instagram.com/ -->\n')
    nfo_content_episode.append('\t<uniqueid default="false" type="x"></uniqueid> <!-- https://x.com/ -->\n')
    #Episodeguide New
    json_episodeguide = json.dumps(episodeguide_dict)
    nfo_content_episode.append('\t<episodeguide>' + json_episodeguide + '</episodeguide>\n')
    #User Ratings
    if getvit.getUserRating():
        nfo_content_episode.append('\t<userrating>' + str(getvit.getUserRating()) + '</userrating>\n')
    nfo_content_episode.append('\t<top250></top250>\n')
    #Plot and Tags
    if getvit.getPlotOutline():
        nfo_content_episode.append('\t<outline>' + getvit.getPlotOutline() + '</outline>\n')
    if getvit.getPlot():
        nfo_content_episode.append('\t<plot>' + getvit.getPlot() + '</plot>\n')
    if getvit.getTagLine():
        nfo_content_episode.append('\t<tagline>' + getvit.getTagLine() + '</tagline>\n')
    if getvit.getDuration():    
        nfo_content_episode.append('\t<runtime>' + str(getvit.getDuration()) + '</runtime>\n')  
    #Genres
    if getvit.getGenres(): 
        for x_genre in getvit.getGenres():
            nfo_content_episode.append('\t<genre>' + x_genre + '</genre>\n')
    #Director,Premiered,Year,First Aired,Trailer..
    if getvit.getWritingCredits():
        nfo_content_episode.append('\t<credits>' + getvit.getWritingCredits() + '</credits>\n')
    if getvit.getDirector():
        nfo_content_episode.append('\t<director>' + getvit.getDirector() + '</director>\n')
    if getvit.getPremieredAsW3C():
        nfo_content_episode.append('\t<premiered>' + getvit.getPremieredAsW3C() + '</premiered>\n')
    if getvit.getYear():
        nfo_content_episode.append('\t<year>' + str(getvit.getYear()) + '</year>\n')
    if getvit.getFirstAiredAsW3C():
        nfo_content_episode.append('\t<aired>' + getvit.getFirstAiredAsW3C() + '</aired>\n')
    if getvit.getTrailer():
        nfo_content_episode.append('\t<trailer>' + getvit.getTrailer() + '</trailer>\n')
    #Writer - unknown tag..
    if getvit.getWriters(): 
        for x_writer in getvit.getWriters():
            nfo_content_episode.append('\t<writer>' + x_writer + '</writer\n')

    #Datei Informationen
    #nfo_content_episode.append('\t<fileinfo>\n')
    #nfo_content_episode.append('\t\t<streamdetails>\n')
    #nfo_content_episode.append('\t\t\t<video>\n')
    #nfo_content_episode.append('\t\t\t\t<codec>h264</codec>\n')
    #nfo_content_episode.append('\t\t\t\t<aspect>1.777778</aspect>\n')
    #nfo_content_episode.append('\t\t\t\t<width>1920</width>\n')
    #nfo_content_episode.append('\t\t\t\t<height>1080</height>\n')
    #nfo_content_episode.append('\t\t\t\t<durationinseconds>7838</durationinseconds>\n')
    #nfo_content_episode.append('\t\t\t\t<stereomode></stereomode>\n')
    #nfo_content_episode.append('\t\t\t\t<hdrtype></hdrtype>\n')
    #nfo_content_episode.append('\t\t\t</video>\n')
    #nfo_content_episode.append('\t\t\t<audio>\n')
    #nfo_content_episode.append('\t\t\t\t<codec>dtshd_ma</codec>\n')
    #nfo_content_episode.append('\t\t\t\t<language>eng</language>\n')
    #nfo_content_episode.append('\t\t\t\t<channels>8</channels>\n')
    #nfo_content_episode.append('\t\t\t</audio>\n')
    #nfo_content_episode.append('\t\t\t<subtitle>\n')
    #nfo_content_episode.append('\t\t\t\t<language>eng</language>\n')
    #nfo_content_episode.append('\t\t\t</subtitle>\n')
    #nfo_content_episode.append('\t\t</streamdetails>\n')
    #nfo_content_episode.append('\t</fileinfo>\n')

    #Actors
    #nfo_content_tvshow.append('\t<actor>\n')
    #nfo_content_tvshow.append('\t\t<name></name>\n')
    #nfo_content_tvshow.append('\t\t<role></role>\n')
    #nfo_content_tvshow.append('\t\t<order></order>\n')
    #nfo_content_tvshow.append('\t\t<thumb>https://image.tmdb.org/t/p/original/tJr9GcmGNHhLVVEH3i7QYbj6hBi.jpg</thumb>\n')
    #nfo_content_tvshow.append('\t</actor>\n')

    #Cast?

    #Filename
    original_filename = getvit.getFilenameAndPath().replace(getvit.getPath(), '')
    nfo_content_episode.append('<original_filename>' + original_filename + '</original_filename>\n')
    #Ende Episoden
    nfo_content_episode.append('</episodedetails>\n')
    return nfo_content_episode



### SCRIPT START ####

if __name__ == '__main__':
    log_debug('DEV: ---- Start MAIN')
    if len(sys.argv)>1:
        if sys.argv[1]=="update":
            log_debug('DEV: ---- Auswahl LIBRARY UPDATE')
            # Update der Video Library
            notification('NFO Exporter', 'Update Library', time4000)
            #xbmcgui.Dialog().notification("ExportTo", "Updating Library...")
            xbmc.executebuiltin("UpdateLibrary(video)")
    else:
        try:
            getvit = sys.listitem.getVideoInfoTag()
            log_debug('DEV: ---- + getvit: ' + getvit)            
        except:
            notification('NFO Exporter', 'Error to get: getVideoInfoTag', time4000)    
            log_debug('DEV: ---- + error get :  getVideoInfoTag')
        try:
            getvitgetFilenameAndPath = sys.listitem.getVideoInfoTag().getFilenameAndPath()
            log_debug('DEV: ---- + getvitgetFilenameAndPath: ' + getvitgetFilenameAndPath)
        except:
            notification('NFO Exporter', 'Error to get: VideoTag', time4000)    
            log_debug('DEV: ---- + error get :  getvitgetFilenameAndPath')
        try:
            mediatype=sys.listitem.getVideoInfoTag().getMediaType() #types=video,set,musicvideo,movie,tvshow,season,episode
            log_debug('DEV: ---- + mediatype: ' + mediatype) 
        except:
            notification('NFO Exporter', 'Error to get: getMediaType', time4000)    
            log_debug('DEV: ---- + error get :  getMediaType')
        try:
            playpath=sys.listitem.getPath()
            log_debug('DEV: ---- + playpath: ' + playpath) 
        except:
            notification('NFO Exporter', 'Error to get: getPath', time4000)    
            log_debug('DEV: ---- + error get :  getPath')
            
        log_debug('DEV: ---- Auswahl NICHT LIBRARY UPDATE SONDERN...') 
        # Auswahl Movie       
        if mediatype=="movie":
            log_debug('DEV: ---- Auswahl MOVIE')

            #Information aus Kodi Datenbank entnehmen oder von Scraper, general_setting11 = true
            # Start - Daten aus Kodi entnehmen [MOVIE]
            if self.getSettingBool('general_setting11'):
                log_debug('DEV: ---- Start - MOVIE Daten aus Kodi entnehmen')


                #Ausgabe im Film Ordner
                # Wenn Ausgabe im Film Ordner oder eigener Pfad, general_setting21 = true
                if self.getSettingBool('general_setting21'):
                    log_debug('DEV: ---- Auswahl: NFO im Film Ordner speichern')
                    log_debug('DEV: ---- general_setting23: ' + self.getSettingString('general_setting23'))
                    #Dateiname = general_setting23 // 1:(moviefilename).nfo // 2:movie.nfo - default 1
                    if self.getSettingString('general_setting23') == '1':
                        log_debug('DEV: ---- Auswahl Film Pfad: (moviefilename).nfo')
                        # Dateiname und  Pfad ändern für NFO [filmtitel.nfo]
                        
#                        #filepathmovie  = getvit.getFilenameAndPath()
                        filepathmovie  = getvitgetFilenameAndPath
                        log_debug('DEV: ---- filepathmovie: ' + str(filepathmovie))
                        filepathmoviewext = os.path.splitext(filepathmovie)
                        log_debug('DEV: ---- filepathmoviewext: ' + filepathmoviewext[0])
                        nfofilenamemovie = filepathmoviewext[0] + '.nfo'
                        log_debug('DEV: ---- nfofilenamemovie: ' + nfofilenamemovie)

                        # NFO SCHREIBEN
                        #nfofilenamemovie_content = 'das ist ein Test\n'
                        write_nfo_file_msg(nfofilenamemovie, create_nfo_content_movie())
                    #Dateiname = general_setting23 // 1:(moviefilename).nfo // 2:movie.nfo - default 1
                    elif self.getSettingString('general_setting23') == '2':
                        log_debug('DEV: ---- Auswahl Film Pfad: movie.nfo')
                        filepathmovie = sys.listitem.getVideoInfoTag().getPath()
                        selection_dir = os.path.join(filepathmovie)
                        log_debug('DEV: ---- selection_dir: ' + str(selection_dir))
                        nfofilenamemovie = selection_dir + 'movie.nfo'
                        log_debug('DEV: ---- nfofilenamemovie: ' + nfofilenamemovie)
                        # NFO SCHREIBEN
                        #nfofilenamemovie_content = 'das ist ein Test 2\n'
                        write_nfo_file_msg(nfofilenamemovie, create_nfo_content_movie())

                # Wenn Ausgabe im Film Ordner oder eigener Pfad, general_setting21 = false                   
                else:
                    log_debug('DEV: ---- Auswahl: NFO in eigenen Ordner speichern')    

                    #Dateiname = general_setting23 // 1:(moviefilename).nfo // 2:movie.nfo - default 1
                    if self.getSettingString('general_setting23') == '1':
                        log_debug('DEV: ---- Auswahl eigener Pfad + : (moviefilename).nfo')

                        ##Eingegebener Pfad
                        nfofilenamemovie = self.getSettingString('general_setting22') 
                        log_debug('DEV: ---- Auswahl eigener Pfad:' + nfofilenamemovie)

                        ##Eingegebener Pfad + Dateiname   
#                        # or_getFilenameAndPath  = getvit.getFilenameAndPath()   
                        or_getFilenameAndPath  = getvitgetFilenameAndPath                        
                        #or_getFilenameAndPath  = getvideoinfotag.getFilenameAndPath()  
                        or_getPath = sys.listitem.getVideoInfoTag().getPath()
                        new_nfofilenamemoviefile = (or_getFilenameAndPath.replace(or_getPath, ''))
                        nfofilenamemovie = nfofilenamemovie + new_nfofilenamemoviefile
                        hel_nfofilenamemovie = os.path.splitext(nfofilenamemovie)
                        log_debug('DEV: ---- filepathmoviewext: ' + hel_nfofilenamemovie[0])
                        nfofilenamemovie = hel_nfofilenamemovie[0] + '.nfo'
                        log_debug('DEV: ---- nfofilenamemovie: ' + nfofilenamemovie)
                        log_debug('DEV: ---- Auswahl eigener Pfad + File :' + nfofilenamemovie)

                        # NFO SCHREIBEN
                        #nfofilenamemovie_content = 'das ist ein Test 2\n'
                        write_nfo_file_msg(nfofilenamemovie, create_nfo_content_movie())                        

                    #Dateiname = general_setting23 // 1:(moviefilename).nfo // 2:movie.nfo - default 1
                    elif self.getSettingString('general_setting23') == '2':
                        log_debug('DEV: ---- Auswahl eigener Pfad +: movie.nfo')                    

                        ##Eingegebener Pfad
                        nfofilenamemovie = self.getSettingString('general_setting22') 
                        log_debug('DEV: ---- Auswahl eigener Pfad:' + nfofilenamemovie)  
                        ##Eingegebener Pfad + Dateiname
                        nfofilenamemovie = nfofilenamemovie + 'movie.nfo'                             

                        # NFO SCHREIBEN
                        #nfofilenamemovie_content = 'das ist ein Test 2\n'
                        write_nfo_file_msg(nfofilenamemovie, create_nfo_content_movie())

   
            #Information aus Kodi Datenbank entnehmen oder von Scraper, general_setting11 = true
            # Start - Daten von Scraper entnehmen [MOVIE]
            else:
                log_debug('DEV: ---- Start - MOVIE Daten von Scraper entnehmen')
                log_debug('DEV: ---- Verwendung später geplant!')  





        # Auswahl TV SHOW
        if mediatype=="tvshow":
            log_debug('DEV: ---- Auswahl TVSHOW')

            #Information aus Kodi Datenbank entnehmen oder von Scraper, general_setting13 = true
            # Start - Daten aus Kodi entnehmen [TVSHOW]
            if self.getSettingBool('general_setting13'):
                log_debug('DEV: ---- Start - TVSHOW Daten aus Kodi entnehmen')

                #Ausgabe im Serien Ordner
                # Wenn Ausgabe im Serien Ordner oder eigener Pfad, general_setting31 = true
                if self.getSettingBool('general_setting31'):
                    log_debug('DEV: ---- Auswahl: NFO im Serien Ordner speichern')

                    #Dateiname = general_setting35 // (tvshowtitle).nfo // tvshow.nfo default 2
                    if self.getSettingString('general_setting35') == '1':
                        log_debug('DEV: ---- Auswahl NFO im Serien Ordner + : (tvshowtitle).nfo')

                        # Dateiname und  Pfad ändern für NFO [(tvshowtitle).nfo]
                        filepathtvshow = sys.listitem.getVideoInfoTag().getPath()
                        filepathtvshow = os.path.join(filepathtvshow)
                        log_debug('DEV: ---- filepathtvshow: ' + str(filepathtvshow))
                        filepathtvshowwext = sys.listitem.getVideoInfoTag()
                        nfofilenametvshow = filepathtvshowwext.getTitle()  
                        log_debug('DEV: ---- title: ' + str(nfofilenametvshow))
                        nfofilenametvshow = nfofilenametvshow + '.nfo'
                        log_debug('DEV: ---- nfofilenametvshow: ' + nfofilenametvshow)
                        nfofilenametvshow = filepathtvshow + nfofilenametvshow
                        log_debug('DEV: ---- nfofilenametvshow: ' + nfofilenametvshow)

                        # NFO SCHREIBEN
                        #nfofilenametvshow_content = 'das ist ein Test\n'
                        write_nfo_file_msg(nfofilenametvshow, create_nfo_content_tvshow())

                        #Dateiname = general_setting35 // (tvshowtitle).nfo // tvshow.nfo default 2
                    elif self.getSettingString('general_setting35') == '2':
                        log_debug('DEV: ---- Auswahl NFO im Serien Ordner +: tvshow.nfo')   

                        # Dateiname und  Pfad ändern für NFO [tvshow.nfo]
                        filepathtvshow = sys.listitem.getVideoInfoTag().getPath()
                        filepathtvshow = os.path.join(filepathtvshow)
                        log_debug('DEV: ---- filepathtvshow: ' + str(filepathtvshow))
                        nfofilenametvshow = 'tvshow.nfo'
                        log_debug('DEV: ---- nfofilenametvshow: ' + nfofilenametvshow)
                        nfofilenametvshow = filepathtvshow + nfofilenametvshow
                        log_debug('DEV: ---- nfofilenametvshow: ' + nfofilenametvshow)

                        # NFO SCHREIBEN
                        #nfofilenametvshow_content = 'das ist ein Test\n'
                        write_nfo_file_msg(nfofilenametvshow, create_nfo_content_tvshow())


                # Wenn Ausgabe im Serien Ordner oder eigener Pfad, general_setting31 = false                   
                else:
                    log_debug('DEV: ---- Auswahl: NFO in eigenen Ordner speichern')   

                    #Dateiname = general_setting35 // (tvshowtitle).nfo // tvshow.nfo default 2
                    if self.getSettingString('general_setting35') == '1':
                        log_debug('DEV: ---- Auswahl eigener Pfad + : (tvshowtitle).nfo')

                        ##Eingegebener Pfad
                        nfofilenametvshowp = self.getSettingString('general_setting32') 
                        log_debug('DEV: ---- Auswahl eigener Pfad:' + nfofilenametvshowp)

                        ##Eingegebener Pfad + Dateiname
                        filepathtvshowwext = sys.listitem.getVideoInfoTag()
                        nfofilenametvshow = filepathtvshowwext.getTitle()  
                        log_debug('DEV: ---- title: ' + str(nfofilenametvshow))
                        nfofilenametvshow = nfofilenametvshow + '.nfo'     
                        nfofilenametvshow = nfofilenametvshowp + nfofilenametvshow
                        log_debug('DEV: ----nfofilenametvshow:' + nfofilenametvshow)

                        # NFO SCHREIBEN
                        #nfofilenametvshow_content = 'das ist ein Test\n'
                        write_nfo_file_msg(nfofilenametvshow, create_nfo_content_tvshow())


                        #Dateiname = general_setting35 // (tvshowtitle).nfo // tvshow.nfo default 2
                    elif self.getSettingString('general_setting35') == '2':
                        log_debug('DEV: ---- Auswahl eigener Pfad +: tvshow.nfo') 

                        ##Eingegebener Pfad
                        nfofilenametvshow = self.getSettingString('general_setting32') 
                        log_debug('DEV: ---- Auswahl eigener Pfad:' + nfofilenametvshow)
                        ##Eingegebener Pfad + Dateiname
                        nfofilenametvshow = nfofilenametvshow + 'tvshow.nfo'     

                         # NFO SCHREIBEN
                        #nfofilenametvshow_content = 'das ist ein Test\n'
                        write_nfo_file_msg(nfofilenametvshow, create_nfo_content_tvshow())                        



            #Information aus Kodi Datenbank entnehmen oder von Scraper, general_setting13 = true
            # Start - Daten von Scraper entnehmen [TVSHOW]
            else:
                log_debug('DEV: ---- Start - TVSHOW Daten von Scraper entnehmen')
                log_debug('DEV: ---- Verwendung später geplant!')  





        # Auswahl SEASON
        if mediatype=="season":
            log_debug('DEV: ---- Auswahl SEASON')    
            playpath=sys.listitem.getPath()

            #Information aus Kodi Datenbank entnehmen oder von Scraper, general_setting13 = true
            # Start - Daten aus Kodi entnehmen [TVSHOW-SEASON]
            if self.getSettingBool('general_setting13'):
                log_debug('DEV: ---- Start - TVSHOW-SEASON Daten aus Kodi entnehmen')

                #Ausgabe im Serien Ordner
                # Wenn Ausgabe im Serien Ordner oder eigener Pfad, general_setting31 = true
                if self.getSettingBool('general_setting31'):
                    log_debug('DEV: ---- Auswahl: Season NFO im Serien Ordner speichern')

                    #Dateiname = general_setting36 // seasonXX.nfo - Folder TVShow | season.nfo - Folder TVShow/Season X,  default 2
                    if self.getSettingString('general_setting36') == '1':
                        log_debug('DEV: ---- Auswahl NFO im Serien Ordner + : seasonXX.nfo')

                        # Dateiname und  Pfad ändern für NFO [seasonXX.nfo]
                        filepathtvshowseas = sys.listitem.getVideoInfoTag().getPath()
                        filepathtvshowseas = os.path.join(filepathtvshowseas)
                        log_debug('DEV: ---- filepathtvshowseas: ' + str(filepathtvshowseas))
                        #Season Number
                        tvshowseasnumb = sys.listitem.getVideoInfoTag().getSeason()
                        log_debug('DEV: ---- tvshowseasnumb: ' + str(tvshowseasnumb))
                        nfofilenametvshowseas = 'season' + str(tvshowseasnumb) + '.nfo'
                        log_debug('DEV: ---- title: ' + str(nfofilenametvshowseas))
                        nfofilenametvshowseas = filepathtvshowseas + nfofilenametvshowseas
                        log_debug('DEV: ---- nfofilenametvshowseas: ' + nfofilenametvshowseas)

                        # NFO SCHREIBEN
                        #nfofilenametvshowseas_content = 'das ist ein Test\n'
                        write_nfo_file_msg(nfofilenametvshowseas, create_nfo_content_season())                         

                    #Dateiname = general_setting36 // seasonXX.nfo - Folder TVShow | season.nfo - Folder TVShow/Season X,  default 2
                    elif self.getSettingString('general_setting36') == '2':
                        log_debug('DEV: ---- Auswahl NFO im Serien Ordner +: /Season X/season.nfo')    
                        #Datei
                        payload = {'jsonrpc': '2.0', 'method': "Files.GetDirectory", 'params': {"properties": ['showtitle','title', 'season', 'episode', 'file'],"directory": playpath, "media": "video"}, 'id': 1}
                        info = json.loads(xbmc.executeJSONRPC(json.dumps(payload)))
                        info = info["result"]
                        tvshowtitlefile=info['files'][0]['file']
                        log_debug('DEV: ---- tvshowtitlefile: ' + str(tvshowtitlefile))
                        #Pfad
                        tvshowtitlefile_path = sys.listitem.getVideoInfoTag().getPath()
                        tvshowtitlefile_path = os.path.join(tvshowtitlefile_path)
                        log_debug('DEV: ---- tvshowtitlefile_path: ' + str(tvshowtitlefile_path))
                        #Season Folder OS
                        tvshowseas_hel = tvshowtitlefile.replace(tvshowtitlefile_path, '')
                        log_debug('DEV: ---- tvshowseas_hel: ' + str(tvshowseas_hel))
                        tvshowseas_hel = r'' + tvshowseas_hel
                        tvshowseas_hel = re.split(r'\\|/', tvshowseas_hel)
                        log_debug('DEV: ---- tvshowseas_hel[0]: ' + str(tvshowseas_hel[0]))
                        # Pfad ändern für NFO [seasonXX.nfo]
                        filepathtvshowseas = sys.listitem.getVideoInfoTag().getPath()
                        filepathtvshowseas = os.path.join(filepathtvshowseas)
                        log_debug('DEV: ---- filepathtvshowseas: ' + str(filepathtvshowseas))
                        #Pfad mit Dateinamen OS konform 
                        nfofilenametvshowseas = filepathtvshowseas + tvshowseas_hel[0]
                        nfofilenametvshowseas = os.path.join(nfofilenametvshowseas, 'season.nfo')
                        log_debug('DEV: ---- nfofilenametvshowseas: ' + str(nfofilenametvshowseas))                        

                        # NFO SCHREIBEN
                        #nfofilenametvshowseas_content = 'das ist ein Test\n'
                        write_nfo_file_msg(nfofilenametvshowseas, create_nfo_content_season()) 


                # Wenn Ausgabe im Serien Ordner oder eigener Pfad, general_setting31 = false                   
                else:
                    log_debug('DEV: ---- Auswahl: Season NFO in eigenen Ordner speichern')   

                    #Dateiname = general_setting36 // seasonXX.nfo - Folder TVShow | season.nfo - Folder TVShow/Season X,  default 2
                    if self.getSettingString('general_setting36') == '1':
                        log_debug('DEV: ---- Auswahl eigener Pfad + : seasonXX.nfo')

                        ##Eingegebener Pfad
                        nfofilenametvshowp = self.getSettingString('general_setting33') 
                        log_debug('DEV: ---- Auswahl eigener Pfad:' + nfofilenametvshowp)
                        #Season Number
                        tvshowseasnumb = sys.listitem.getVideoInfoTag().getSeason()
                        log_debug('DEV: ---- tvshowseasnumb: ' + str(tvshowseasnumb))
                        nfofilenametvshowseas = 'season' + str(tvshowseasnumb) + '.nfo'
                        log_debug('DEV: ---- title: ' + str(nfofilenametvshowseas))
                        nfofilenametvshowseas = nfofilenametvshowp + nfofilenametvshowseas
                        log_debug('DEV: ---- nfofilenametvshowseas: ' + nfofilenametvshowseas)

                        # NFO SCHREIBEN
                        #nfofilenametvshowseas_content = 'das ist ein Test\n'
                        write_nfo_file_msg(nfofilenametvshowseas, create_nfo_content_season())                         

                    #Dateiname = general_setting36 // seasonXX.nfo - Folder TVShow | season.nfo - Folder TVShow/Season X,  default 2
                    elif self.getSettingString('general_setting36') == '2':
                        log_debug('DEV: ---- Auswahl eigener Pfad +: /Season X/season.nfo')      

                        ##Eingegebener Pfad
                        nfofilenametvshowp = self.getSettingString('general_setting33') 
                        log_debug('DEV: ---- Auswahl eigener Pfad:' + nfofilenametvshowp)

                        #Datei
                        payload = {'jsonrpc': '2.0', 'method': "Files.GetDirectory", 'params': {"properties": ['showtitle','title', 'season', 'episode', 'file'],"directory": playpath, "media": "video"}, 'id': 1}
                        info = json.loads(xbmc.executeJSONRPC(json.dumps(payload)))
                        info = info["result"]
                        tvshowtitlefile=info['files'][0]['file']
                        log_debug('DEV: ---- tvshowtitlefile: ' + str(tvshowtitlefile))
                        #Pfad
                        tvshowtitlefile_path = sys.listitem.getVideoInfoTag().getPath()
                        tvshowtitlefile_path = os.path.join(tvshowtitlefile_path)
                        log_debug('DEV: ---- tvshowtitlefile_path: ' + str(tvshowtitlefile_path))
                        #Season Folder OS
                        tvshowseas_hel = tvshowtitlefile.replace(tvshowtitlefile_path, '')
                        log_debug('DEV: ---- tvshowseas_hel: ' + str(tvshowseas_hel))
                        tvshowseas_hel = r'' + tvshowseas_hel
                        tvshowseas_hel = re.split(r'\\|/', tvshowseas_hel)
                        log_debug('DEV: ---- tvshowseas_hel[0]: ' + str(tvshowseas_hel[0]))

                        #Pfad mit Dateinamen
                        nfofilenametvshowseas = nfofilenametvshowp + tvshowseas_hel[0]
                        log_debug('DEV: ---- nfofilenametvshowseas: ' + str(nfofilenametvshowseas))  
                        if nfofilenametvshowseas.find("/") > 0:
                            log_debug('DEV: ---- Slash or Backslah: / ')
                            nfofilenametvshowseas = nfofilenametvshowseas + '/season.nfo'
                        elif nfofilenametvshowseas.find("\\") > 0:
                            log_debug('DEV: ---- Slash or Backslah: \ ')
                            nfofilenametvshowseas = nfofilenametvshowseas + '\season.nfo'    
                        log_debug('DEV: ---- nfofilenametvshowseas: ' + str(nfofilenametvshowseas))   

                        # NFO SCHREIBEN
                        #nfofilenametvshowseas_content = 'das ist ein Test\n'
                        write_nfo_file_msg(nfofilenametvshowseas, create_nfo_content_season())                         

            #Information aus Kodi Datenbank entnehmen oder von Scraper, general_setting13 = true
            # Start - Daten von Scraper entnehmen [TVSHOW-SEASON]
            else:
                log_debug('DEV: ---- Start - TVSHOW-SEASON Daten von Scraper entnehmen')
                log_debug('DEV: ---- Verwendung später geplant!')  


        # Auswahl EPISODE
        if mediatype=="episode":
            log_debug('DEV: ---- Auswahl EPISODE')   

            #Information aus Kodi Datenbank entnehmen oder von Scraper, general_setting13 = true
            # Start - Daten aus Kodi entnehmen [TVSHOW-SEASON-EPISODE]
            if self.getSettingBool('general_setting13'):
                log_debug('DEV: ---- Start - TVSHOW-SEASON-EPISODE Daten aus Kodi entnehmen')

                #Ausgabe im Serien Ordner
                # Wenn Ausgabe im Serien Ordner oder eigener Pfad, general_setting31 = true
                if self.getSettingBool('general_setting31'):
                    log_debug('DEV: ---- Auswahl: Season NFO im Serien/Staffel X/ Ordner speichern')

                    #Dateiname = general_setting37 // (episodefilename).nfo - Folder TVShow |  NICHT BENUTZT, default 1
                    if self.getSettingString('general_setting37') == '1':
                        log_debug('DEV: ---- Auswahl NFO im Serien/Staffel X/ Ordner + : (episodefilename).nfo')

                        # Datenbank getFilenameAndPath des Eintrags
                        getFilenameAndPath_epis = sys.listitem.getVideoInfoTag().getFilenameAndPath()              
                        log_debug('DEV: ---- getFilenameAndPath_epis: ' + str(getFilenameAndPath_epis))
                        #Cut FileTypeExtension
                        nfofilenametvshowseasepis = getFilenameAndPath_epis.rsplit('.', 1)
                        nfofilenametvshowseasepis = nfofilenametvshowseasepis[0] + '.nfo'

                        # NFO SCHREIBEN
                        #nfofilenametvshowseasepis_content = 'das ist ein Test\n'
                        write_nfo_file_msg(nfofilenametvshowseasepis, create_nfo_content_episode())                         

                    #Dateiname = general_setting37 //  (episodefilename).nfo - Folder TVShow |  NICHT BENUTZT, default 1
                    elif self.getSettingString('general_setting37') == '2':
                        log_debug('DEV: ---- Auswahl NFO im Serien/Staffel X/ Ordner +: NICHT BENUTZT')    
                        # NFO SCHREIBEN
                        nfofilenametvshowseasepis = 'PFAD NOTWENDIG'
                        #nfofilenametvshowseasepis_content = 'das ist ein Test\n'
                        #write_nfo_file_msg(nfofilenametvshowseasepis, create_nfo_content_episode())


                # Wenn Ausgabe im Serien Ordner oder eigener Pfad, general_setting31 = false                   
                else:
                    log_debug('DEV: ---- Auswahl: Season NFO in eigenen Ordner speichern')   

                    #Dateiname = general_setting37 //  (episodefilename).nfo - Folder TVShow |  NICHT BENUTZT, default 1
                    if self.getSettingString('general_setting37') == '1':
                        log_debug('DEV: ---- Auswahl eigener Pfad + : (episodefilename).nfo')

                        ##Eingegebener Pfad
                        nfofilenametvshowpe = self.getSettingString('general_setting34') 
                        log_debug('DEV: ---- Auswahl eigener Pfad:' + nfofilenametvshowpe)

                        #Nur Episoden Filename+ext
                        getFilenameAndPath_eps = sys.listitem.getVideoInfoTag().getFilenameAndPath()                         
                        getFilenameAndPath_epsoe = sys.listitem.getVideoInfoTag().getPath()
                        getFilenameAndPath_epis = (getFilenameAndPath_eps.replace(getFilenameAndPath_epsoe, ''))
                        log_debug('DEV: ---- getFilenameAndPath_epis:' + getFilenameAndPath_epis)

                        #Cut FileTypeExtension
                        nfofilenametvshowseasepis = getFilenameAndPath_epis.rsplit('.', 1)
                        nfofilenametvshowseasepis = nfofilenametvshowseasepis[0] + '.nfo'
                        log_debug('DEV: ---- nfofilenametvshowseasepis:' + nfofilenametvshowseasepis)

                        #FilePath
                        nfofilenametvshowseasepis = nfofilenametvshowpe + nfofilenametvshowseasepis
                        log_debug('DEV: ---- nfofilenametvshowseasepis:' + nfofilenametvshowseasepis)

                        # NFO SCHREIBEN
                        #nfofilenametvshowseasepis_content = 'das ist ein Test\n'
                        write_nfo_file_msg(nfofilenametvshowseasepis, create_nfo_content_episode())


                    #Dateiname = general_setting37 //  (episodefilename).nfo - Folder TVShow |  NICHT BENUTZT, default 1
                    elif self.getSettingString('general_setting37') == '2':
                        log_debug('DEV: ---- Auswahl eigener Pfad +: NICHT BENUTZT')   
                        # NFO SCHREIBEN
                        nfofilenametvshowseasepis = 'PFAD NOTWENDIG'
                        #nfofilenametvshowseasepis_content = 'das ist ein Test\n'
                        #write_nfo_file_msg(nfofilenametvshowseasepis, create_nfo_content_episode())                           



            #Information aus Kodi Datenbank entnehmen oder von Scraper, general_setting13 = true
            # Start - Daten von Scraper entnehmen [TVSHOW-SEASON-EPISODE]
            else:
                log_debug('DEV: ---- Start - TVSHOW-SEASON-EPISODE Daten von Scraper entnehmen')
                log_debug('DEV: ---- Verwendung später geplant!')  





"""
        log_debug('DEV: ---- ANFANG')
        for ep in info['files']:
            if ep['type']=="episode":
                #exportep(showtitle,ep['season'],ep['episode'],ep['label'],ep['file'])
                print(showtitle,ep['season'],ep['episode'],ep['label'],ep['file'])
        log_debug('DEV: ---- ENDE')

"""
"""

 

#######DEV A



#=> Daten von Film holen
 #'getActors', 'getAlbum', 'getArtist', 'getCast', 'getDbId', 'getDirector', 'getDirectors', 'getDuration', 'getEpisode', 
 #'getFile', 'getFilenameAndPath', 'getFirstAired', 'getFirstAiredAsW3C', 'getGenre', 'getGenres', 'getIMDBNumber', 'getLastPlayed', 
 # 'getLastPlayedAsW3C', 'getMediaType', 'getOriginalTitle', 'getPath', 'getPictureURL', 'getPlayCount', 'getPlot', 'getPlotOutline', 
 # 'getPremiered', 'getPremieredAsW3C', 'getRating', 'getResumeTime', 'getResumeTimeTotal', 'getSeason', 'getTVShowTitle', 'getTagLine', 
 # 'getTitle', 'getTrack', 'getTrailer', 'getUniqueID', 'getUserRating', 'getVotes', 'getVotesAsInt', 'getWriters', 'getWritingCredits', 'getYear'

# https://alwinesch.github.io/group__python__xbmcgui__listitem.html

    getvit = sys.listitem.getVideoInfoTag()

    getvit_test  = getvit.getDbId()    
    log_debug('DEV: ---- getvit_test: ' + str(getvit_test))


    uniqueID = getvit.getUniqueID('imdb')
    log_debug('DEV: ---- uniqueID: ' + str(uniqueID))

    getvit_testx = getvit.getGenre() 
    log_debug('DEV: ---- getvit_testx: ' + str(getvit_testx))

    getvit_testxx = getvit.getActors() 
    log_debug('DEV: ---- getvit_testxx: ' + str(getvit_testxx))

    getvit_testxxd = sys.listitem.getVideoInfoTag().getCast() 
    log_debug('DEV: ---- getvit_testxxd: ' + str(getvit_testxxd))


#if getvit.getPremieredAsW3C():
#if getvit.getVotesAsInt('tmdb'):



###########DEV E
"""

""" Episoden Loop
        # Test mehr
        playpath=sys.listitem.getPath()
        payload = {'jsonrpc': '2.0', 'method': "Files.GetDirectory", 'params': {"properties": ['showtitle','title', 'season', 'episode', 'file'],"directory": playpath, "media": "video"}, 'id': 1}
        info = json.loads(xbmc.executeJSONRPC(json.dumps(payload)))
        info = info["result"]
        for ep in info['files']:
            if ep['type']=="episode":
                #exportep(showtitle,ep['season'],ep['episode'],ep['label'],ep['file'])
                print(showtitle,ep['season'],ep['episode'],ep['label'],ep['file'])

"""

"""
 CStreamDetailVideo* VideoStreamDetail::ToStreamDetailVideo() const
    {
      auto streamDetail = new CStreamDetailVideo();
      streamDetail->m_iWidth = m_width;
      streamDetail->m_iHeight = m_height;
      streamDetail->m_fAspect = m_aspect;
      streamDetail->m_iDuration = m_duration;
      streamDetail->m_strCodec = m_codec;
      streamDetail->m_strStereoMode = m_stereoMode;
      streamDetail->m_strLanguage = m_language;
      streamDetail->m_strHdrType = m_hdrType;

      return streamDetail;
    }
"""

"""
############# SPÄTER LÖSCHEN ANFANG #############


#Settings abfragen anpassen - speicherort
moviepath=xbmcaddon.Addon().getSetting("general_setting22")
showpath=xbmcaddon.Addon().getSetting("general_setting32")

def cleanstr(instr):
    instr=instr.replace("&","and")
    return re.sub('[^ .0-9a-zA-Z]+', '', instr).replace(" ", ".")

def recursSea(playpath):
    
    payload = {'jsonrpc': '2.0', 'method': "Files.GetDirectory", 'params': {"properties": ['showtitle','title', 'season', 'episode', 'file'],"directory": playpath, "media": "video"}, 'id': 1}
    
    info = json.loads(xbmc.executeJSONRPC(json.dumps(payload)))
    info = info["result"]
    if not info['files'][0]:
        return
    
    showtitle=info['files'][0]['showtitle']
    log_debug('DEV: ---- showtitle: ' + str(showtitle)) 
    showtitle1=info['files'][0]['title']
    log_debug('DEV: ---- showtitle1: ' + str(showtitle1)) 
    showtitle2=info['files'][0]['season']
    log_debug('DEV: ---- showtitle2: ' + str(showtitle2)) 

    showtitle3=info['files'][0]['episode']
    log_debug('DEV: ---- showtitle3: ' + str(showtitle3)) 

    showtitle4=info['files'][0]['file']
    log_debug('DEV: ---- showtitle4: ' + str(showtitle4)) 

    for ep in info['files']:
        if ep['type']=="episode":
            exportep(showtitle,ep['season'],ep['episode'],ep['label'],ep['file'])
"""