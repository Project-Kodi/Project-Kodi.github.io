# -*- coding: UTF-8 -*-
#
# Copyright (C) 2024, Project Kodi
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# Code attribution:
# core based on metadata.tvshows.thesportsdb.python by pkscout
# and metadata.tvmaze scrapper by Roman Miroshnychenko aka Roman V.M.
# and the metadata.tvshows.themoviedb.org.python scraper by Team Kodi
# all created by improvements to metadata.thesportsdb.com 2015 from Project Kodi (peter0123)
#
# OPEN
# => https://kodi.wiki/view/Add-on:Embuary_Info / Wenn man mehr informationen über zb. Premier League anfordert, danach ein Team wählt und informationen holt, geht das Plugin nur zur MOVIE DB!
# Title "label" not title
# BEI NFO, die Sprach Einstellung beachten, aktuell nur EN?
# Cast Import von TSDB zu KODI, immer nur ein Actor/Cast??? NFO Verarbeitung passt, dort nur 1 Ergebnis da nur 1x in kodi?
# filter smb/nfs passwords from logging
# ##Expand extra Fanart  => data_utily.py sowie season
# addAvailableArtwork(   , at the end data_utilis.py
# pylint: disable=missing-docstring


"""Functions to interact with TSDb API"""

from __future__ import absolute_import, unicode_literals

import unicodedata
from math import floor
from pprint import pformat
from . import cache, api_utils, settings
from .utils import logger

try:
    from typing import (
        Text,
        Optional,
        Union,
        List,
        Dict,
        Any,
    )  # pylint: disable=unused-import

    InfoType = Dict[Text, Any]  # pylint: disable=invalid-name
except ImportError:
    pass

# Addon Settings - API Version/Verbose logging extreme
api_version = settings.APIVERSION
verboselog_adv = settings.VERBOSELOGADV
change_api_key = settings.CHANGEAPIKEY
# Check Settings - API Version:
logger.debug("API CALLS {}".format(settings.APIVERSION))


# Free Test API Key Url - Fallback (Integration...)
base_url_free_api = "https://www.thesportsdb.com/api/v2/json/3/{}"

# API Key Change - Addon Settings
if change_api_key == "Only if available" or change_api_key == "":
    change_api_key = 9863529876235


# API V1                  | API V2         | - used from Scraper             | - Possible API V1
# all_leagues.php         | all/leagues/   | {}                              | all_leagues.php
# search_all_seasons.php  | list/seasons/  | {'id': '4372'}                  | search_all_seasons.php?id=4328
# eventsseason.php        | filter/events/ | {'id': '4328', 's': '1992-1993'}| eventsseason.php?id=4328&s=2014-2015
# search_all_teams.php    | list/teams/    | {'l': 'English Premier League'} | search_all_teams.php?l=English%20Premier%20League | search_all_teams.php?s=Soccer&c=Spain
# lookupleague.php        | lookup/league/ | {'id': '4328'}                  | lookupleague.php?id=4346
# lookupevent.php         | lookup/event/  | {'id': '448758'}                | lookupevent.php?id=441613
# searchplayers.php       | list/players/  | ?{'t': 'Brentford'}             | searchplayers.php?p=Danny_Welbeck | searchplayers.php?t={TeamName}&p={Playername}


# API V1:
if api_version == "1":
    # API Key for Project-Kodi & Project-Plex
    base_url = "https://www.thesportsdb.com/api/v1/json/" + str(change_api_key) + "/{}"
    SEARCH_URL = base_url.format("all_leagues.php")
    SHOW_URL = base_url.format("lookupleague.php")
    SEASON_URL = base_url.format("search_all_seasons.php")
    EVENTLIST_URL = base_url.format("eventsseason.php")
    EPISODE_URL = base_url.format("lookupevent.php")
    ROSTER_URL = base_url.format("searchplayers.php")
    TEAMLIST_URL = base_url.format("search_all_teams.php")
    HEADERS = (
        (
            "User-Agent",
            "Kodi sports events scraper by Project Kodi - metadata.thesportsdb.python; contact kodi-support@streimelweger.eu; API Version 1.0",
        ),
        ("Accept", "application/json"),
    )
    logger.debug("V1 API Settings load")

# API V2:
elif api_version == "2":
    # API Key for Project-Kodi & Project-Plex
    base_url = "https://www.thesportsdb.com/api/v2/json/" + str(change_api_key) + "/{}"
    SEARCH_URL = base_url.format(
        "all/leagues"
    )  # all_leagues.php => https://www.thesportsdb.com/api/v2/json/3/all/leagues
    SHOW_URL = base_url.format(
        "lookup/league/"
    )  # lookupleague.php => https://www.thesportsdb.com/api/v2/json/3/lookup/league/4328
    SEASON_URL = base_url.format(
        "list/seasons/"
    )  # search_all_seasons.php => https://www.thesportsdb.com/api/v2/json/3/list/seasons/4328
    EVENTLIST_URL = base_url.format(
        "filter/events/"
    )  # eventsseason.php https://www.thesportsdb.com/api/v2/json/3/filter/events/4370/1850
    EPISODE_URL = base_url.format(
        "lookup/event/"
    )  # lookupevent.php => https://www.thesportsdb.com/api/v2/json/3/lookup/event/1448310
    ROSTER_URL = base_url.format(
        "list/players/"
    )  # searchplayers.php => https://www.thesportsdb.com/api/v2/json/3/list/players/133604
    TEAMLIST_URL = base_url.format(
        "list/teams/"
    )  # search_all_teams.php => https://www.thesportsdb.com/api/v2/json/3/list/teams/Formula_1
    SEASON_ARTWORK_URL = base_url.format("list/seasonposters/")  # new in API V2
    HEADERS = (
        (
            "User-Agent",
            "Kodi sports events scraper by Project Kodi - metadata.thesportsdb.python; contact kodi-support@streimelweger.eu; API Version 2.0",
        ),
        ("Accept", "application/json"),
    )
    logger.debug("V2 API Settings load")


api_utils.set_headers(dict(HEADERS))


def search_show(title, api_version):
    # type: (Text ,int) -> Optional[List]
    """
    Search for a single sports league

    :param title: Sports League title to search
    :param api_version: API Version
    :return: a dict with the matching sports league
    """
    params = {}
    results = []
    logger.debug("using title of %s to find league" % title)
    resp = api_utils.load_info(
        SEARCH_URL, params=params, verboselog=settings.VERBOSELOG
    )
    if resp is not None:
        for league in resp.get("leagues"):
            if league.get("strLeague") == title:
                params["id"] = league.get("idLeague")
                resp_d = api_utils.load_info(
                    SHOW_URL, params=params, verboselog=settings.VERBOSELOG
                )
                if resp_d is not None:
                    results = resp_d.get("leagues")
                break
    if verboselog_adv:
        logger.debug('Function search_show results: "{}"'.format(results))
    return results


def load_show_info(show_id, api_version):
    # type: (Text ,int) -> Optional[InfoType]
    """Save rosters info to list item"""
    """
    Get full info for a single league

    :param show_id: thesportsDB League ID
    :param api_version: API Version   
    :return: show info or None
    """
    show_info = cache.load_show_info_from_cache(show_id)
    if show_info is None:
        logger.debug("no cache file found, loading from scratch")
        params = {}
        params["id"] = show_id
        resp = api_utils.load_info(
            SHOW_URL, params=params, verboselog=settings.VERBOSELOG
        )
        if resp is None:
            return None
        show_info = resp.get("leagues", [])[0]
        logger.debug("saving show info to the cache")
        if settings.VERBOSELOG:
            logger.debug(format(pformat(show_info)))
        cache.cache_show_info(show_info)
    else:
        logger.debug("using cached show info")
    if verboselog_adv:
        logger.debug('Function load_show_info show_info: "{}"'.format(show_info))
    return show_info


def load_episode_info(show_id, episode_id, api_version):
    # type: (Text, Text ,int) -> Optional[InfoType]
    """
    Load episode info

    :param show_id:
    :param episode_id:
    :param api_version: API Version
    :return: episode info or None
    """
    show_info = load_show_info(show_id, api_version)
    found_event = False
    if show_info is not None:
        for event in show_info.get("event_list"):
            if event.get("idEvent") == episode_id:
                episode_info = event
                found_event = True
                break
        if not found_event:
            return None
        params = {"id": episode_id}
        resp = api_utils.load_info(
            EPISODE_URL, params=params, verboselog=settings.VERBOSELOG
        )
        if resp is None:
            return None
        ep_return = resp.get("events", [])[0]
        # ep_return["strEvent"] = episode_info.get("strEvent", "0")
        ep_return["strEpisode"] = episode_info.get("strEpisode", "0")
        if verboselog_adv:
            logger.debug('Function load_episode_info ep_return: "{}"'.format(ep_return))
        return ep_return
    return None


def load_roster_info(team_id, team_name, api_version):
    # type: (Text, Text ,int) -> Optional[InfoType]
    """
    Load roster info

    :param team_id:
    :param team_name:
    :param api_version: API Version
    :return: team roster or None
    """
    players = None
    resp = cache.load_show_info_from_cache(team_id)
    if not resp:
        params = {"t": team_name.replace(" ", "_")}
        resp = api_utils.load_info(
            ROSTER_URL, params=params, verboselog=settings.VERBOSELOG
        )
    if resp:
        # API V1:
        if api_version == "1":
            players = resp.get("player")
        # API V2:
        elif api_version == "2":
            players = resp.get("players")
        if verboselog_adv:
            logger.debug(
                'Function load_roster_info Respong ROSTER_URL: "{}"'.format(resp)
            )
            logger.debug(
                'Function load_roster_info Respong ROSTER_URL => players: "{}"'.format(
                    players
                )
            )
        # Save all Information about Player from one Team in Cache
        info = {"idTeam": team_id, "player": players}
        cache.cache_show_info(info, info_type="roster")
    if verboselog_adv:
        logger.debug('Function load_roster_info players: "{}"'.format(players))
    return players


def load_team_list(league_name, api_version):
    # type: (Text ,int) -> Optional[InfoType]
    """
    Load team list for league

    :param league_name:
    :param api_version: API Version
    :return: team list or None
    """
    teams = None
    params = {"l": league_name.replace(" ", "_")}
    resp = api_utils.load_info(
        TEAMLIST_URL, params=params, verboselog=settings.VERBOSELOG
    )
    if resp:
        teams = resp.get("teams")
    if verboselog_adv:
        logger.debug('Function load_team_list teams: "{}"'.format(teams))
    return teams


def load_season_info(show_id, api_version):
    # type: (Text ,int) -> Optional[InfoType]
    """
    Load season info

    :param show_id:
    :param api_version: API Version
    :return: season list or None
    """
    params = {"id": show_id}
    resp = api_utils.load_info(
        SEASON_URL, params=params, verboselog=settings.VERBOSELOG
    )
    if resp:
        if verboselog_adv:
            logger.debug(
                'Function load_season_info seasons: "{}"'.format(resp.get("seasons"))
            )
        return resp.get("seasons")
    return None


def load_season_episodes(idLeague, season_name, api_version):
    # type: (int, Text ,int) -> Optional[InfoType]
    """
    Load episode list for given season

    :param idLeague:
    :param season_name:
    :param api_version: API Version
    :return: episode list or None
    """
    params = {}
    params["id"] = idLeague
    params["s"] = season_name
    resp = api_utils.load_info(
        EVENTLIST_URL, params=params, verboselog=settings.VERBOSELOG
    )
    if resp:
        if verboselog_adv:
            logger.debug(
                'Function load_season_episodes events: "{}"'.format(resp.get("events"))
            )
        return resp.get("events")
    return None


def load_season_artwork(show_id, api_version):
    # type: (Text ,int) -> Optional[InfoType]
    """
    Load season artwork

    :param show_id:
    :param api_version: API Version
    :return: season poster list or None
    """
    params = {"id": show_id}
    resp = api_utils.load_info(
        SEASON_ARTWORK_URL, params=params, verboselog=settings.VERBOSELOG
    )
    if resp:
        if verboselog_adv:
            logger.debug(
                'Function load_season_artwork posters: "{}"'.format(
                    resp.get("seasonposters")
                )
            )
        return resp.get("seasonposters")
    return None
